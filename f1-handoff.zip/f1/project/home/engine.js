/* ============================================================================
   F1Pulse — shared homepage engine (vanilla, no deps)
   Scroll-linked parallax + reveals + split text + magnetic type + car
   silhouette + a tiny host-protocol Tweaks panel (theme / motion).
   ========================================================================== */
(function () {
  'use strict';

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const root = document.documentElement;

  /* ── tweaks state ──────────────────────────────────────────────────────── */
  const ACCENTS = [
    { key: 'crimson', label: 'Crimson', a: '#D81E13', a2: '#FF5247' },
    { key: 'petrol',  label: 'Petrol',  a: '#12C2B0', a2: '#0CE0C9' },
    { key: 'papaya',  label: 'Papaya',  a: '#FF7A1A', a2: '#FF9A4D' },
  ];
  const DEFAULTS = window.__F1_TWEAKS || { theme: 'light', motion: 8, accent: 'crimson' };
  if (!DEFAULTS.accent) DEFAULTS.accent = 'crimson';
  const normMotion = (m) => {                  // tolerate 0–1 or 0–10 stored scales
    const v = (typeof m === 'number') ? m : 8;
    return Math.max(0, Math.min(1, v > 1.0001 ? v / 10 : v));
  };
  let motion = reduced ? 0 : normMotion(DEFAULTS.motion);  // 0..1 amplitude scale
  window.__f1motion = motion;

  function applyTheme(t) { root.setAttribute('data-theme', t === 'dark' ? 'dark' : 'light'); }
  function applyAccent(key) {
    const a = ACCENTS.find((x) => x.key === key) || ACCENTS[0];
    root.style.setProperty('--accent', a.a);     // inline → wins over theme override
    root.style.setProperty('--accent-2', a.a2);
  }
  applyTheme(DEFAULTS.theme);
  applyAccent(DEFAULTS.accent);

  /* ── smooth inertia scroll (Lenis-lite) ────────────────────────────────── */
  // Keeps REAL scroll position (sticky/fixed still work) but eases toward a
  // wheel/key-driven target. Disabled for touch + reduced-motion.
  const smooth = { on: false, target: 0, current: 0, ease: 0.085 };
  function maxScroll() { return Math.max(0, document.body.scrollHeight - innerHeight); }
  function initSmooth() {
    if (reduced || matchMedia('(pointer:coarse)').matches) return;
    smooth.on = true;
    smooth.target = smooth.current = window.scrollY;
    addEventListener('wheel', (e) => {
      if (!smooth.on) return;
      if (e.ctrlKey) return;                       // pinch-zoom
      e.preventDefault();
      smooth.target = Math.min(maxScroll(), Math.max(0, smooth.target + e.deltaY));
    }, { passive: false });
    // keyboard + space/page nav
    addEventListener('keydown', (e) => {
      if (!smooth.on) return;
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || e.target.isContentEditable) return;
      const step = innerHeight;
      let d = 0;
      if (e.key === 'ArrowDown') d = 90; else if (e.key === 'ArrowUp') d = -90;
      else if (e.key === 'PageDown' || e.key === ' ') d = step * 0.9;
      else if (e.key === 'PageUp') d = -step * 0.9;
      else if (e.key === 'Home') { smooth.target = 0; return; }
      else if (e.key === 'End') { smooth.target = maxScroll(); return; }
      if (d) { e.preventDefault(); smooth.target = Math.min(maxScroll(), Math.max(0, smooth.target + d)); }
    });
    // anchor links → eased jump
    document.addEventListener('click', (e) => {
      const a = e.target.closest && e.target.closest('a[href^="#"]');
      if (!a) return;
      const id = a.getAttribute('href').slice(1);
      const el = id && document.getElementById(id);
      if (!el) return;
      e.preventDefault();
      smooth.target = Math.min(maxScroll(), Math.max(0, window.scrollY + el.getBoundingClientRect().top - 0));
    });
    // if user drags scrollbar / external scroll, resync target
    addEventListener('scroll', () => {
      if (!smooth.on) return;
      if (Math.abs(window.scrollY - smooth.current) > 4) { smooth.target = smooth.current = window.scrollY; }
    }, { passive: true });
  }
  function stepSmooth() {
    if (!smooth.on) return;
    const m = (window.__f1motion ?? motion);
    if (m <= 0) { smooth.target = smooth.current = window.scrollY; return; }  // motion=calm → native
    smooth.current += (smooth.target - smooth.current) * smooth.ease;
    if (Math.abs(smooth.target - smooth.current) < 0.4) smooth.current = smooth.target;
    window.scrollTo(0, smooth.current);
  }

  /* ── scroll loop ───────────────────────────────────────────────────────── */
  let vw = innerWidth, vh = innerHeight, prog = 0;
  const frameCbs = [];
  const onFrame = (cb) => { frameCbs.push(cb); return cb; };
  // expose helper so page scripts can map a section's scroll progress
  function progressOf(el, opts) {
    // returns 0..1 as `el` travels: default = top hits bottom (0) → bottom hits top (1)
    const r = el.getBoundingClientRect();
    const mode = (opts && opts.mode) || 'through';
    if (mode === 'pin') {                          // for tall pinned wrappers
      const total = el.offsetHeight - vh;
      return Math.min(1, Math.max(0, (-r.top) / Math.max(1, total)));
    }
    if (mode === 'enter') {                         // 0 when top at vh, 1 when top at 0
      return Math.min(1, Math.max(0, (vh - r.top) / vh));
    }
    return Math.min(1, Math.max(0, (vh - r.top) / (vh + r.height)));
  }

  function collectPar() {
    return [...document.querySelectorAll('[data-speed]')].map((el) => ({
      el, s: parseFloat(el.getAttribute('data-speed')) || 0,
    }));
  }
  let parEls = [];
  let revealEls = [];

  function loop() {
    stepSmooth();
    const sy = window.scrollY;
    const max = Math.max(1, document.body.scrollHeight - vh);
    prog = Math.min(1, Math.max(0, sy / max));
    root.style.setProperty('--prog', prog.toFixed(4));

    for (const p of parEls) {
      const r = p.el.getBoundingClientRect();
      const center = r.top + r.height / 2;
      const y = (center - vh / 2) * p.s * motion;
      p.el.style.transform = `translate3d(0,${y.toFixed(2)}px,0)`;
    }

    // reveal: rAF-based for reliability (IO timing can lag programmatic jumps)
    if (revealEls.length) {
      const tline = vh * 0.9;
      revealEls = revealEls.filter((el) => {
        const r = el.getBoundingClientRect();
        if (r.top < tline && r.bottom > 0) { el.classList.add('in'); return false; }
        return true;
      });
    }

    for (const cb of frameCbs) { try { cb({ scrollY: sy, prog, vw, vh, motion }); } catch (e) {} }
    requestAnimationFrame(loop);
  }

  addEventListener('resize', () => { vw = innerWidth; vh = innerHeight; }, { passive: true });

  /* ── reveal (rAF-driven; collected at boot) ────────────────────────────── */
  function collectReveal() {
    return [...document.querySelectorAll('[data-reveal],[data-clip],[data-split].split-ready')];
  }

  /* ── split text → lines of letters ─────────────────────────────────────── */
  function splitText(el) {
    const text = el.textContent;
    el.textContent = '';
    el.classList.add('split-ready');
    const words = text.split(/(\s+)/);
    const frag = document.createDocumentFragment();
    words.forEach((w) => {
      if (/^\s+$/.test(w)) { frag.appendChild(document.createTextNode(' ')); return; }
      const ws = document.createElement('span'); ws.className = 'word';
      const inner = document.createElement('span');
      inner.textContent = w;
      ws.appendChild(inner); frag.appendChild(ws);
    });
    el.appendChild(frag);
  }
  function autoSplit() {
    document.querySelectorAll('[data-split]').forEach(splitText);
  }

  /* ── magnetic kinetic headline ─────────────────────────────────────────── */
  function initMagnetic() {
    document.querySelectorAll('[data-magnetic]').forEach((box) => {
      const chars = [...box.querySelectorAll('.mchar')];
      const radius = parseFloat(box.getAttribute('data-magnetic')) || 180;
      const targets = chars.map(() => ({ x: 0, y: 0, cx: 0, cy: 0 }));
      let raf = null;
      function tick() {
        let moving = false;
        chars.forEach((c, i) => {
          const t = targets[i];
          t.cx += (t.x - t.cx) * 0.12; t.cy += (t.y - t.cy) * 0.12;
          if (Math.abs(t.x - t.cx) > 0.1 || Math.abs(t.y - t.cy) > 0.1) moving = true;
          c.style.transform = `translate(${t.cx.toFixed(2)}px,${t.cy.toFixed(2)}px)`;
        });
        raf = moving ? requestAnimationFrame(tick) : null;
      }
      function move(px, py) {
        chars.forEach((c, i) => {
          const r = c.getBoundingClientRect();
          const dx = (r.left + r.width / 2) - px;
          const dy = (r.top + r.height / 2) - py;
          const dist = Math.hypot(dx, dy);
          const f = Math.max(0, 1 - dist / radius);
          const push = f * f * 46 * motion;
          targets[i].x = (dx / (dist || 1)) * push;
          targets[i].y = (dy / (dist || 1)) * push;
        });
        if (!raf) raf = requestAnimationFrame(tick);
      }
      box.addEventListener('pointermove', (e) => move(e.clientX, e.clientY));
      box.addEventListener('pointerleave', () => {
        targets.forEach((t) => { t.x = 0; t.y = 0; });
        if (!raf) raf = requestAnimationFrame(tick);
      });
    });
  }
  // wrap letters of [data-kinetic] into .mchar spans
  function wrapKinetic() {
    document.querySelectorAll('[data-kinetic]').forEach((el) => {
      const html = [...el.childNodes].map((n) => {
        if (n.nodeType === 3) {
          return [...n.textContent].map((ch) =>
            ch === ' ' ? '<span class="mchar">&nbsp;</span>'
                       : `<span class="mchar">${ch}</span>`).join('');
        }
        return n.outerHTML || '';
      }).join('');
      el.innerHTML = html;
    });
  }

  /* ── car silhouette ────────────────────────────────────────────────────── */
  const CAR_SVG = `
<svg class="carfig" viewBox="0 0 480 150" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <g fill="currentColor">
    <!-- floor -->
    <rect x="64" y="104" width="362" height="20" rx="7"/>
    <!-- main body / sidepod -->
    <path d="M96 98 L150 64 L252 64 L300 86 L308 98 L308 112 L96 112 Z"/>
    <!-- airbox hump -->
    <path d="M156 66 L172 38 L190 38 L198 66 Z"/>
    <!-- cockpit surround -->
    <path d="M206 66 L216 54 L246 54 L254 66 Z"/>
    <!-- helmet -->
    <ellipse cx="231" cy="56" rx="12" ry="11"/>
    <!-- long nose -->
    <path d="M250 66 L300 84 L444 116 L444 126 L250 96 Z"/>
    <!-- rear wing top plane -->
    <rect x="10" y="42" width="62" height="13" rx="3"/>
    <!-- rear wing endplate -->
    <rect x="16" y="42" width="14" height="62" rx="2"/>
    <!-- rear beam wing -->
    <rect x="22" y="92" width="56" height="9" rx="3"/>
    <!-- front wing main plane -->
    <rect x="398" y="118" width="74" height="11" rx="3"/>
    <!-- front wing endplate -->
    <rect x="458" y="96" width="13" height="34" rx="2"/>
  </g>
  <!-- front wing upper flap (accent) -->
  <path class="ca" d="M414 117 L472 105 L472 113 L414 124 Z"/>
  <!-- nose accent -->
  <path class="ca" d="M392 110 L444 121 L444 126 L392 116 Z" opacity="0.9"/>
  <!-- rear wing accent edge -->
  <rect class="ca" x="10" y="42" width="62" height="4" rx="2"/>
  <!-- halo -->
  <path d="M198 64 C198 44 232 40 256 56" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>
  <!-- wheels -->
  <g>
    <circle cx="128" cy="98" r="42" fill="currentColor"/>
    <circle cx="128" cy="98" r="14" class="ca"/>
    <circle cx="128" cy="98" r="5.5" fill="var(--paper)"/>
    <circle cx="372" cy="98" r="42" fill="currentColor"/>
    <circle cx="372" cy="98" r="14" class="ca"/>
    <circle cx="372" cy="98" r="5.5" fill="var(--paper)"/>
  </g>
</svg>`;
  function mountCars() {
    document.querySelectorAll('[data-car]').forEach((el) => { el.innerHTML = CAR_SVG; });
  }

  /* ── count up ──────────────────────────────────────────────────────────── */
  function initCounters() {
    const io = new IntersectionObserver((ents) => {
      ents.forEach((e) => {
        if (!e.isIntersecting) return;
        io.unobserve(e.target);
        const el = e.target;
        const to = parseFloat(el.getAttribute('data-count'));
        const dec = (el.getAttribute('data-count').split('.')[1] || '').length;
        const dur = 1500; const t0 = performance.now();
        const pre = el.getAttribute('data-pre') || '';
        const suf = el.getAttribute('data-suf') || '';
        function step(now) {
          const k = Math.min(1, (now - t0) / dur);
          const e2 = 1 - Math.pow(1 - k, 3);
          el.textContent = pre + (to * e2).toFixed(dec) + suf;
          if (k < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
    }, { threshold: 0.6 });
    document.querySelectorAll('[data-count]').forEach((el) => io.observe(el));
  }

  /* ── custom cursor: speed reticle ──────────────────────────────────────── */
  function initCursor() {
    if (matchMedia('(pointer:coarse)').matches || reduced) return;
    const el = document.createElement('div');
    el.className = 'f1cur';
    el.innerHTML = `
      <svg class="f1cur__ring" viewBox="0 0 60 60" width="60" height="60">
        <circle cx="30" cy="30" r="27" fill="none" stroke="var(--accent)" stroke-width="1" stroke-dasharray="10 6"/>
        <line x1="30" y1="2" x2="30" y2="11" stroke="var(--accent)" stroke-width="1"/>
        <line x1="30" y1="49" x2="30" y2="58" stroke="var(--accent)" stroke-width="1"/>
        <line x1="2" y1="30" x2="11" y2="30" stroke="var(--accent)" stroke-width="1"/>
        <line x1="49" y1="30" x2="58" y2="30" stroke="var(--accent)" stroke-width="1"/>
      </svg>
      <div class="f1cur__dot"></div>
      <div class="f1cur__lab"><span class="f1cur__spd">0</span><i>KM/H</i></div>`;
    document.body.appendChild(el);
    document.documentElement.classList.add('has-f1cur');

    let px = innerWidth / 2, py = innerHeight / 2, rx = px, ry = py;
    let lastX = px, lastY = py, lastT = performance.now(), spd = 0, spdShown = 0;
    const spdEl = el.querySelector('.f1cur__spd');
    addEventListener('pointermove', (e) => {
      px = e.clientX; py = e.clientY;
      const now = performance.now(); const dt = Math.max(8, now - lastT);
      const d = Math.hypot(px - lastX, py - lastY);
      spd = Math.min(340, (d / dt) * 1000 * 0.42);
      lastX = px; lastY = py; lastT = now;
      const t = e.target;
      const interactive = t.closest && t.closest('a,button,[data-mag],input,image-slot');
      el.classList.toggle('hot', !!interactive);
    }, { passive: true });
    addEventListener('pointerdown', () => el.classList.add('down'));
    addEventListener('pointerup', () => el.classList.remove('down'));
    document.addEventListener('mouseleave', () => el.classList.add('gone'));
    document.addEventListener('mouseenter', () => el.classList.remove('gone'));

    onFrame(() => {
      rx += (px - rx) * 0.18; ry += (py - ry) * 0.18;
      el.style.transform = `translate3d(${rx.toFixed(1)}px,${ry.toFixed(1)}px,0)`;
      el.querySelector('.f1cur__dot').style.transform =
        `translate(${(px - rx).toFixed(1)}px,${(py - ry).toFixed(1)}px)`;
      spd *= 0.86; spdShown += (spd - spdShown) * 0.25;
      spdEl.textContent = Math.round(spdShown);
    });
  }

  /* ── magnetic interactive elements ─────────────────────────────────────── */
  function initMagLinks() {
    if (matchMedia('(pointer:coarse)').matches) return;
    document.querySelectorAll('[data-mag]').forEach((el) => {
      const pull = parseFloat(el.getAttribute('data-mag')) || 0.3;
      let raf = null, tx = 0, ty = 0, cx = 0, cy = 0;
      function tick() {
        cx += (tx - cx) * 0.18; cy += (ty - cy) * 0.18;
        el.style.transform = `translate(${cx.toFixed(2)}px,${cy.toFixed(2)}px)`;
        if (Math.abs(tx - cx) > 0.1 || Math.abs(ty - cy) > 0.1) raf = requestAnimationFrame(tick);
        else raf = null;
      }
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        tx = (e.clientX - (r.left + r.width / 2)) * pull * motion;
        ty = (e.clientY - (r.top + r.height / 2)) * pull * motion;
        if (!raf) raf = requestAnimationFrame(tick);
      });
      el.addEventListener('pointerleave', () => { tx = 0; ty = 0; if (!raf) raf = requestAnimationFrame(tick); });
    });
  }

  /* ── Tweaks panel (host protocol) ──────────────────────────────────────── */
  let tw = { ...DEFAULTS };
  function persist(edits) {
    Object.assign(tw, edits);
    try { window.parent.postMessage({ type: '__edit_mode_set_keys', edits }, '*'); } catch (e) {}
    try { localStorage.setItem('f1home-tweaks', JSON.stringify(tw)); } catch (e) {}
  }
  function buildPanel() {
    const css = document.createElement('style');
    css.textContent = `
      .twk{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:248px;
        font-family:var(--mono);color:var(--ink);background:var(--card);
        border:1px solid var(--rule);border-radius:13px;box-shadow:var(--shadow);
        transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
        display:none;overflow:hidden}
      .twk.open{display:block}
      .twk__hd{display:flex;align-items:center;justify-content:space-between;
        padding:12px 12px 10px 15px;cursor:move;user-select:none;border-bottom:1px solid var(--rule-soft)}
      .twk__hd b{font-family:var(--display);font-weight:800;font-size:14px;letter-spacing:.05em;text-transform:uppercase}
      .twk__x{width:22px;height:22px;border-radius:6px;color:var(--silver);font-size:14px}
      .twk__x:hover{background:var(--rule-soft);color:var(--ink)}
      .twk__b{padding:14px 15px 16px;display:flex;flex-direction:column;gap:16px}
      .twk__row label{display:block;font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:var(--silver);margin-bottom:9px}
      .twk__seg{display:flex;gap:3px;background:var(--paper-2);border-radius:8px;padding:3px}
      .twk__seg button{flex:1;padding:7px 0;font-size:10.5px;letter-spacing:.16em;text-transform:uppercase;border-radius:6px;color:var(--silver);transition:.2s}
      .twk__seg button.on{background:var(--accent);color:#fff;font-weight:600}
      .twk__sw{display:flex;gap:8px}
      .twk__sw button{flex:1;height:30px;border-radius:7px;border:1px solid var(--rule);position:relative;transition:.2s;overflow:hidden}
      .twk__sw button::after{content:'';position:absolute;inset:0;background:var(--c);opacity:.18;transition:.2s}
      .twk__sw button .chip{position:absolute;left:8px;top:50%;transform:translateY(-50%);width:13px;height:13px;border-radius:50%;background:var(--c)}
      .twk__sw button span{position:absolute;right:9px;top:50%;transform:translateY(-50%);font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--silver)}
      .twk__sw button.on{border-color:var(--c)}
      .twk__sw button.on::after{opacity:.32}
      .twk__sw button.on span{color:var(--ink)}
      .twk__rng{width:100%;-webkit-appearance:none;height:2px;background:var(--rule);border-radius:2px;outline:none}
      .twk__rng::-webkit-slider-thumb{-webkit-appearance:none;width:15px;height:15px;border-radius:50%;background:var(--accent);cursor:pointer;border:2px solid var(--card)}
      .twk__val{float:right;color:var(--ink);font-variant-numeric:tabular-nums}
    `;
    document.head.appendChild(css);
    const p = document.createElement('div');
    p.className = 'twk';
    p.innerHTML = `
      <div class="twk__hd"><b>Tweaks</b><button class="twk__x" aria-label="Close">✕</button></div>
      <div class="twk__b">
        <div class="twk__row"><label>Theme</label>
          <div class="twk__seg" data-seg="theme">
            <button data-v="light">Paper</button><button data-v="dark">Carbon</button>
          </div>
        </div>
        <div class="twk__row"><label>Accent</label>
          <div class="twk__sw" data-seg="accent">
            ${ACCENTS.map((a) => `<button data-v="${a.key}" style="--c:${a.a}"><i class="chip"></i><span>${a.label}</span></button>`).join('')}
          </div>
        </div>
        <div class="twk__row"><label>Motion <span class="twk__val" id="twk-mval"></span></label>
          <input class="twk__rng" id="twk-motion" type="range" min="0" max="10" step="1">
        </div>
      </div>`;
    document.body.appendChild(p);

    const seg = p.querySelector('[data-seg="theme"]');
    function paintSeg() { seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === tw.theme)); }
    seg.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
      applyTheme(b.dataset.v); persist({ theme: b.dataset.v }); paintSeg();
    }));
    paintSeg();

    const asw = p.querySelector('[data-seg="accent"]');
    function paintAcc() { asw.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === tw.accent)); }
    asw.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
      applyAccent(b.dataset.v); persist({ accent: b.dataset.v }); paintAcc();
    }));
    paintAcc();
    const rng = p.querySelector('#twk-motion');
    const mval = p.querySelector('#twk-mval');
    const m10 = tw.motion > 1.0001 ? Math.round(tw.motion) : Math.round((tw.motion || 0) * 10);
    rng.value = m10;
    mval.textContent = m10 === 0 ? 'calm' : (m10 >= 9 ? 'max' : m10);
    rng.addEventListener('input', () => {
      const v = parseInt(rng.value, 10);
      motion = v / 10; window.__f1motion = motion;
      mval.textContent = v === 0 ? 'calm' : (v >= 9 ? 'max' : v);
      persist({ motion: v });
    });

    // drag
    const hd = p.querySelector('.twk__hd');
    let dx = 0, dy = 0, drag = false;
    hd.addEventListener('pointerdown', (e) => {
      if (e.target.classList.contains('twk__x')) return;
      drag = true; dx = e.clientX; dy = e.clientY; hd.setPointerCapture(e.pointerId);
      p.style.transition = 'none';
    });
    hd.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const nx = e.clientX - dx, ny = e.clientY - dy; dx = e.clientX; dy = e.clientY;
      p.style.right = ''; p.style.bottom = '';
      p.style.left = (p.offsetLeft + nx) + 'px'; p.style.top = (p.offsetTop + ny) + 'px';
    });
    hd.addEventListener('pointerup', () => { drag = false; });

    p.querySelector('.twk__x').addEventListener('click', () => {
      p.classList.remove('open');
      try { window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*'); } catch (e) {}
    });

    addEventListener('message', (e) => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') p.classList.add('open');
      else if (t === '__deactivate_edit_mode') p.classList.remove('open');
    });
    try { window.parent.postMessage({ type: '__edit_mode_available' }, '*'); } catch (e) {}
  }

  /* ── boot ──────────────────────────────────────────────────────────────── */
  function boot() {
    // merge any localStorage tweak (host EDITMODE wins on file reload, this covers preview)
    try {
      const saved = JSON.parse(localStorage.getItem('f1home-tweaks') || 'null');
      if (saved) { tw = { ...tw, ...saved }; applyTheme(tw.theme); if (tw.accent) applyAccent(tw.accent); motion = (reduced ? 0 : normMotion(tw.motion)); window.__f1motion = motion; }
    } catch (e) {}
    parEls = collectPar();
    revealEls = collectReveal();
    initSmooth();
    requestAnimationFrame(loop);                 // start first — reveals/parallax must never be blocked
    try { autoSplit(); } catch (e) { console.warn('split', e); }
    try { wrapKinetic(); } catch (e) { console.warn('kinetic', e); }
    try { mountCars(); } catch (e) { console.warn('cars', e); }
    try { initMagnetic(); } catch (e) { console.warn('magnetic', e); }
    try { initMagLinks(); } catch (e) { console.warn('maglinks', e); }
    try { initCounters(); } catch (e) { console.warn('counters', e); }
    try { initCursor(); } catch (e) { console.warn('cursor', e); }
    try { buildPanel(); } catch (e) { console.warn('panel', e); }
  }

  window.F1 = { onFrame, splitText, mountCars, CAR_SVG, progressOf };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
