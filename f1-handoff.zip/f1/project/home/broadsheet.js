/* ============================================================================
   Homepage — Broadsheet · page choreography
   (countdown · marquee/lane · circuit · hero drift · speed divider · era rail)
   Loads after engine.js; uses window.F1.onFrame.
   ========================================================================== */
(function () {
  'use strict';
  const F1 = window.F1; if (!F1) return;

  /* ── countdown ───────────────────────────────────────────────────────── */
  (function () {
    const target = new Date(Date.now() + (2 * 864e5) + (18 * 36e5) + (2 * 6e4));
    const map = {
      d: document.querySelector('[data-cd="d"]'), h: document.querySelector('[data-cd="h"]'),
      m: document.querySelector('[data-cd="m"]'), s: document.querySelector('[data-cd="s"]'),
    };
    const pad = (n) => String(n).padStart(2, '0');
    function tick() {
      let diff = Math.max(0, target - Date.now());
      const d = Math.floor(diff / 864e5); diff -= d * 864e5;
      const h = Math.floor(diff / 36e5); diff -= h * 36e5;
      const m = Math.floor(diff / 6e4); diff -= m * 6e4;
      const s = Math.floor(diff / 1e3);
      if (map.d) map.d.textContent = pad(d); if (map.h) map.h.textContent = pad(h);
      if (map.m) map.m.textContent = pad(m); if (map.s) map.s.textContent = pad(s);
    }
    tick(); setInterval(tick, 1000);
  })();

  /* ── marquee + lane percent ──────────────────────────────────────────── */
  (function () {
    const track = document.getElementById('marq');
    if (track) track.innerHTML += track.innerHTML;
    const pct = document.getElementById('lanepct');
    let mx = 0;
    const half = () => (track ? track.scrollWidth / 2 : 0);
    F1.onFrame(({ prog, motion }) => {
      if (pct) pct.textContent = Math.round(prog * 100);
      if (track) {
        mx -= (0.6 + motion * 1.2);
        if (-mx >= half()) mx += half();
        track.style.transform = `translateX(${mx}px)`;
      }
    });
  })();

  /* ── lane ticks ──────────────────────────────────────────────────────── */
  (function () {
    const lane = document.querySelector('.lane'); if (!lane) return;
    for (let i = 1; i < 10; i++) {
      const t = document.createElement('div'); t.className = 'lane__tick';
      t.style.left = `calc(var(--pad) + (100% - var(--pad)*2) * ${i / 10})`;
      lane.appendChild(t);
    }
  })();

  /* ── feed telemetry bars ─────────────────────────────────────────────── */
  (function () {
    const wrap = document.getElementById('feedbars'); if (!wrap) return;
    for (let i = 0; i < 30; i++) {
      const b = document.createElement('i');
      b.style.animationDelay = (-Math.random() * 1.3).toFixed(2) + 's';
      b.style.animationDuration = (1 + Math.random() * 0.9).toFixed(2) + 's';
      wrap.appendChild(b);
    }
  })();

  /* ── self-drawing Monaco circuit + tracing car ───────────────────────── */
  (function () {
    const svg = document.getElementById('circuit'); if (!svg) return;
    const edge = document.getElementById('trk-edge'), base = document.getElementById('trk-base'), line = document.getElementById('trk-line');
    const nodesG = document.getElementById('trk-nodes'), car = document.getElementById('trk-car'), ghost = document.getElementById('trk-ghost'), sfG = document.getElementById('trk-sf');
    const P = [[232,524],[201,498],[183,462],[207,447],[193,417],[219,402],[198,372],[223,357],[241,326],[223,296],[250,260],[300,240],[356,238],[402,220],[424,184],[404,150],[374,158],[372,198],[349,232],[320,262],[300,318],[276,380],[256,442],[244,488]];
    function smooth(p) { const n = p.length; let d = `M ${p[0][0]} ${p[0][1]} `; for (let i = 0; i < n; i++) { const a = p[(i-1+n)%n], b = p[i], c = p[(i+1)%n], e = p[(i+2)%n]; const c1x=b[0]+(c[0]-a[0])/6, c1y=b[1]+(c[1]-a[1])/6, c2x=c[0]-(e[0]-b[0])/6, c2y=c[1]-(e[1]-b[1])/6; d += `C ${c1x.toFixed(1)} ${c1y.toFixed(1)}, ${c2x.toFixed(1)} ${c2y.toFixed(1)}, ${c[0]} ${c[1]} `; } return d + 'Z'; }
    const d = smooth(P); edge.setAttribute('d', d); base.setAttribute('d', d); line.setAttribute('d', d);
    const L = line.getTotalLength();
    line.style.strokeDasharray = L; line.style.strokeDashoffset = L; line.style.transition = 'stroke-dashoffset 2.6s cubic-bezier(0.16,1,0.3,1)';
    const sf = line.getPointAtLength(0); sfG.setAttribute('transform', `translate(${sf.x} ${sf.y})`);
    const fr = [0.05,0.14,0.24,0.35,0.47,0.58,0.70,0.83]; const nodes = [];
    fr.forEach((f, i) => { const pt = line.getPointAtLength(f * L); const g = document.createElementNS('http://www.w3.org/2000/svg', 'g'); g.setAttribute('class', 'circuit__node'); g.setAttribute('transform', `translate(${pt.x} ${pt.y})`); g.innerHTML = `<circle r="11"></circle><text text-anchor="middle" dy="3.8">${String(i+1).padStart(2,'0')}</text>`; nodesG.appendChild(g); nodes.push({ g, len: f * L }); });
    let drawn = false;
    const io = new IntersectionObserver((e) => { e.forEach((x) => { if (x.isIntersecting && !drawn) { drawn = true; requestAnimationFrame(() => { line.style.strokeDashoffset = 0; }); } }); }, { threshold: 0.25 });
    io.observe(svg);
    let phase = 0, last = performance.now();
    F1.onFrame(({ motion }) => {
      const now = performance.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
      const lap = 15 - motion * 10;
      phase = (phase + dt / Math.max(3.5, lap)) % 1;
      const t = drawn ? phase : 0;
      const pc = line.getPointAtLength(t * L); car.setAttribute('cx', pc.x); car.setAttribute('cy', pc.y);
      const pg = line.getPointAtLength(((t - 0.02 + 1) % 1) * L); ghost.setAttribute('cx', pg.x); ghost.setAttribute('cy', pg.y);
      const cl = t * L; nodes.forEach((n) => { let dd = Math.abs(cl - n.len); dd = Math.min(dd, L - dd); n.g.classList.toggle('hot', drawn && dd < 28); });
    });
  })();

  /* ── hero ambient drift ──────────────────────────────────────────────── */
  (function () {
    const hero = document.querySelector('.hero'); if (!hero) return;
    const ghost = document.querySelector('.hero__ghost'), k = document.querySelector('.kinetic');
    let tx = 0, ty = 0, cx = 0, cy = 0;
    hero.addEventListener('pointermove', (e) => { const m = window.__f1motion || 0; const r = hero.getBoundingClientRect(); tx = ((e.clientX - r.left) / r.width - 0.5) * 46 * m; ty = ((e.clientY - r.top) / r.height - 0.5) * 30 * m; }, { passive: true });
    hero.addEventListener('pointerleave', () => { tx = 0; ty = 0; });
    F1.onFrame(() => {
      cx += (tx - cx) * 0.06; cy += (ty - cy) * 0.06;
      if (ghost) ghost.style.transform = `translate(${(cx * 1.5).toFixed(1)}px,${(cy * 1.2).toFixed(1)}px)`;
      if (k) k.style.transform = `translate(${(cx * -0.35).toFixed(1)}px,${(cy * -0.28).toFixed(1)}px)`;
    });
  })();

  /* ── speed / telemetry divider — opposing scrub rows ─────────────────── */
  (function () {
    const sec = document.getElementById('speed'); if (!sec) return;
    const a = sec.querySelector('[data-row="a"]'), b = sec.querySelector('[data-row="b"]');
    if (a) a.innerHTML += a.innerHTML; if (b) b.innerHTML += b.innerHTML;
    let ax = 0, bx = 0;
    const halfA = () => (a ? a.scrollWidth / 2 : 0), halfB = () => (b ? b.scrollWidth / 2 : 0);
    F1.onFrame(({ motion, vh }) => {
      const r = sec.getBoundingClientRect();
      const vis = r.top < (vh || innerHeight) && r.bottom > 0;
      const boost = vis ? (1 + motion * 2.2) : 0.4;
      if (a) { ax -= boost; if (-ax >= halfA()) ax += halfA(); a.style.transform = `translateX(${ax}px)`; }
      if (b) { bx += boost * 0.8; if (bx >= 0) bx -= halfB(); b.style.transform = `translateX(${bx}px)`; }
    });
  })();

  /* ── THE CURRENT ERA — pinned, fully scrubbed cinematic scene ─────────── */
  (function () {
    const sec = document.getElementById('ground'); if (!sec) return;
    const year = document.getElementById('ce-year');
    const eyebrow = document.getElementById('ce-eyebrow');
    const titleWords = [...sec.querySelectorAll('.ce__title [data-w]')];
    const car = document.getElementById('ce-car');
    const img = car ? car.querySelector('img') : null;
    const scan = document.getElementById('ce-scan');
    const floor = document.getElementById('ce-floor');
    const tuns = [...sec.querySelectorAll('.ce__tun')];
    const caption = document.getElementById('ce-caption');
    const specs = [...sec.querySelectorAll('.ce__spec')];
    const hint = document.getElementById('ce-hint');
    const counters = specs.map((s) => {
      const span = s.querySelector('[data-to]');
      return { span, to: parseFloat(span.dataset.to), dec: parseInt(span.dataset.dec || '0', 10) };
    });
    const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
    const sub = (p, a, b) => clamp((p - a) / (b - a));
    const eo = (t) => 1 - Math.pow(1 - t, 3);
    const eio = (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    let dash = 0;

    F1.onFrame(({ motion }) => {
      const r = sec.getBoundingClientRect();
      const visible = r.bottom > 0 && r.top < innerHeight;
      // animate flowing tunnel dashes whenever near
      if (visible) { dash -= (0.6 + motion * 2); tuns.forEach((t) => { t.style.strokeDashoffset = dash; }); }
      if (!visible && car && car.dataset.built === '1') { /* keep last frame */ }

      const p = F1.progressOf(sec, { mode: 'pin' });

      // YEAR — slow parallax drift + slight scale, fade out late
      if (year) {
        const yp = eo(sub(p, 0, 1));
        year.style.transform = `translateY(${(-yp * 80).toFixed(1)}px) scale(${(1 + p * 0.18).toFixed(3)})`;
        year.style.opacity = (0.05 * (1 - sub(p, 0.55, 0.85) * 0.6)).toFixed(3);
      }

      // TITLE words rise in (staggered), then lift + fade as car takes over
      const tIn = sub(p, 0.02, 0.22), tOut = sub(p, 0.30, 0.46);
      titleWords.forEach((w, i) => {
        const d = i * 0.12;
        const enter = eo(clamp((tIn - d) / (1 - d)));
        const y = (1 - enter) * 118 - tOut * 60;
        w.style.transform = `translateY(${y.toFixed(1)}%)`;
      });
      if (sec.querySelector('.ce__title')) sec.querySelector('.ce__title').style.opacity = (1 - tOut).toFixed(3);
      if (eyebrow) { eyebrow.style.transform = `translateY(${(-tOut * 40).toFixed(1)}px)`; eyebrow.style.opacity = (1 - tOut * 0.6).toFixed(3); }
      if (hint) hint.style.opacity = (0.5 * (1 - sub(p, 0.05, 0.16))).toFixed(3);

      // CAR — clip-reveal from centre sliver, scale settle, parallax slide
      const tCar = sub(p, 0.18, 0.5);
      if (car) {
        const open = eio(tCar);
        const inset = (1 - open) * 50;            // 50% → 0
        car.style.clipPath = `inset(0 ${inset.toFixed(2)}% 0 ${inset.toFixed(2)}%)`;
        const slide = (1 - open) * 70;
        const scale = 1.16 - open * 0.16;
        car.style.transform = `translate(calc(-50% + ${slide.toFixed(1)}px), -50%) scale(${scale.toFixed(3)})`;
        car.dataset.built = tCar > 0.99 ? '1' : '0';
        // subtle continuous parallax bob after built
        if (img) img.style.transform = `translateY(${(Math.sin(p * 10) * 4 * motion).toFixed(2)}px)`;
      }
      if (scan) {
        const s = sub(p, 0.2, 0.46);
        scan.style.left = `${(s * 100).toFixed(1)}%`;
        scan.style.opacity = (Math.sin(clamp(s) * Math.PI)).toFixed(3);
      }

      // FLOOR tunnels glow in
      const tFloor = sub(p, 0.42, 0.62);
      if (floor) {
        floor.style.opacity = eo(tFloor).toFixed(3);
        floor.style.transform = `translate(-50%, ${(40 - eo(tFloor) * 40).toFixed(1)}px)`;
      }

      // CAPTION
      const tCap = sub(p, 0.54, 0.7);
      if (caption) { caption.style.opacity = eo(tCap).toFixed(3); caption.style.transform = `translateY(${((1 - eo(tCap)) * 40).toFixed(1)}px)`; }

      // SPECS — staggered rise + scrubbed count-up
      specs.forEach((s, i) => {
        const a = 0.58 + i * 0.055, b = a + 0.16;
        const t = sub(p, a, b);
        const e = eo(t);
        s.style.opacity = e.toFixed(3);
        s.style.transform = `translateY(${((1 - e) * 46).toFixed(1)}px)`;
        const c = counters[i];
        c.span.textContent = (c.to * e).toFixed(c.dec);
      });
    });
  })();


  (function () {
    const sec = document.getElementById('eras'); if (!sec) return;
    const track = document.getElementById('eratrack');
    const pin = sec.querySelector('.era__pin');
    const prog = document.getElementById('eraprog');
    const panels = [...track.querySelectorAll('.era__panel')];
    const n = panels.length;
    const STOPS = panels.map((p) => ({ bg: p.dataset.bg, fg: p.dataset.fg }));
    let curIdx = -1;

    F1.onFrame(({ vh }) => {
      const h = vh || innerHeight;
      const r = sec.getBoundingClientRect();
      const total = sec.offsetHeight - h;
      const p = Math.min(1, Math.max(0, (-r.top) / Math.max(1, total)));
      const maxX = Math.max(0, track.scrollWidth - innerWidth);
      track.style.transform = `translate3d(${(-p * maxX).toFixed(1)}px,0,0)`;
      if (prog) prog.style.transform = `scaleX(${p.toFixed(4)})`;

      const engaged = r.top <= 1 && r.bottom >= h;
      document.body.classList.toggle('eras-active', engaged);

      // active panel + mood
      const idx = Math.min(n - 1, Math.round(p * (n - 1)));
      if (idx !== curIdx) {
        curIdx = idx;
        const s = STOPS[idx];
        if (pin && s) { pin.style.background = s.bg; pin.style.color = s.fg; }
        panels.forEach((pn, i) => pn.classList.toggle('era__panel--on', i === idx));
      }
    });
  })();
})();
