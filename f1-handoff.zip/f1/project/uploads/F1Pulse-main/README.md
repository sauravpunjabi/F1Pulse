# F1Pulse

> A cinematic, immersive Formula 1 platform covering the live 2026 season and the complete history of Formula 1 from 1950 → present.
> Built as an experience — not a dashboard.

![Next.js](https://img.shields.io/badge/Next.js-14-black?style=for-the-badge\&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-Strict-blue?style=for-the-badge\&logo=typescript)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-Database-blue?style=for-the-badge\&logo=postgresql)
![Redis](https://img.shields.io/badge/Redis-Cache-red?style=for-the-badge\&logo=redis)

---

# Overview

F1Pulse is a full-stack Formula 1 platform focused on immersive storytelling, cinematic UI, and real-time racing data.

Unlike traditional sports dashboards, F1Pulse blends:

* Live race data
* Historical archives
* Motion-driven interfaces
* Interactive storytelling
* High-performance infrastructure
* Cinematic user experiences

into a premium web experience inspired by Formula 1 broadcasts, editorial design, and modern interactive websites.

---

# Core Philosophy

* No hardcoded race data
* No direct frontend calls to third-party APIs
* Server-side ingestion + normalization only
* Fast cached responses through the F1Pulse API
* Experience-first UI/UX architecture

All race data is:

1. Ingested server-side from live sources
2. Normalized into PostgreSQL
3. Cached using Redis
4. Served through F1Pulse's own API layer

The frontend communicates only with the internal API.

---

# Tech Stack

| Layer                    | Technologies                                                                                                     |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------- |
| **Frontend**             | Next.js 14, React, TypeScript, Tailwind CSS, Framer Motion, GSAP, Lenis, React Three Fiber, Zustand, React Query |
| **Backend**              | Node.js, Express, TypeScript, Prisma                                                                             |
| **Database**             | PostgreSQL                                                                                                       |
| **Caching & Queues**     | Redis, BullMQ                                                                                                    |
| **Infrastructure**       | Vercel, Railway/Fly.io, Cloudinary                                                                               |
| **Developer Experience** | pnpm Workspaces, Docker, ESLint, Prettier                                                                        |

---

# Features

## Current / Planned

* Live 2026 F1 season coverage
* Full Formula 1 historical archive (1950 → present)
* Driver and constructor profiles
* Interactive race timelines
* Animated standings and visuals
* Cinematic landing experience
* Session telemetry visualizations
* Responsive premium UI
* High-performance caching architecture
* Smooth motion and immersive transitions

---

# Architecture

```txt
                ┌──────────────────────┐
                │   Third Party APIs   │
                └──────────┬───────────┘
                           │
                    Server-side only
                           │
                ┌──────────▼───────────┐
                │    Express API       │
                │  Ingestion Layer     │
                └──────────┬───────────┘
                           │
         ┌─────────────────┼─────────────────┐
         │                                   │
┌────────▼────────┐               ┌──────────▼─────────┐
│   PostgreSQL    │               │       Redis        │
│ Normalized Data │               │  Cache + Queues    │
└────────┬────────┘               └──────────┬─────────┘
         │                                   │
         └─────────────────┬─────────────────┘
                           │
                ┌──────────▼───────────┐
                │   Next.js Frontend   │
                │     F1Pulse Web      │
                └──────────────────────┘
```

---

# Monorepo Structure

```txt
F1Pulse/
├── apps/
│   ├── web/         # Next.js 14 frontend
│   └── server/      # Express API + ingestion layer
│
├── docker-compose.yml
├── tsconfig.base.json
├── CLAUDE.md
└── README.md
```

---

# Getting Started

## Prerequisites

Make sure you have:

* Node.js ≥ 20
* pnpm ≥ 9
* Docker Desktop

Enable pnpm through Corepack:

```bash
corepack enable
```

---

# Installation

## 1. Clone the repository

```bash
git clone https://github.com/your-username/F1Pulse.git
cd F1Pulse
```

## 2. Install dependencies

```bash
pnpm install
```

## 3. Start PostgreSQL + Redis

```bash
pnpm db:up
```

## 4. Create environment files

### Windows (PowerShell)

```powershell
Copy-Item apps/server/.env.example apps/server/.env
Copy-Item apps/web/.env.example apps/web/.env.local
```

### macOS / Linux

```bash
cp apps/server/.env.example apps/server/.env
cp apps/web/.env.example apps/web/.env.local
```

## 5. Generate Prisma client

```bash
pnpm --filter @f1pulse/server db:generate
```

## 6. Start development servers

```bash
pnpm dev
```

---

# Local Development

| Service      | URL                          |
| ------------ | ---------------------------- |
| Web App      | http://localhost:3000        |
| API          | http://localhost:4000        |
| Health Check | http://localhost:4000/health |

---

# Available Scripts

## Root Scripts

| Command           | Description                     |
| ----------------- | ------------------------------- |
| `pnpm dev`        | Run frontend + backend together |
| `pnpm dev:web`    | Run frontend only               |
| `pnpm dev:server` | Run backend only                |
| `pnpm build`      | Build all apps                  |
| `pnpm lint`       | Run ESLint                      |
| `pnpm format`     | Format the codebase             |
| `pnpm db:up`      | Start PostgreSQL + Redis        |
| `pnpm db:down`    | Stop Docker services            |
| `pnpm db:reset`   | Delete database volumes         |

---

## Server Scripts

| Command                                     | Description            |
| ------------------------------------------- | ---------------------- |
| `pnpm --filter @f1pulse/server db:generate` | Generate Prisma client |
| `pnpm --filter @f1pulse/server db:migrate`  | Run Prisma migrations  |
| `pnpm --filter @f1pulse/server db:studio`   | Open Prisma Studio     |

---

# Design Goals

F1Pulse is heavily inspired by:

* Formula 1 broadcast aesthetics
* Editorial storytelling
* Motion-driven experiences
* Cinematic transitions
* High-end interactive web design

The platform prioritizes:

* Fluid animations
* Visual immersion
* Performance
* Responsive interaction
* Minimal UI clutter

---

# Performance Philosophy

* Redis cache-first strategy
* Server-side ingestion pipeline
* Optimized React rendering
* GPU-accelerated animations
* Lazy loading and streaming
* Strict TypeScript architecture
* Minimal client-side overhead

---

# Deployment

| Service  | Platform         |
| -------- | ---------------- |
| Frontend | Vercel           |
| Backend  | Railway / Fly.io |
| Media    | Cloudinary       |

---

# Roadmap

* [ ] Live telemetry overlays
* [ ] Historic season explorer
* [ ] Interactive track maps
* [ ] Driver rivalry timelines
* [ ] Pit stop visualizations
* [ ] Race replay mode
* [ ] AI-generated race insights
* [ ] Multi-language support
* [ ] PWA support

---

# License

This project is source-available for learning and portfolio purposes only.
Commercial use, redistribution, or replication of the design is not permitted without permission.

---

# Author

Built and designed by a developer passionate about Formula 1, cinematic web experiences, and modern full-stack engineering.
