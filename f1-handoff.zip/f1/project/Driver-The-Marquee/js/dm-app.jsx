/* ───────────────────────────────────────────────────────────────────────────
   dm-app.jsx — shell: chrome, theme + accent + motion tweaks, assembly.
   ─────────────────────────────────────────────────────────────────────────── */
const { useEffect: useEffectA, useState: useStateA } = React;

const DM_ACCENTS = [
  { label: 'Crimson', value: '#C9201A' },
  { label: 'Papaya',  value: '#F25C1F' },
  { label: 'Acid',    value: '#C8E000' },
  { label: 'Cobalt',  value: '#2A6FDB' },
];

const DM_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#C9201A",
  "dark": false,
  "motion": 1
}/*EDITMODE-END*/;

const SunIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
    <circle cx="12" cy="12" r="4.2" /><path d="M12 2v2.4M12 19.6V22M4.2 4.2l1.7 1.7M18.1 18.1l1.7 1.7M2 12h2.4M19.6 12H22M4.2 19.8l1.7-1.7M18.1 5.9l1.7-1.7" />
  </svg>
);
const MoonIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 14.5A8 8 0 1 1 9.5 4a6.3 6.3 0 0 0 10.5 10.5z" />
  </svg>
);

function Chrome({ dark, onToggleTheme }) {
  return (
    <div className="chrome">
      <span className="chrome__brand"><span className="dot" />F1PULSE</span>
      <span className="chrome__mono">Driver File · The Marquee</span>
      <div className="chrome__right">
        <a className="chip" href="Senna - The Pantheon.html">The Pantheon ↗</a>
        <button className="icbtn" onClick={onToggleTheme} aria-label="Toggle theme" title="Toggle light / dark">
          {dark ? <SunIcon /> : <MoonIcon />}
        </button>
      </div>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(DM_DEFAULTS);
  const accent = t.accent;

  // theme
  useEffectA(() => {
    document.documentElement.setAttribute('data-theme', t.dark ? 'dark' : 'light');
  }, [t.dark]);

  // accent → CSS var
  useEffectA(() => {
    document.documentElement.style.setProperty('--accent', accent);
  }, [accent]);

  // motion scale → primitives
  useEffectA(() => {
    window.__motionScale = t.motion;
    window.dispatchEvent(new Event('ds-motion'));
  }, [t.motion]);

  // scroll progress
  useEffectA(() => {
    const el = document.getElementById('prog');
    let raf = 0;
    const upd = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      if (el) el.style.setProperty('--p', max > 0 ? (h.scrollTop / max).toFixed(4) : 0);
      raf = 0;
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(upd); };
    upd();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); };
  }, []);

  return (
    <div>
      <Chrome dark={t.dark} onToggleTheme={() => setTweak('dark', !t.dark)} />

      <MarqueeHero accent={accent} />
      <MarqueeSections accent={accent} />

      <footer className="footer">
        <span className="lbl">F1Pulse · The Marquee · Driver File Prototype</span>
        <span className="lbl tnum">{window.DM.driver.code} / {window.DM.driver.number}</span>
      </footer>

      <TweaksPanel>
        <TweakSection label="Accent" />
        <TweakColor label="Accent" value={accent}
          options={DM_ACCENTS.map((a) => a.value)}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Theme" />
        <TweakToggle label="Dark mode" value={t.dark}
          onChange={(v) => setTweak('dark', v)} />
        <TweakSection label="Motion" />
        <TweakSlider label="Intensity" value={t.motion} min={0} max={2} step={0.1} unit="×"
          onChange={(v) => setTweak('motion', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
