/* ───────────────────────────────────────────────────────────────────────────
   dm-hero.jsx — "The Marquee" hero. Lando-style stacked wordmark + centered
   drop-in portrait + ghost number, topographic contour parallax, dossier ticket
   and signature-circuit card. Exports window.MarqueeHero.
   ─────────────────────────────────────────────────────────────────────────── */
const { useRef: useRefH, useEffect: useEffectH, useState: useStateH } = React;

/* Topographic contour field — generated smooth wavy lines (not hand-drawn art). */
function Contours() {
  const W = 1440, H = 900, lines = 17;
  const paths = [];
  for (let i = 0; i < lines; i++) {
    const baseY = 70 + (i / (lines - 1)) * (H - 140);
    const amp = 26 + 18 * Math.sin(i * 0.9);
    const ph = i * 0.7;
    let d = `M -40 ${baseY.toFixed(1)}`;
    for (let x = 0; x <= W + 40; x += 36) {
      const y = baseY + amp * Math.sin(x / 220 + ph) + 10 * Math.sin(x / 90 + ph * 1.7);
      d += ` L ${x} ${y.toFixed(1)}`;
    }
    paths.push(d);
  }
  return (
    <svg className="hero__contours" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      {paths.map((d, i) => (
        <path key={i} d={d} fill="none" stroke="currentColor" strokeWidth="1" vectorEffect="non-scaling-stroke" />
      ))}
    </svg>
  );
}

function MarqueeHero({ accent }) {
  const D = window.DM.driver;
  const motion = useMotion();
  const heroRef = useRefH(null);
  const contRef = useRefH(null);
  const ghostRef = useRefH(null);
  const portRef = useRefH(null);
  const markRef = useRefH(null);

  // pointer parallax (motion energy: max)
  useEffectH(() => {
    const hero = heroRef.current; if (!hero) return;
    let tx = 0, ty = 0, cx = 0, cy = 0, raf = 0;
    const onMove = (e) => {
      const r = hero.getBoundingClientRect();
      tx = ((e.clientX - r.left) / r.width - 0.5);
      ty = ((e.clientY - r.top) / r.height - 0.5);
    };
    const onLeave = () => { tx = 0; ty = 0; };
    const tick = () => {
      cx += (tx - cx) * 0.06; cy += (ty - cy) * 0.06;
      const m = motion;
      if (contRef.current) contRef.current.style.transform = `translate(${cx * 34 * m}px,${cy * 24 * m}px)`;
      if (ghostRef.current) ghostRef.current.style.transform = `translate(-50%,-50%) translate(${cx * -46 * m}px,${cy * -30 * m}px)`;
      if (portRef.current) portRef.current.style.transform = `translate(${cx * 20 * m}px,${cy * 12 * m}px)`;
      if (markRef.current) markRef.current.style.transform = `translate(${cx * -16 * m}px,${cy * -10 * m}px)`;
      raf = requestAnimationFrame(tick);
    };
    hero.addEventListener('pointermove', onMove, { passive: true });
    hero.addEventListener('pointerleave', onLeave);
    raf = requestAnimationFrame(tick);
    return () => { hero.removeEventListener('pointermove', onMove); hero.removeEventListener('pointerleave', onLeave); cancelAnimationFrame(raf); };
  }, [motion]);

  return (
    <section className="hero" ref={heroRef}>
      <div ref={contRef} style={{ position: 'absolute', inset: 0, zIndex: 0 }}><Contours /></div>

      {/* ghost number + portrait, centered */}
      <div className="hero__center">
        <span className="hero__ghost" ref={ghostRef}>{D.number}</span>
        <div className="hero__portrait" ref={portRef}>
          <image-slot id="marquee-portrait" shape="rounded" radius="6"
            placeholder="DROP DRIVER PORTRAIT"></image-slot>
        </div>
      </div>

      {/* wordmark */}
      <div className="hero__mark" ref={markRef}>
        <span className="hero__first" style={{ overflow: 'hidden' }}>
          <SplitReveal text={D.first} stagger={0.05} delay={0.1} />
        </span>
        <span className="hero__last">
          <SplitReveal text={D.last} stagger={0.045} delay={0.28} />
        </span>
        <span className="hero__num-badge">
          <span className="hero__num">{D.number}</span>
          <span className="hero__natline">
            <span className="rule" style={{ width: 28 }} />
            <span className="lbl">{D.code} · {D.nationality}</span>
          </span>
        </span>
      </div>

      {/* dossier ticket — bottom-left */}
      <div className="ticket hero__dossier">
        <div className="dz-top">
          <span className="lbl lbl--accent">Driver Dossier</span>
          <span className="lbl tnum">{D.code}/{D.number}</span>
        </div>
        <div className="dz-honor" style={{ marginBottom: 14 }}>{D.honor}</div>
        <div className="dz-grid">
          {D.dossier.map((row) => (
            <div className="dz-cell" key={row.k}>
              <span className="lbl">{row.k}</span>
              <b>{row.v}</b>
            </div>
          ))}
        </div>
      </div>

      {/* signature circuit card — bottom-right */}
      <div className="ticket hero__marquee">
        <div className="marq-emblem"><span>{D.marquee.circuit.slice(0, 1)}</span></div>
        <div className="marq-stat">
          <span className="lbl" style={{ marginBottom: 4 }}>{D.marquee.circuit}</span>
          <span style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <CountUp to={D.marquee.stat} duration={1.8} className="big tnum"
              style={{ fontFamily: 'var(--wide)', fontWeight: 900, fontSize: 34, lineHeight: 0.9, color: accent }} />
            <span className="lbl">{D.marquee.statLabel}</span>
          </span>
        </div>
      </div>

      <div className="scrollcue">
        <span className="lbl">Scroll</span>
        <span className="bar" />
      </div>
    </section>
  );
}

Object.assign(window, { MarqueeHero });
