/* ───────────────────────────────────────────────────────────────────────────
   dm-sections.jsx — career totals · signature giant number · season-by-season ·
   latest-season form strip. Exports window.MarqueeSections.
   ─────────────────────────────────────────────────────────────────────────── */
const { useRef: useRefS, useEffect: useEffectS, useState: useStateS } = React;

function SecHead({ n, title, right }) {
  return (
    <div className="sec-head">
      <span className="pill-dot" />
      <span className="num">{n}</span>
      <span className="ttl">{title}</span>
      <span className="ln" />
      {right && <span className="lbl">{right}</span>}
    </div>
  );
}

/* ── Career totals ──────────────────────────────────────────────────────── */
function CareerTotals({ accent }) {
  const { totals } = window.DM;
  return (
    <section className="sec" id="record">
      <div className="sec-inner">
        <SecHead n="01" title="The Record" right={window.DM.driver.span} />
        <div className="totals">
          {totals.map((s, i) => (
            <StatCell key={s.key} value={s.value} label={s.label} accent={accent} delay={i * 0.06} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StatCell({ value, label, accent, delay }) {
  const [ref, seen] = useInView({ threshold: 0.4 });
  const motion = useMotion();
  return (
    <div className="stat" ref={ref}>
      <CountUp to={value} duration={2.2} className="stat__v" />
      <div className="stat__l">
        <span className="lbl">{label}</span>
      </div>
      <div className="stat__bar" style={{
        transform: `scaleX(${seen ? 1 : 0})`,
        transition: `transform ${1 * motion}s var(--ease) ${delay * motion}s`,
      }} />
    </div>
  );
}

/* ── Signature giant number ─────────────────────────────────────────────── */
function Signature({ accent }) {
  const { signature, lapTrace } = window.DM;
  return (
    <section className="signature" id="signature">
      <div className="signature__big">
        <CountUp to={signature.value} duration={2.8} />
      </div>
      <TelemetryTrace points={lapTrace} stroke={accent} strokeWidth={2} trigger="scroll" duration={2.6}
        className="signature__trace" style={{ color: accent, width: '100%' }} />
      <div className="signature__meta">
        <span className="signature__label">{signature.label}</span>
        <p className="signature__blurb">{signature.blurb}</p>
      </div>
    </section>
  );
}

/* ── Season-by-season ───────────────────────────────────────────────────── */
function Seasons({ accent }) {
  const { seasons } = window.DM;
  const maxWins = Math.max(...seasons.map((s) => s.wins), 1);
  return (
    <section className="sec" id="seasons">
      <div className="sec-inner">
        <SecHead n="02" title="Season by Season" right={`${seasons.length} campaigns`} />
        <div>
          {seasons.map((s, i) => (
            <SeasonRow key={s.year} s={s} maxWins={maxWins} accent={accent} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function SeasonRow({ s, maxWins, accent, idx }) {
  const [ref, seen] = useInView({ threshold: 0.5 });
  const motion = useMotion();
  const pct = Math.max(0.03, s.wins / maxWins);
  return (
    <div className={`season${s.mono ? ' season--mono' : ''}`} ref={ref}>
      <span className="season__yr">{s.year}</span>
      <span className="season__team">
        <b>{s.team}</b>
        <span className="lbl">{s.car}</span>
      </span>
      <span className="season__pos" style={s.champion ? { color: accent } : {}}>{s.pos}</span>
      <span className="season__wins">
        <span className="lbl tnum" style={{ width: 54 }}>{s.wins} {s.wins === 1 ? 'win' : 'wins'}</span>
        <span className="season__bar">
          <i style={{ transform: `scaleX(${seen ? pct : 0})`, transition: `transform ${0.9 * motion}s var(--ease) ${idx * 0.04 * motion}s`, background: s.mono ? 'var(--silver)' : accent }} />
        </span>
        <span className="lbl tnum" style={{ width: 64, textAlign: 'right' }}>{s.poles} pole{s.poles === 1 ? '' : 's'}</span>
      </span>
      <span className="season__champ">
        {s.champion && <span className="star" title="World Champion">★</span>}
      </span>
    </div>
  );
}

/* ── Latest-season form strip ───────────────────────────────────────────── */
function FormStrip({ accent }) {
  const { formSeason, driver } = window.DM;
  return (
    <section className="sec" id="form" style={{ background: 'var(--paper-2)' }}>
      <div className="sec-inner">
        <SecHead n="03" title="Season Form" right={`${formSeason.year} · ${formSeason.car}`} />
        <div className="form">
          <div>
            <div className="form__strip">
              {formSeason.rounds.map((rd, i) => (
                <RoundCell key={rd.r} rd={rd} delay={i * 0.045} />
              ))}
            </div>
            <div className="form__legend">
              <span className="lg"><i style={{ background: accent }} />Win</span>
              <span className="lg"><i style={{ background: accent, opacity: 0.55 }} />Podium</span>
              <span className="lg"><i style={{ background: 'var(--ink-soft)' }} />Points</span>
              <span className="lg"><i style={{ background: 'var(--silver)' }} />DNF</span>
            </div>
          </div>
          <div>
            <span className="lbl lbl--accent">{formSeason.year} Championship</span>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, margin: '14px 0 18px' }}>
              <span style={{ fontFamily: 'var(--wide)', fontWeight: 900, fontSize: 'clamp(48px,6vw,96px)', lineHeight: 0.85, color: accent }}>{formSeason.finish}</span>
              <span className="lbl">Final<br />Standing</span>
            </div>
            <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(16px,1.6vw,23px)', lineHeight: 1.55, color: 'var(--ink-soft)', maxWidth: 420, margin: 0 }}>
              {formSeason.line}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function RoundCell({ rd, delay }) {
  const [ref, seen] = useInView({ threshold: 0.5 });
  return (
    <div className={`rnd${seen ? ' in' : ''}`} data-t={rd.type} ref={ref}
      style={{ transitionDelay: `${delay}s` }} title={`${rd.gp} — ${rd.pos === 'DNF' ? 'DNF' : 'P' + rd.pos}`}>
      <span className="rnd__dot" />
      <span className="rnd__r">{rd.r}</span>
      <span className="rnd__p">{rd.pos}</span>
    </div>
  );
}

function MarqueeSections({ accent }) {
  return (
    <>
      <CareerTotals accent={accent} />
      <Signature accent={accent} />
      <Seasons accent={accent} />
      <FormStrip accent={accent} />
    </>
  );
}

Object.assign(window, { MarqueeSections });
