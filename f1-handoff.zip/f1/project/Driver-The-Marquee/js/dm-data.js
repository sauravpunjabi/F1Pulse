/* ───────────────────────────────────────────────────────────────────────────
   dm-data.js — "The Marquee" driver-page data layer (plain global, no JSX).

   Extends the existing ds-data.js driver record with the few extra fields the
   Marquee layout needs: a dossier ticket, a signature/"marquee" circuit, and a
   single-season FORM strip. Built as a reusable template — everything the page
   renders comes from this one object, so swapping `window.DS` for another
   driver re-skins the whole page.

   Seeded with AYRTON SENNA (career aggregates are historical fact, see
   ds-data.js). The 1993 form strip below: the FIVE WINS are historical fact
   (Brazil, Donington/Europe, Monaco, Suzuka, Adelaide). Intermediate finishing
   positions are *stylised* for the visual — same convention as the lapTrace.
   ─────────────────────────────────────────────────────────────────────────── */

window.DM = (function () {
  const base = window.DS;
  const c = base.driver.career;

  const driver = Object.assign({}, base.driver, {
    // wordmark: elegant first name over heavy last name (Lando-style stack)
    teamLine: 'McLaren · Lotus · Toleman',
    honor: 'Three-Time World Champion',
    // bottom-left "dossier" ticket facts
    dossier: [
      { k: 'Born',        v: '21 Mar 1960' },
      { k: 'From',        v: 'São Paulo, BR' },
      { k: 'Active',      v: '1984 — 1994' },
      { k: 'Entries',     v: String(c.entries) },
    ],
    // signature "marquee" circuit (the Lando "NEXT RACE" card slot)
    marquee: {
      circuit: 'MONACO',
      sub: 'Circuit de Monaco',
      stat: c.monacoWins,
      statLabel: 'Victories',
      note: 'Master of the Principality',
    },
  });

  // Career totals surfaced as the big count-up grid. Order = visual priority.
  const totals = [
    { key: 'titles',   value: c.titles,   label: 'World Titles' },
    { key: 'wins',     value: c.wins,     label: 'Grand Prix Wins' },
    { key: 'poles',    value: c.poles,    label: 'Pole Positions' },
    { key: 'podiums',  value: c.podiums,  label: 'Podiums' },
    { key: 'starts',   value: c.starts,   label: 'Race Starts' },
    { key: 'points',   value: c.points,   label: 'Career Points' },
  ];

  // The one giant "signature" number that owns a full screen.
  const signature = {
    value: c.poles,
    label: 'Pole Positions',
    blurb: 'The fastest man over a single lap the sport has known — sixty-five times alone on the limit.',
  };

  // ── Single-season FORM strip — Senna's final McLaren campaign (1993, MP4/8).
  // Wins are fact; other finishes stylised. type drives the dot colour.
  const formSeason = {
    year: 1993,
    team: 'McLaren-Ford',
    car: 'MP4/8',
    finish: 'P2',
    line: 'Outgunned by Williams all year — and still the most watchable driver on the grid.',
    rounds: [
      { r: 'RSA', gp: 'South Africa', pos: '2',   type: 'podium' },
      { r: 'BRA', gp: 'Brazil',       pos: '1',   type: 'win' },
      { r: 'EUR', gp: 'Donington',    pos: '1',   type: 'win' },
      { r: 'SMR', gp: 'San Marino',   pos: 'DNF', type: 'dnf' },
      { r: 'ESP', gp: 'Spain',        pos: '2',   type: 'podium' },
      { r: 'MON', gp: 'Monaco',       pos: '1',   type: 'win' },
      { r: 'CAN', gp: 'Canada',       pos: 'DNF', type: 'dnf' },
      { r: 'FRA', gp: 'France',       pos: '4',   type: 'points' },
      { r: 'GBR', gp: 'Britain',      pos: '5',   type: 'points' },
      { r: 'GER', gp: 'Germany',      pos: '4',   type: 'points' },
      { r: 'HUN', gp: 'Hungary',      pos: 'DNF', type: 'dnf' },
      { r: 'BEL', gp: 'Belgium',      pos: '4',   type: 'points' },
      { r: 'ITA', gp: 'Italy',        pos: 'DNF', type: 'dnf' },
      { r: 'POR', gp: 'Portugal',     pos: 'DNF', type: 'dnf' },
      { r: 'JPN', gp: 'Japan',        pos: '1',   type: 'win' },
      { r: 'AUS', gp: 'Australia',    pos: '1',   type: 'win' },
    ],
  };

  return {
    driver,
    totals,
    signature,
    formSeason,
    seasons: base.seasons,
    lapTrace: base.lapTrace,
    teamColors: base.teamColors,
  };
})();
