/* ───────────────────────────────────────────────────────────────────────────
   ds-data.js — Driver story data layer (plain global, no JSX).

   Illustrative content for the F1Pulse redesign prototype. Subject: AYRTON
   SENNA — chosen because every figure here is settled historical fact (not
   live race data), so it is safe and trustworthy for die-hard fans, and it
   threads directly into History Mode + the Senna/Prost rivalry already in the
   codebase. Numbers below are career-accurate.
   ─────────────────────────────────────────────────────────────────────────── */

window.DS = (function () {
  const driver = {
    code: 'SEN',
    number: '12',
    first: 'AYRTON',
    last: 'SENNA',
    full: 'Ayrton Senna da Silva',
    nationality: 'Brazil',
    birthplace: 'São Paulo, Brazil',
    born: '21 March 1960',
    span: '1984 — 1994',
    epitaph: 'Three-time World Champion. Sixty-five poles. The fastest man over one lap the sport has known.',
    // Career aggregate — all historical fact
    career: {
      titles: 3,
      wins: 41,
      poles: 65,
      podiums: 80,
      starts: 161,
      entries: 162,
      fastestLaps: 19,
      points: 614,
      monacoWins: 6,
      frontRows: 87,
      lapsLed: 2982,
    },
  };

  // Season-by-season. team key drives the color + the B&W→color History Mode.
  // 'mono' eras (Toleman/Lotus) render desaturated until the 1988 title floods colour.
  const seasons = [
    { year: 1984, team: 'Toleman',  car: 'TG184',     teamKey: 'toleman', pos: 'P9',  points: 13, wins: 0, poles: 0,  fl: 0, note: 'Monaco, in the rain — a debut that announced a genius.', mono: true },
    { year: 1985, team: 'Lotus',    car: '97T',       teamKey: 'lotus',   pos: 'P4',  points: 38, wins: 2, poles: 7,  fl: 3, note: 'First win at Estoril, leading by over a minute in a storm.', mono: true },
    { year: 1986, team: 'Lotus',    car: '98T',       teamKey: 'lotus',   pos: 'P4',  points: 55, wins: 2, poles: 8,  fl: 0, note: 'Eight poles. The qualifying legend takes hold.', mono: true },
    { year: 1987, team: 'Lotus',    car: '99T',       teamKey: 'lotus',   pos: 'P3',  points: 57, wins: 2, poles: 1,  fl: 3, note: 'A first Monaco victory. The throne is found.', mono: true },
    { year: 1988, team: 'McLaren',  car: 'MP4/4',     teamKey: 'mclaren', pos: 'P1',  points: 90, wins: 8, poles: 13, fl: 3, note: 'McLaren-Honda. Eight wins, thirteen poles, a first crown.', champion: true, flood: true },
    { year: 1989, team: 'McLaren',  car: 'MP4/5',     teamKey: 'mclaren', pos: 'P2',  points: 60, wins: 6, poles: 13, fl: 3, note: 'Suzuka. The collision. A rivalry becomes a war.' },
    { year: 1990, team: 'McLaren',  car: 'MP4/5B',    teamKey: 'mclaren', pos: 'P1',  points: 78, wins: 6, poles: 10, fl: 2, note: 'Suzuka, turn one — the title reclaimed on his terms.', champion: true },
    { year: 1991, team: 'McLaren',  car: 'MP4/6',     teamKey: 'mclaren', pos: 'P1',  points: 96, wins: 7, poles: 8,  fl: 2, note: 'A third title. Victory at home, Interlagos, stuck in sixth gear.', champion: true },
    { year: 1992, team: 'McLaren',  car: 'MP4/7A',    teamKey: 'mclaren', pos: 'P4',  points: 50, wins: 3, poles: 1,  fl: 2, note: 'Outgunned by Williams, yet Monaco is his — a sixth time.' },
    { year: 1993, team: 'McLaren',  car: 'MP4/8',     teamKey: 'mclaren', pos: 'P2',  points: 73, wins: 5, poles: 1,  fl: 1, note: 'Donington, the lap of the gods — five places on lap one.' },
    { year: 1994, team: 'Williams', car: 'FW16',      teamKey: 'williams',pos: '—',   points: 0,  wins: 0, poles: 3,  fl: 0, note: 'Three poles, no flags. Imola, 1 May. The sport stood still.', requiem: true },
  ];

  // A single qualifying lap trace — Monaco, normalized 0..1 speed over the lap.
  // Stylised telemetry for the signature "fastest over one lap" moment.
  const lapTrace = [
    0.62, 0.95, 0.98, 0.40, 0.28, 0.66, 0.88, 0.52, 0.30, 0.34,
    0.74, 0.92, 0.99, 0.58, 0.33, 0.30, 0.70, 0.86, 0.96, 0.44,
    0.26, 0.48, 0.82, 0.97, 0.60, 0.35, 0.55, 0.90, 1.00, 0.72,
  ];

  // Era bands the career spans — feeds the History Mode context strip.
  const eras = [
    { key: 'turbo', label: 'Turbo Wars',    years: '1983–1988', accent: '#C9A24B' },
    { key: 'v10',   label: 'The V10 Era',   years: '1989–2005', accent: '#C9201A' },
  ];

  // Team cosmetic colours (brand colours are allowed local constants).
  const teamColors = {
    toleman:  '#1B4D8C',
    lotus:    '#0B5C2E',
    mclaren:  '#C9201A',
    williams: '#0A2A6B',
  };

  return { driver, seasons, lapTrace, eras, teamColors };
})();
