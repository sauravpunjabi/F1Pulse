/* ───────────────────────────────────────────────────────────────────────────
   hm-ignite.jsx — 1967, THE signature moment. The page pins. The world is
   still silver. A target asks you to PRESS & HOLD — and as you hold, you
   physically drag colour into existence: desaturation lifts, the swatches
   bloom, the engine swells, the film catches fire. Release early and it ebbs
   back (tension). Hold to full and colour LOCKS — the world is colour forever.
   Writes HM.state.hold / .ignited / .holdRpm; the master controller in hm-app
   reads those to drive the page-wide filter + red flash. Exports window.Ignite.
   ─────────────────────────────────────────────────────────────────────────── */
const { useState: useStateIg, useEffect: useEffectIg, useRef: useRefIg } = React;

const HOLD_SECONDS = 1.5;     // press duration to full ignition
const EBB_SECONDS = 0.6;      // release recovery time

function Ignite({ accent }) {
  const d = window.HM.ignite;
  const [ignited, setIgnited] = useStateIg(false);
  const ignitedRef = useRefIg(false);
  const holdingRef = useRefIg(false);
  const valRef = useRefIg(0);         // 0..1 current hold value
  const secRef = useRefIg(null);
  const ringRef = useRefIg(null);
  const targetRef = useRefIg(null);
  const swRef = useRefIg([]);

  const R = 78, C = 2 * Math.PI * R;

  const doIgnite = () => {
    if (ignitedRef.current) return;
    ignitedRef.current = true;
    setIgnited(true);
    valRef.current = 1;
    window.HM.state.hold = 1;
    window.HM.state.ignited = true;
    window.HM.audio.ignite();
  };

  useEffectIg(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    swRef.current = secRef.current ? Array.from(secRef.current.querySelectorAll('[data-swatch]')) : [];
    if (reduced) { doIgnite(); return; }

    const tick = ({ dt }) => {
      const sec = secRef.current;
      if (!ignitedRef.current) {
        // ease hold value toward target
        const target = holdingRef.current ? 1 : 0;
        const rate = holdingRef.current ? dt / HOLD_SECONDS : -dt / EBB_SECONDS;
        valRef.current = Math.max(0, Math.min(1, valRef.current + (target > valRef.current ? Math.abs(rate) : -Math.abs(rate))));
        window.HM.state.hold = valRef.current;
        window.HM.state.holdRpm = valRef.current;
        if (ringRef.current) ringRef.current.style.strokeDashoffset = (C * (1 - valRef.current)).toFixed(1);
        const sc = (0.45 + valRef.current * 0.55).toFixed(3);
        for (const s of swRef.current) s.style.transform = `scaleY(${sc})`;
        if (valRef.current >= 0.999) doIgnite();

        // safety net: if scrolled most of the way through without holding, ignite
        if (sec) {
          const r = sec.getBoundingClientRect();
          const travel = sec.offsetHeight - window.innerHeight;
          const p = travel > 0 ? Math.min(1, Math.max(0, -r.top / travel)) : 0;
          if (p > 0.82) doIgnite();
        }
      } else {
        window.HM.state.holdRpm = Math.max(0, window.HM.state.holdRpm - dt * 0.6);
      }
    };
    const off = window.HM.frame.add(tick);
    return off;
  }, []);

  const start = (e) => {
    if (ignitedRef.current) return;
    e.preventDefault();
    holdingRef.current = true;
    targetRef.current && targetRef.current.classList.add('is-holding');
    if (!window.HM.audio.enabled) { /* silent unless opted in */ }
  };
  const end = () => {
    holdingRef.current = false;
    targetRef.current && targetRef.current.classList.remove('is-holding');
  };

  useEffectIg(() => {
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
    return () => { window.removeEventListener('pointerup', end); window.removeEventListener('pointercancel', end); };
  }, []);

  return (
    <section ref={secRef} id="sec-1967" className="ignite" data-screen-label="1967 · Colour Arrives">
      <div className="ignite__pin">
        <span className="ignite__ghost">{d.year}</span>

        {/* PRE — silver world, press & hold */}
        <div className="ignite__pre" style={{ opacity: ignited ? 0 : 1, transform: ignited ? 'scale(0.98)' : 'none' }}>
          <span className="mono-tick ignite__yr" style={{ color: accent }}>{d.year}</span>
          <h2 className="ignite__title">
            {d.pre.map((l, i) => <span key={i}>{l}</span>)}
          </h2>

          <div className="ignite__swatches">
            {d.swatches.map((c, i) => (
              <span key={i} data-swatch style={{ background: c }} />
            ))}
          </div>

          <div
            ref={targetRef}
            className="hold"
            onPointerDown={start}
            role="button"
            tabIndex={0}
            aria-label="Press and hold to ignite colour"
          >
            <svg className="hold__ring" viewBox="0 0 180 180">
              <circle className="hold__track" cx="90" cy="90" r={R} />
              <circle ref={ringRef} className="hold__bar" cx="90" cy="90" r={R}
                      style={{ stroke: accent, strokeDasharray: C, strokeDashoffset: C }} />
            </svg>
            <span className="hold__core">
              <span className="hold__dot" style={{ background: accent }} />
              <span className="hold__lbl">HOLD</span>
            </span>
          </div>

          <div className="ignite__prompt">
            <span className="hair" /><span className="mono-tick">{d.prompt}</span><span className="hair" />
          </div>
        </div>

        {/* POST — colour arrives */}
        <div className="ignite__post" style={{ opacity: ignited ? 1 : 0, transform: ignited ? 'none' : 'translateY(20px)' }}>
          <h2 className="ignite__venue">
            <SplitReveal text={d.venue} stagger={0.03} trigger={ignited ? 'mount' : 'scroll'} />
          </h2>
          <span className="mono-tick" style={{ color: accent, letterSpacing: '0.35em' }}>{d.year} — THE MOMENT COLOUR ARRIVED</span>
          <p className="ignite__caption">{d.caption}</p>
          <span className="ignite__again">↓ keep descending — the colour only deepens</span>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Ignite });
