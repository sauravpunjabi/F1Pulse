/* ============================================================================
   F1Pulse — Circuit feature · Autodromo Nazionale Monza
   A refined, recognisable Monza silhouette (long main straight on the left,
   the Parabolica sweeping back at the bottom) + named corner complexes,
   sector character and telemetry meta. Coordinates in a normalised 0..100 box.
   ========================================================================== */
window.MONZA = {
  r: 15, gp: "Italian Grand Prix", circuit: "Autodromo Nazionale Monza",
  city: "Monza", country: "Italy", cc: "ITA", date: "September 6", dateShort: "SEP 06",
  region: "Europe", type: "Permanent", nation: "Italia",
  len: 5.793, corners: 11, laps: 53, dist: 306.7, record: "1:21.046",
  recordBy: "R. Barrichello", recordYear: 2004, firstHeld: 1950, built: 1922,
  drs: 2, topSpeed: 366, fullThrottle: 79, gearShifts: 42,
  lat: 45.62, lon: 9.28, elevation: 162, nearest: "Milano · 15 km",
  sectors: [0.31, 0.66],
  tag: "The Temple of Speed",
  beat: "The fastest permanent circuit on the calendar. Lowest downforce of the year, 360 km/h on the straights, and the tifosi turning the grandstands red. Monza is racing reduced to its purest equation — top speed and bravery.",
  lede: "Twenty-two corners cut to eleven, four of them chicanes, the rest taken flat. A 1.1-kilometre pit straight, the longest full-throttle stretches in Formula One, and the oldest grandstands in the sport. This is the lap that has decided more Italian afternoons than any other.",

  /* refined Monza loop — clockwise from the start/finish line (bottom-left of
     the main straight), up the straight, through the two top chicanes, down
     the right through Lesmo and Ascari, then the Parabolica back to the line. */
  P: [
    [20, 75],   // 0  start / finish — main straight (lower)
    [20, 57],   // 1  main straight
    [20.5, 41], // 2  main straight
    [21.5, 31], // 3  braking zone into Rettifilo
    [26, 25],   // 4  Variante del Rettifilo — apex 1
    [31, 27],   // 5  Variante del Rettifilo — apex 2
    [44, 22],   // 6  Curva Grande — entry
    [55, 22],   // 7  Curva Grande — exit / approach Roggia
    [62, 27],   // 8  Variante della Roggia — in
    [58.5, 32], // 9  Variante della Roggia — out
    [67, 36],   // 10 Curva di Lesmo 1
    [71, 45],   // 11 Curva di Lesmo 2
    [67, 55],   // 12 Curva del Serraglio — back straight
    [64, 63],   // 13 approach Ascari
    [60, 67],   // 14 Variante Ascari — left
    [55.5, 65], // 15 Variante Ascari — right
    [58, 72],   // 16 Variante Ascari — exit
    [50, 79],   // 17 straight down to Parabolica
    [38, 83],   // 18 Curva Parabolica — entry
    [27, 81],   // 19 Curva Parabolica — mid
    [21, 76]    // 20 Curva Parabolica — exit onto main straight
  ],

  /* named corner complexes, placed by fraction-of-lap (0..1, clockwise).
     `t` is tuned to land each marker on its feature along the smoothed path. */
  corners: [
    { n: 1, name: "Variante del Rettifilo", turns: "T1–2", kind: "Chicane", t: 0.205,
      gear: "2nd", speed: 86,
      note: "The first chicane and the heaviest braking zone in Formula One — 340 km/h down to 86 in under 130 metres. Lock a wheel here and the lap is gone before it began." },
    { n: 2, name: "Curva Grande", turns: "T3", kind: "Flat-out", t: 0.31,
      gear: "8th", speed: 318,
      note: "A vast right-hand sweep taken flat in top gear. The cars barely breathe off the throttle — it is a straight that happens to bend." },
    { n: 3, name: "Variante della Roggia", turns: "T4–5", kind: "Chicane", t: 0.405,
      gear: "3rd", speed: 132,
      note: "The best overtaking spot on the lap. A long approach and a tight left-right invite the late lunge down the inside — and the occasional trip across the kerbs." },
    { n: 4, name: "Curve di Lesmo", turns: "T6–7", kind: "Quick right", t: 0.505,
      gear: "5th", speed: 214,
      note: "Two fast, blind right-handers in quick succession. Commitment is everything; the smallest lift bleeds speed all the way down the back straight." },
    { n: 5, name: "Curva del Serraglio", turns: "—", kind: "Full throttle", t: 0.60,
      gear: "8th", speed: 330,
      note: "Not a corner so much as a flat-out rush beneath the bridge of the old banking — the ghost of Monza's terrifying high-speed oval still looming overhead." },
    { n: 6, name: "Variante Ascari", turns: "T8–10", kind: "Chicane", t: 0.71,
      gear: "4th", speed: 196,
      note: "Named for Alberto Ascari. A flowing left-right-left at over 200 km/h — the lap's true examination of rhythm, where a perfect entry carries all the way to Parabolica." },
    { n: 7, name: "Curva Parabolica", turns: "T11", kind: "Long right", t: 0.895,
      gear: "4th→7th", speed: 215,
      note: "The legendary, endless right-hander now named for Michele Alboreto. Get on the power a fraction early and you win the 1.1 km main straight that follows. Get it wrong and you lose the lap." }
  ],

  /* the three sectors — character notes for the editorial breakdown */
  sectorMeta: [
    { id: "S1", color: "var(--accent)", name: "The Plunge", frac: [0, 0.31],
      blurb: "From the lights, the longest straight on the calendar funnels into the Rettifilo's brutal stop. Curva Grande then opens flat-out — heart-rate and top speed, all at once." },
    { id: "S2", color: "#E0A33A", name: "The Spine", frac: [0.31, 0.66],
      blurb: "Roggia, the Lesmos and the run to Ascari form the technical heart of the lap. This is where a balanced car carries minimum speed and where places change hands." },
    { id: "S3", color: "#3FA8C4", name: "The Release", frac: [0.66, 1],
      blurb: "Ascari flows into the long blast to Parabolica — the corner that defines the lap. Exit speed here echoes the whole way down the pit straight to the line." }
  ]
};
