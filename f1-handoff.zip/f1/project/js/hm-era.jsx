/* ───────────────────────────────────────────────────────────────────────────
   hm-era.jsx — one reusable cinematic era chapter, data-driven from HM.eras.
   Parallax ghost year (subscribes to HM.frame), hover ken-burns plate, and
   staggered scroll reveals for title / lede / facts / pull quote.
   Exports window.EraChapter.
   ─────────────────────────────────────────────────────────────────────────── */
const { useEffect: useEffectEra, useRef: useRefEra } = React;

function EraPlate({ era }) {
  const warm = era.colour > 0 && era.colour < 0.85;
  const stripe = `repeating-linear-gradient(125deg, ${era.bg} 0 15px, color-mix(in srgb, ${era.bg} 86%, #fff) 15px 30px)`;
  return (
    <div className="chapter__media">
      <figure className="plate" style={{ aspectRatio: '4 / 3', background: stripe }}>
        <div className="plate__img" style={{ backgroundImage: `linear-gradient(135deg, ${era.bg}, color-mix(in srgb, ${era.accent} 22%, ${era.bg}))` }} />
        <div className="plate__scan" />
        <div className="plate__inner">
          <span className="plate__mark">▢ archival plate · drop photo</span>
          <span className="plate__label">{era.plate}</span>
        </div>
        <span className="plate__corner plate__corner--tl" style={{ borderColor: `${era.accent}` }} />
        <span className="plate__corner plate__corner--br" style={{ borderColor: `${era.accent}` }} />
      </figure>
      <span className="plate__cap mono-tick">{era.plate}</span>
    </div>
  );
}

function FactRow({ facts, accent }) {
  return (
    <div className="facts">
      {facts.map((f, i) => {
        const [ref, seen] = useInView({ threshold: 0.5 });
        return (
          <div key={f.k} ref={ref} className="facts__cell" style={{ opacity: seen ? 1 : 0, transform: seen ? 'none' : 'translateY(16px)', transition: `opacity .6s ease ${i * 0.08}s, transform .7s cubic-bezier(0.16,1,0.3,1) ${i * 0.08}s` }}>
            <span className="facts__v">{f.v}</span>
            <span className="facts__k" style={{ color: accent }}>{f.k}</span>
          </div>
        );
      })}
    </div>
  );
}

function EraChapter({ era }) {
  const ghostRef = useRefEra(null);
  const secRef = useRefEra(null);

  // Parallax: the giant ghost year drifts against scroll.
  useEffectEra(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;
    const tick = () => {
      const sec = secRef.current, g = ghostRef.current;
      if (!sec || !g) return;
      const r = sec.getBoundingClientRect();
      const vh = window.innerHeight;
      // -1 (below) .. +1 (above) centred at viewport middle
      const rel = (r.top + r.height / 2 - vh / 2) / vh;
      g.style.transform = `translateY(calc(-50% + ${(-rel * 90).toFixed(1)}px))`;
    };
    const off = window.HM.frame.add(tick);
    return off;
  }, []);

  const Lead = (
    <div className="chapter__lead">
      <h2 className="chapter__title" style={{ color: era.colour > 0 ? era.accent : '#cfcdc7' }}>
        <SplitReveal text={era.title} stagger={0.035} trigger="scroll" />
      </h2>
      <p className="chapter__lede">{era.lede}</p>
      <FactRow facts={era.facts} accent={era.accent} />
    </div>
  );

  return (
    <section ref={secRef} id={era.id} className="chapter" data-screen-label={era.title} style={{ '--accent': era.accent }}>
      <div className="chapter__head">
        <span className="chapter__num" style={{ color: era.colour > 0 ? era.accent : undefined }}>{era.num}</span>
        <span className="mono-tick">{era.range}</span>
        <span className="mono-tick" style={{ color: era.colour > 0 ? era.accent : undefined }}>{era.tag}</span>
      </div>

      <div className={`chapter__grid${era.reverse ? ' chapter__grid--rev' : ''}`}>
        {era.reverse ? <><EraPlate era={era} />{Lead}</> : <>{Lead}<EraPlate era={era} /></>}
      </div>

      <div className="chapter__pull">
        <span ref={ghostRef} className="bignum bignum--ghost" style={era.colour > 0.75 ? { color: `${era.accent}1f` } : undefined}>{era.ghost}</span>
        <p className="pull" style={{ color: era.colour > 0.5 ? '#efe7da' : undefined }}>“{era.pull}”</p>
      </div>
    </section>
  );
}

Object.assign(window, { EraChapter, EraPlate });
