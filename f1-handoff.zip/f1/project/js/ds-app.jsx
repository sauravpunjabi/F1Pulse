/* ───────────────────────────────────────────────────────────────────────────
   ds-app.jsx — shell: direction switcher, tweaks, atmosphere, assembly.
   ─────────────────────────────────────────────────────────────────────────── */
const { useState: useStateApp, useEffect: useEffectApp } = React;

const ACCENTS = [
  { key: 'crimson', label: 'Crimson', value: '#C9201A' },
  { key: 'green',   label: 'Senna',   value: '#00D449' },
  { key: 'cyan',    label: 'Neon',    value: '#16E0C8' },
  { key: 'gold',    label: 'Gold',    value: '#C9A24B' },
];

const DIRECTIONS = [
  { key: 'broadcast', label: 'Broadcast' },
  { key: 'archive',   label: 'Archive' },
  { key: 'telemetry', label: 'Telemetry' },
];

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "direction": "broadcast",
  "accent": "#C9201A",
  "grain": 0.06,
  "vignette": 0.36,
  "motion": 1
}/*EDITMODE-END*/;

function DirectionSwitcher({ value, onChange, accent }) {
  return (
    <div className="dirswitch">
      <span className="dirswitch__brand">F1PULSE</span>
      <div className="dirswitch__seg">
        {DIRECTIONS.map((d) => (
          <button key={d.key} onClick={() => onChange(d.key)}
            className={value === d.key ? 'is-active' : ''}
            style={value === d.key ? { color: '#0a0a0b', background: accent } : {}}>
            {d.label}
          </button>
        ))}
      </div>
      <span className="dirswitch__tag">Driver Story · Senna</span>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // keep global motion scale in sync (lower value = faster)
  useEffectApp(() => {
    window.__motionScale = t.motion;
    window.dispatchEvent(new Event('ds-motion'));
  }, [t.motion]);

  const accent = t.accent;
  const dir = t.direction;

  // expose accent as CSS var for any CSS hooks
  useEffectApp(() => {
    document.documentElement.style.setProperty('--accent', accent);
  }, [accent]);

  return (
    <div data-dir={dir} style={{ '--accent': accent }}>
      <DirectionSwitcher value={dir} onChange={(v) => setTweak('direction', v)} accent={accent} />

      <DriverHero dir={dir} accent={accent} />
      <DriverStats dir={dir} accent={accent} />
      <DriverTimeline dir={dir} accent={accent} />

      <footer className="ds-footer">
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.3em', color: 'rgba(245,244,240,0.35)' }}>F1PULSE · THE PANTHEON · PROTOTYPE</span>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.3em', color: 'rgba(245,244,240,0.35)' }}>{DIRECTIONS.find((d) => d.key === dir).label.toUpperCase()} DIRECTION</span>
      </footer>

      <Grain grain={t.grain} vignette={t.vignette} />

      <TweaksPanel>
        <TweakSection label="Art Direction" />
        <TweakRadio label="Direction" value={dir}
          options={DIRECTIONS.map((d) => d.key)}
          onChange={(v) => setTweak('direction', v)} />
        <TweakSection label="Accent" />
        <TweakColor label="Accent" value={accent}
          options={ACCENTS.map((a) => a.value)}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Atmosphere" />
        <TweakSlider label="Grain" value={t.grain} min={0} max={0.16} step={0.01}
          onChange={(v) => setTweak('grain', v)} />
        <TweakSlider label="Vignette" value={t.vignette} min={0} max={0.7} step={0.02}
          onChange={(v) => setTweak('vignette', v)} />
        <TweakSection label="Motion" />
        <TweakSlider label="Speed" value={t.motion} min={0.5} max={2} step={0.1} unit="×"
          onChange={(v) => setTweak('motion', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
