/* ============================================================================
   F1Pulse — Circuits · The Grand Tour · page choreography
   Atlas navigator · scroll-scrubbed track grid · hot-lap dossier · filters.
   Loads after engine.js (window.F1) and circuits-data.js (window.CIRCUITS).
   ========================================================================== */
(function () {
  'use strict';
  const C = window.CIRCUITS || [];
  const F1 = window.F1 || { onFrame: () => {} };
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const root = document.documentElement;
  const SVGNS = 'http://www.w3.org/2000/svg';
  const NEXT_ROUND = 8; // Monaco — matches the homepage "next lights-out"
  // rounds that have a dedicated full-page circuit feature
  const CIRCUIT_PAGES = { 15: 'Circuit - Monza.html' };

  /* ── Catmull-Rom → closed bezier (matches homepage technique) ──────────── */
  function smooth(p, mul) {
    const m = mul || 1, n = p.length;
    let d = `M ${(p[0][0]*m).toFixed(2)} ${(p[0][1]*m).toFixed(2)} `;
    for (let i = 0; i < n; i++) {
      const a = p[(i-1+n)%n], b = p[i], c = p[(i+1)%n], e = p[(i+2)%n];
      const c1x=(b[0]+(c[0]-a[0])/6)*m, c1y=(b[1]+(c[1]-a[1])/6)*m;
      const c2x=(c[0]-(e[0]-b[0])/6)*m, c2y=(c[1]-(e[1]-b[1])/6)*m;
      d += `C ${c1x.toFixed(2)} ${c1y.toFixed(2)}, ${c2x.toFixed(2)} ${c2y.toFixed(2)}, ${(c[0]*m).toFixed(2)} ${(c[1]*m).toFixed(2)} `;
    }
    return d + 'Z';
  }
  const el = (tag, cls, attrs) => {
    const e = document.createElementNS(SVGNS, tag);
    if (cls) e.setAttribute('class', cls);
    if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  };
  function recordSeconds(rec) {
    const m = /(\d+):(\d+)\.(\d+)/.exec(rec || '');
    if (!m) return 92.0;
    return parseInt(m[1],10)*60 + parseInt(m[2],10) + parseInt(m[3],10)/1000;
  }
  function fmtLap(s) {
    const mm = Math.floor(s/60), ss = Math.floor(s%60), ms = Math.round((s - Math.floor(s))*1000);
    return `${mm}:${String(ss).padStart(2,'0')}.${String(ms).padStart(3,'0')}`;
  }
  function fmtSec(s) { return s.toFixed(3); }

  /* ── HERO ghost track ──────────────────────────────────────────────────── */
  (function () {
    const svg = document.getElementById('hero-ghost'); if (!svg) return;
    const P = [[120,210],[150,150],[210,110],[300,96],[400,104],[470,130],[510,180],[492,236],[420,256],[360,228],[320,262],[300,318],[250,330],[190,308],[150,272],[128,240]];
    const d = smooth(P, 1);
    const base = el('path', 'gline', { d }); svg.appendChild(base);
    const dash = el('path', 'gdash', { d }); svg.appendChild(dash);
  })();

  /* ── GLOBE · interactive 3D atlas (drag · detailed continents · borders) ── */
  const pinByRound = {};
  (function () {
    const stage = document.getElementById('globe');
    const svg = document.getElementById('globe-svg');
    if (!stage || !svg || !window.d3) return;
    const d3 = window.d3;
    const S = 640, R = 300, CX = S/2, CY = S/2;
    svg.setAttribute('viewBox', `0 0 ${S} ${S}`);

    const proj = d3.geoOrthographic().scale(R).translate([CX, CY]).rotate([-18, -22]).clipAngle(90);
    const path = d3.geoPath(proj);
    const gratMinor = d3.geoGraticule().step([15, 15])();
    const gratMajor = d3.geoGraticule().step([90, 90])();

    // atmosphere halo (blurred accent rim) sits behind the sphere
    const atmo = el('circle', 'g-atmo', { cx:CX, cy:CY, r:R });
    const sphere = el('path', 'g-sphere');
    const gratMaj = el('path', 'g-grat--maj');
    const grat = el('path', 'g-grat');
    const land = el('path', 'g-land');
    const borders = el('path', 'g-borders');
    svg.appendChild(atmo); svg.appendChild(sphere); svg.appendChild(grat); svg.appendChild(gratMaj);
    svg.appendChild(land); svg.appendChild(borders);
    // style atmosphere + sphere via CSS-friendly inline (respects --accent)
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#C9201A';
    atmo.style.fill = 'none'; atmo.style.stroke = accent; atmo.style.strokeWidth = '3';
    atmo.style.opacity = '0.16'; atmo.style.filter = 'blur(7px)';
    sphere.style.filter = 'drop-shadow(0 16px 28px rgba(20,17,14,0.28))';

    let landLow = null, landHigh = null, bordersMesh = null;

    // pins
    const tip = document.getElementById('atlas-tip');
    const pinG = el('g'); svg.appendChild(pinG);
    const items = [];
    [...C].sort((a,b) => a.r - b.r).forEach((c) => {
      const g = el('g', 'g-pin' + (c.r === NEXT_ROUND ? ' next' : ''));
      g.appendChild(el('circle', 'g-pin__ring', { r:8 }));
      g.appendChild(el('circle', 'g-pin__dot', { r:4 }));
      g.appendChild(el('circle', 'g-pin__hit', { r:15 }));
      pinG.appendChild(g);
      pinByRound[c.r] = g;
      const it = { c, g, ll:[c.lon, c.lat] };
      items.push(it);
      const show = () => {
        g.classList.add('hot');
        const card = cardByRound[c.r]; if (card) card.classList.add('hot');
        const d = smooth(c.P, 1);
        tip.innerHTML =
          `<div class="atlas__tip__track">
             <span class="tt-cc">${c.cc}</span>
             <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
               <path class="tt-base" d="${d}"></path>
               <path class="tt-line" d="${d}"></path>
               <circle class="tt-sf" r="2.2"></circle>
             </svg>
           </div>
           <div class="atlas__tip__meta">
             <div class="rd">Round ${String(c.r).padStart(2,'0')} · ${c.region}</div>
             <div class="nm">${c.city}</div>
             <div class="dt">${c.circuit} — ${c.dateShort}</div>
           </div>`;
        // animate the track drawing itself
        const line = tip.querySelector('.tt-line'), sfd = tip.querySelector('.tt-sf');
        const L = line.getTotalLength();
        const p0 = line.getPointAtLength(0); sfd.setAttribute('cx', p0.x); sfd.setAttribute('cy', p0.y);
        if (!reduced) {
          line.style.strokeDasharray = `${L}`; line.style.strokeDashoffset = `${L}`;
          line.getBoundingClientRect();
          line.style.transition = 'stroke-dashoffset 0.85s cubic-bezier(0.16,1,0.3,1)';
          requestAnimationFrame(() => { line.style.strokeDashoffset = '0'; });
        }
        const fr = stage.getBoundingClientRect(), pr = g.getBoundingClientRect();
        tip.style.left = (pr.left - fr.left + pr.width/2) + 'px';
        tip.style.top = (pr.top - fr.top) + 'px';
        tip.classList.add('on');
      };
      const hide = () => {
        if (c.r !== NEXT_ROUND) g.classList.remove('hot');
        const card = cardByRound[c.r]; if (card) card.classList.remove('hot');
        tip.classList.remove('on');
      };
      g.addEventListener('pointerenter', show);
      g.addEventListener('pointerleave', hide);
      g.addEventListener('click', (e) => { e.stopPropagation(); if (!dragMoved) openFocus(c.r); });
    });

    function render(fast) {
      sphere.setAttribute('d', path({ type:'Sphere' }) || '');
      grat.setAttribute('d', path(gratMinor) || '');
      gratMaj.setAttribute('d', path(gratMajor) || '');
      const lf = (fast ? landLow : landHigh) || landLow || landHigh;
      if (lf) land.setAttribute('d', path(lf) || '');
      if (!fast && bordersMesh) borders.setAttribute('d', path(bordersMesh) || '');
      else if (fast) borders.setAttribute('d', '');
      const rot = proj.rotate(); const center = [-rot[0], -rot[1]];
      for (const it of items) {
        const dist = d3.geoDistance(it.ll, center);
        if (dist > Math.PI/2 - 0.02) { it.g.style.display = 'none'; continue; }
        it.g.style.display = '';
        const p = proj(it.ll);
        it.g.setAttribute('transform', `translate(${p[0].toFixed(1)} ${p[1].toFixed(1)})`);
        const fade = Math.max(0.18, Math.min(1, (Math.PI/2 - dist) / 0.42));
        it.g.style.opacity = fade.toFixed(2);
      }
    }

    // drag to rotate freely (low-detail while moving, high-detail on release)
    let dragging = false, dragMoved = false, lx = 0, ly = 0, settle = null;
    const k = 0.34;
    stage.addEventListener('pointerdown', (e) => {
      dragging = true; dragMoved = false; lx = e.clientX; ly = e.clientY;
      try { stage.setPointerCapture(e.pointerId); } catch (_) {}
      tip.classList.remove('on');
    });
    stage.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
      if (Math.abs(dx) + Math.abs(dy) > 2) dragMoved = true;
      const r = proj.rotate();
      let nlat = r[1] - dy * k; nlat = Math.max(-90, Math.min(90, nlat));
      proj.rotate([r[0] + dx * k, nlat]);
      render(true);
    });
    const endDrag = () => {
      dragging = false;
      clearTimeout(settle); settle = setTimeout(() => render(false), 60);
      setTimeout(() => { dragMoved = false; }, 0);
    };
    stage.addEventListener('pointerup', endDrag);
    stage.addEventListener('pointercancel', endDrag);

    render(false);
    // detailed world data: 50m coastlines + interior country borders, with 110m fallback for drag
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json')
      .then((r) => r.json())
      .then((topo) => { if (window.topojson) { landLow = topojson.feature(topo, topo.objects.land); render(false); } })
      .catch(() => {});
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json')
      .then((r) => r.json())
      .then((topo) => {
        if (!window.topojson) return;
        landHigh = topojson.feature(topo, topo.objects.countries);
        bordersMesh = topojson.mesh(topo, topo.objects.countries, (a, b) => a !== b);
        render(false);
      })
      .catch(() => {});
  })();

  /* ── CALENDAR GRID ─────────────────────────────────────────────────────── */
  const cardByRound = {};
  const cardAnim = []; // {card, line, base, L, car, sf}
  (function () {
    const grid = document.getElementById('grid'); if (!grid) return;
    C.forEach((c) => {
      const card = document.createElement('article');
      card.className = 'ccard'; card.dataset.region = c.region; card.dataset.round = c.r;
      card.innerHTML = `
        <div class="ccard__spine"></div>
        <div class="ccard__top">
          <div class="ccard__rd"><span class="p">RD</span><span class="n tnum">${String(c.r).padStart(2,'0')}</span></div>
          <div class="ccard__date"><b>${c.dateShort}</b><span>2026</span></div>
        </div>
        <div class="ccard__map">
          <span class="ccard__cc">${c.cc}</span>
          <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
            <path class="t-base"></path>
            <path class="t-line"></path>
            <circle class="t-sf" r="2.2"></circle>
            <circle class="t-car" r="2.6"></circle>
          </svg>
        </div>
        <div class="ccard__body">
          <div class="ccard__gp">${c.country} · ${c.type}</div>
          <h3 class="ccard__name">${c.city}</h3>
          <p class="ccard__loc">${c.circuit}</p>
          <p class="ccard__beat">${c.beat}</p>
        </div>
        <div class="ccard__foot">
          <div class="ccard__stat"><b class="tnum">${c.len.toFixed(3)}</b><span class="label">KM length</span></div>
          <div class="ccard__stat"><b class="tnum">${c.corners}</b><span class="label">Corners</span></div>
          <div class="ccard__stat"><b class="tnum">${c.laps}</b><span class="label">Laps</span></div>
          <div class="ccard__cta" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
        </div>`;
      grid.appendChild(card);
      cardByRound[c.r] = card;

      const svg = card.querySelector('svg');
      const base = svg.querySelector('.t-base'), line = svg.querySelector('.t-line');
      const sf = svg.querySelector('.t-sf'), car = svg.querySelector('.t-car');
      const d = smooth(c.P, 1);
      base.setAttribute('d', d); line.setAttribute('d', d);
      const L = line.getTotalLength();
      line.style.strokeDasharray = `${L}`;
      line.style.strokeDashoffset = reduced ? '0' : `${L}`;
      const p0 = line.getPointAtLength(0); sf.setAttribute('cx', p0.x); sf.setAttribute('cy', p0.y);
      cardAnim.push({ card, line, L, car });

      card.addEventListener('pointerenter', () => { const p = pinByRound[c.r]; if (p) p.classList.add('hot'); });
      card.addEventListener('pointerleave', () => { const p = pinByRound[c.r]; if (p && c.r !== NEXT_ROUND) p.classList.remove('hot'); });
      card.addEventListener('click', () => openFocus(c.r));
    });
  })();

  // scroll-scrubbed drawing of each visible card's track
  F1.onFrame(({ vh }) => {
    if (reduced) return;
    for (const a of cardAnim) {
      const r = a.card.getBoundingClientRect();
      if (r.bottom < -40 || r.top > vh + 40) continue;
      // draws from when card top is at 88% vh to when at 36% vh
      let p = (vh * 0.88 - r.top) / (vh * 0.52);
      p = Math.max(0, Math.min(1, p));
      a.line.style.strokeDashoffset = `${(a.L * (1 - p)).toFixed(1)}`;
      if (p > 0.04) a.card.classList.add('spine');
      // the "pen" dot rides the leading edge
      const tip = a.line.getPointAtLength(Math.max(0.001, p) * a.L);
      a.car.setAttribute('cx', tip.x); a.car.setAttribute('cy', tip.y);
      a.car.style.opacity = (p > 0.02 && p < 0.995) ? '1' : '0';
    }
  });

  /* ── FILTER BAR ────────────────────────────────────────────────────────── */
  (function () {
    const bar = document.getElementById('filter'); if (!bar) return;
    const counts = {};
    C.forEach((c) => { counts[c.region] = (counts[c.region]||0)+1; });
    const order = ['All','Europe','Asia','Middle East','Americas','Oceania'];
    let active = 'All';
    order.forEach((reg) => {
      const n = reg === 'All' ? C.length : (counts[reg]||0);
      if (reg !== 'All' && !n) return;
      const b = document.createElement('button');
      b.className = 'fchip'; b.setAttribute('aria-pressed', reg === 'All' ? 'true' : 'false');
      b.innerHTML = `${reg} <span class="ct">${String(n).padStart(2,'0')}</span>`;
      b.addEventListener('click', () => {
        active = reg;
        bar.querySelectorAll('.fchip').forEach((x) => x.setAttribute('aria-pressed', x === b ? 'true' : 'false'));
        C.forEach((c) => {
          const match = reg === 'All' || c.region === reg;
          cardByRound[c.r].classList.toggle('hide', !match);
          const pin = pinByRound[c.r]; if (pin) pin.classList.toggle('dim', !match);
        });
      });
      bar.appendChild(b);
    });
  })();

  /* ── FOCUS DOSSIER ─────────────────────────────────────────────────────── */
  const focus = document.getElementById('focus');
  const scrim = document.getElementById('focus-scrim');
  const panel = document.getElementById('focus-panel');
  let fxState = null; // { idx, raf, playing, t, T, lapDur, line, L, car, ghost, nodes, sectors, els }

  function buildFocus(c) {
    const T = recordSeconds(c.record);
    const dMul = 2; // 0..200 coordinate space
    const dStr = smooth(c.P, dMul);
    panel.innerHTML = `
      <div class="fx__stage">
        <div class="fx__grid"></div>
        <div class="fx__big">${c.cc}</div>
        <div class="fx__chips">
          <span class="fx__chip"><i style="background:var(--accent)"></i>Sector 1</span>
          <span class="fx__chip"><i style="background:#E0A33A"></i>Sector 2</span>
          <span class="fx__chip"><i style="background:#3FA8C4"></i>Sector 3</span>
          <span class="fx__chip" id="fx-drschip"><i style="background:#F4F2EC"></i>DRS ×${c.drs}</span>
        </div>
        <svg class="fx__svg" viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
          <path class="fx__base" d="${dStr}"></path>
          <path class="fx__drs" id="fx-drs"></path>
          <path class="fx__s1" id="fx-s1"></path>
          <path class="fx__s2" id="fx-s2"></path>
          <path class="fx__s3" id="fx-s3"></path>
          <g id="fx-nodes"></g>
          <g id="fx-sf"><circle class="fx__sf" r="4.4"></circle><circle class="fx__sfp" r="1.9"></circle></g>
          <circle class="fx__ghost" id="fx-ghost" r="2.4"></circle>
          <circle class="fx__car" id="fx-car" r="3"></circle>
        </svg>
        <div class="fx__hint">Hot lap · simulated from the circuit record</div>
      </div>
      <div class="fx__info">
        <div class="fx__nav">
          ${CIRCUIT_PAGES[c.r] ? `<a class="fxbtn" href="${CIRCUIT_PAGES[c.r]}" aria-label="Open full circuit feature" title="Full circuit feature"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M21 3l-9 9M10 5H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5"/></svg></a>` : ''}
          <button class="fxbtn" id="fx-prev" aria-label="Previous round"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button>
          <button class="fxbtn" id="fx-next" aria-label="Next round"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg></button>
          <button class="fxbtn x" id="fx-close" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
        <div class="fx__rd"><span>Round ${String(c.r).padStart(2,'0')} / 24</span><span class="ln"></span><span>${c.dateShort} · 2026</span></div>
        <h2 class="fx__name">${c.city}</h2>
        <p class="fx__circuit">${c.circuit} — ${c.country}</p>
        <p class="fx__beat">${c.beat}</p>
        <div class="fx__stats">
          <div class="fx__stat"><div class="v tnum">${c.len.toFixed(3)}<small>KM</small></div><div class="l">Lap length</div></div>
          <div class="fx__stat"><div class="v tnum">${c.corners}</div><div class="l">Corners</div></div>
          <div class="fx__stat"><div class="v tnum">${c.laps}</div><div class="l">Race laps</div></div>
          <div class="fx__stat"><div class="v tnum">${c.dist.toFixed(0)}<small>KM</small></div><div class="l">Distance</div></div>
          <div class="fx__stat"><div class="v tnum">${c.drs}</div><div class="l">DRS zones</div></div>
          <div class="fx__stat"><div class="v tnum">${c.firstHeld}</div><div class="l">First held</div></div>
        </div>
        <div class="fx__lap">
          <div class="fx__laphd"><span>Hot lap · ${c.type}</span><b><span class="d"></span>${c.record === '—' ? 'Inaugural' : 'Lap record ' + c.record}</b></div>
          <div class="fx__sectors">
            <div class="fx__sec"><div class="bar"><i id="fx-b1"></i></div><div class="t"><span>S1</span><b id="fx-t1">0.000</b></div></div>
            <div class="fx__sec"><div class="bar"><i id="fx-b2"></i></div><div class="t"><span>S2</span><b id="fx-t2">0.000</b></div></div>
            <div class="fx__sec"><div class="bar"><i id="fx-b3"></i></div><div class="t"><span>S3</span><b id="fx-t3">0.000</b></div></div>
          </div>
          <div class="fx__time">
            <div class="lap tnum" id="fx-clock">0:00.000</div>
            <div class="fx__ctrl">
              <input class="fx__scrub" id="fx-scrub" type="range" min="0" max="1000" value="0" aria-label="Lap position" />
              <button class="fx__play" id="fx-play" aria-label="Play hot lap"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button>
            </div>
          </div>
        </div>
      </div>`;

    // geometry
    const line = panel.querySelector('#fx-s1'); // placeholder, real lengths computed on base
    const baseEl = panel.querySelector('.fx__base');
    const L = baseEl.getTotalLength();
    const f1 = c.sectors[0], f2 = c.sectors[1];
    // build sector sub-paths by sampling the base
    function sub(a, b) {
      const steps = Math.max(6, Math.round((b - a) * 240));
      let s = '';
      for (let i = 0; i <= steps; i++) {
        const t = a + (b - a) * (i / steps);
        const pt = baseEl.getPointAtLength(t * L);
        s += (i ? 'L' : 'M') + pt.x.toFixed(2) + ' ' + pt.y.toFixed(2) + ' ';
      }
      return s;
    }
    const s1 = panel.querySelector('#fx-s1'), s2 = panel.querySelector('#fx-s2'), s3 = panel.querySelector('#fx-s3');
    s1.setAttribute('d', sub(0, f1)); s2.setAttribute('d', sub(f1, f2)); s3.setAttribute('d', sub(f2, 1));
    // draw-on animation per sector
    [s1, s2, s3].forEach((p, i) => {
      const pl = p.getTotalLength();
      p.style.strokeDasharray = `${pl}`;
      p.style.strokeDashoffset = reduced ? '0' : `${pl}`;
      p.style.transition = `stroke-dashoffset 1s cubic-bezier(0.16,1,0.3,1) ${0.15 + i*0.5}s`;
    });
    // DRS overlay zones (placed on the longest straight-ish fractions)
    const drsEl = panel.querySelector('#fx-drs');
    const zoneStarts = c.drs >= 3 ? [0.02, 0.40, 0.70] : (c.drs === 2 ? [0.04, 0.55] : [0.06]);
    let dz = '';
    zoneStarts.slice(0, c.drs).forEach((zs) => { dz += sub(zs, Math.min(0.999, zs + 0.07)); });
    drsEl.setAttribute('d', dz);

    // start/finish + corner nodes
    const sfG = panel.querySelector('#fx-sf');
    const p0 = baseEl.getPointAtLength(0); sfG.setAttribute('transform', `translate(${p0.x} ${p0.y})`);
    const nodesG = panel.querySelector('#fx-nodes');
    const nodeCount = Math.min(c.corners, 9);
    const nodes = [];
    for (let i = 0; i < nodeCount; i++) {
      const f = (i + 0.5) / nodeCount;
      const pt = baseEl.getPointAtLength(f * L);
      const g = el('g', 'fx__node', { transform: `translate(${pt.x} ${pt.y})` });
      g.appendChild(el('circle', null, { r: 4.4 }));
      const tx = el('text', null, { 'text-anchor':'middle', dy:2.4 }); tx.textContent = String(i+1); g.appendChild(tx);
      nodesG.appendChild(g); nodes.push({ g, len: f * L });
    }

    const car = panel.querySelector('#fx-car'), ghost = panel.querySelector('#fx-ghost');
    const drsChip = panel.querySelector('#fx-drschip');
    const drsZonesLen = zoneStarts.slice(0, c.drs).map((zs) => [zs, Math.min(0.999, zs + 0.07)]);

    fxState = {
      c, T, L, baseEl, car, ghost, nodes, f1, f2,
      drsEl, drsZonesLen, drsChip,
      bars: [panel.querySelector('#fx-b1'), panel.querySelector('#fx-b2'), panel.querySelector('#fx-b3')],
      times: [panel.querySelector('#fx-t1'), panel.querySelector('#fx-t2'), panel.querySelector('#fx-t3')],
      clock: panel.querySelector('#fx-clock'),
      scrub: panel.querySelector('#fx-scrub'),
      playBtn: panel.querySelector('#fx-play'),
      t: 0, playing: false, last: 0
    };
    placeCar(0);
    renderLap(0);

    // wiring
    panel.querySelector('#fx-close').addEventListener('click', closeFocus);
    panel.querySelector('#fx-prev').addEventListener('click', () => stepFocus(-1));
    panel.querySelector('#fx-next').addEventListener('click', () => stepFocus(1));
    fxState.playBtn.addEventListener('click', togglePlay);
    fxState.scrub.addEventListener('input', () => {
      fxState.t = parseFloat(fxState.scrub.value) / 1000;
      if (fxState.playing) pausePlay();
      placeCar(fxState.t); renderLap(fxState.t);
    });
    if (!reduced) { requestAnimationFrame(() => { s1.style.strokeDashoffset = '0'; s2.style.strokeDashoffset = '0'; s3.style.strokeDashoffset = '0'; }); }
  }

  function lapDur() {
    const h = (typeof window.__circuitHotlap === 'number') ? window.__circuitHotlap : 6;
    return Math.max(3, 14 - h); // seconds of wall-clock per simulated lap
  }
  function placeCar(t) {
    const s = fxState; if (!s) return;
    const pc = s.baseEl.getPointAtLength((t % 1) * s.L); s.car.setAttribute('cx', pc.x); s.car.setAttribute('cy', pc.y);
    const pg = s.baseEl.getPointAtLength(((t - 0.018 + 1) % 1) * s.L); s.ghost.setAttribute('cx', pg.x); s.ghost.setAttribute('cy', pg.y);
    const cl = t * s.L;
    s.nodes.forEach((n) => { let dd = Math.abs(cl - n.len); dd = Math.min(dd, s.L - dd); n.g.classList.toggle('hot', dd < 9); });
    // DRS active when car is within a zone
    const inZone = s.drsZonesLen.some(([a, b]) => t >= a && t <= b);
    s.drsEl.classList.toggle('on', inZone);
    if (s.drsChip) s.drsChip.style.opacity = inZone ? '1' : '0.55';
  }
  function renderLap(t) {
    const s = fxState; if (!s) return;
    const { f1, f2, T } = s;
    s.clock.textContent = fmtLap(t * T);
    // sector progress 0..1 each
    const segs = [[0, f1], [f1, f2], [f2, 1]];
    segs.forEach((seg, i) => {
      const [a, b] = seg;
      let p = (t - a) / (b - a); p = Math.max(0, Math.min(1, p));
      s.bars[i].style.width = (p * 100).toFixed(1) + '%';
      const elapsed = (Math.min(t, b) > a ? (Math.min(t, b) - a) : 0) * T;
      s.times[i].textContent = fmtSec(elapsed);
    });
  }
  function tick(now) {
    const s = fxState; if (!s || !s.playing) return;
    if (!s.last) s.last = now;
    const dt = Math.min(0.05, (now - s.last) / 1000); s.last = now;
    s.t += dt / lapDur();
    if (s.t >= 1) { s.t = 0; } // loop
    s.scrub.value = String(Math.round(s.t * 1000));
    placeCar(s.t); renderLap(s.t);
    s.raf = requestAnimationFrame(tick);
  }
  function togglePlay() { if (fxState.playing) pausePlay(); else startPlay(); }
  function startPlay() {
    const s = fxState; s.playing = true; s.last = 0;
    s.playBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>';
    s.raf = requestAnimationFrame(tick);
  }
  function pausePlay() {
    const s = fxState; s.playing = false;
    if (s.raf) cancelAnimationFrame(s.raf);
    s.playBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
  }

  let fxIdx = 0;
  function openFocus(round) {
    const idx = C.findIndex((x) => x.r === round); if (idx < 0) return;
    fxIdx = idx;
    buildFocus(C[idx]);
    focus.classList.add('on'); focus.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => focus.classList.add('show'));
    if (!reduced) setTimeout(startPlay, 900);
  }
  function stepFocus(dir) {
    if (fxState) pausePlay();
    fxIdx = (fxIdx + dir + C.length) % C.length;
    buildFocus(C[fxIdx]);
    if (!reduced) setTimeout(startPlay, 700);
  }
  function closeFocus() {
    if (fxState) pausePlay();
    focus.classList.remove('show');
    setTimeout(() => { focus.classList.remove('on'); focus.setAttribute('aria-hidden', 'true'); document.body.style.overflow = ''; }, 420);
  }
  scrim.addEventListener('click', closeFocus);
  addEventListener('keydown', (e) => {
    if (!focus.classList.contains('on')) return;
    if (e.key === 'Escape') closeFocus();
    else if (e.key === 'ArrowRight') stepFocus(1);
    else if (e.key === 'ArrowLeft') stepFocus(-1);
    else if (e.key === ' ') { e.preventDefault(); togglePlay(); }
  });

  /* ── EXTRA TWEAKS · hot-lap speed + density (append to engine panel) ───── */
  (function () {
    const defaults = window.__F1_TWEAKS || {};
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {}; } catch (e) {}
    let hotlap = (typeof saved.hotlap === 'number') ? saved.hotlap : (typeof defaults.hotlap === 'number' ? defaults.hotlap : 6);
    let density = saved.density || defaults.density || 'default';
    window.__circuitHotlap = hotlap;
    applyDensity(density);

    function applyDensity(d) { if (d && d !== 'default') root.setAttribute('data-density', d); else root.removeAttribute('data-density'); }
    function persist(edits) {
      try {
        const cur = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {};
        Object.assign(cur, edits);
        localStorage.setItem('f1home-tweaks', JSON.stringify(cur));
      } catch (e) {}
      try { window.parent.postMessage({ type: '__edit_mode_set_keys', edits }, '*'); } catch (e) {}
    }

    function inject() {
      const body = document.querySelector('.twk .twk__b');
      if (!body) return false;
      if (body.querySelector('[data-circuit-tweak]')) return true;

      // Hot-lap speed
      const r1 = document.createElement('div');
      r1.className = 'twk__row'; r1.setAttribute('data-circuit-tweak', '1');
      r1.innerHTML = `<label>Hot-lap speed <span class="twk__val" id="ctw-hval"></span></label>
        <input class="twk__rng" id="ctw-hot" type="range" min="0" max="10" step="1">`;
      body.appendChild(r1);
      const rng = r1.querySelector('#ctw-hot'), hval = r1.querySelector('#ctw-hval');
      rng.value = hotlap; hval.textContent = hotlap <= 1 ? 'cruise' : (hotlap >= 9 ? 'qualy' : hotlap);
      rng.addEventListener('input', () => {
        hotlap = parseInt(rng.value, 10); window.__circuitHotlap = hotlap;
        hval.textContent = hotlap <= 1 ? 'cruise' : (hotlap >= 9 ? 'qualy' : hotlap);
        persist({ hotlap });
      });

      // Density
      const r2 = document.createElement('div');
      r2.className = 'twk__row'; r2.setAttribute('data-circuit-tweak', '1');
      r2.innerHTML = `<label>Grid density</label>
        <div class="twk__seg" id="ctw-den">
          <button data-v="dense">Dense</button><button data-v="default">Default</button><button data-v="roomy">Roomy</button>
        </div>`;
      body.appendChild(r2);
      const seg = r2.querySelector('#ctw-den');
      const paint = () => seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === density));
      seg.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
        density = b.dataset.v; applyDensity(density); persist({ density }); paint();
      }));
      paint();
      return true;
    }

    let tries = 0;
    const iv = setInterval(() => { if (inject() || ++tries > 40) clearInterval(iv); }, 120);
  })();

})();
