/* ============================================================================
   F1Pulse — Circuit feature · Monza · page choreography
   Hero ghost lap · drivable hot-lap player with simulated speed telemetry ·
   three-sector maps · annotated corner hotspots · orthographic locator globe.
   Loads after engine.js (window.F1) and monza-data.js (window.MONZA).
   ========================================================================== */
(function () {
  'use strict';
  const M = window.MONZA;
  const F1 = window.F1 || { onFrame: () => {} };
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const SVGNS = 'http://www.w3.org/2000/svg';
  if (!M) return;

  /* ── helpers ─────────────────────────────────────────────────────────── */
  function smooth(p, mul) {
    const m = mul || 1, n = p.length;
    let d = `M ${(p[0][0]*m).toFixed(2)} ${(p[0][1]*m).toFixed(2)} `;
    for (let i = 0; i < n; i++) {
      const a = p[(i-1+n)%n], b = p[i], c = p[(i+1)%n], e = p[(i+2)%n];
      const c1x=(b[0]+(c[0]-a[0])/6)*m, c1y=(b[1]+(c[1]-a[1])/6)*m;
      const c2x=(c[0]-(e[0]-b[0])/6)*m, c2y=(c[1]-(e[1]-b[1])/6)*m;
      d += `C ${c1x.toFixed(2)} ${c1y.toFixed(2)}, ${c2x.toFixed(2)} ${c2y.toFixed(2)}, ${(c[0]*m).toFixed(2)} ${(c[1]*m).toFixed(2)} `;
    }
    return d + 'Z';
  }
  const el = (tag, cls, attrs) => {
    const e = document.createElementNS(SVGNS, tag);
    if (cls) e.setAttribute('class', cls);
    if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  };
  const $ = (id) => document.getElementById(id);
  function recordSeconds(rec) {
    const m = /(\d+):(\d+)\.(\d+)/.exec(rec || ''); if (!m) return 81;
    return parseInt(m[1],10)*60 + parseInt(m[2],10) + parseInt(m[3],10)/1000;
  }
  const fmtLap = (s) => { const mm=Math.floor(s/60), ss=Math.floor(s%60), ms=Math.round((s-Math.floor(s))*1000);
    return `${mm}:${String(ss).padStart(2,'0')}.${String(ms).padStart(3,'0')}`; };
  const fmtSec = (s) => s.toFixed(3);
  // sample a sub-path of a base element between fractions a..b
  function subPath(baseEl, L, a, b) {
    const steps = Math.max(6, Math.round(Math.abs(b - a) * 260));
    let s = '';
    for (let i = 0; i <= steps; i++) {
      const t = a + (b - a) * (i / steps);
      const pt = baseEl.getPointAtLength(((t % 1 + 1) % 1) * L);
      s += (i ? 'L' : 'M') + pt.x.toFixed(2) + ' ' + pt.y.toFixed(2) + ' ';
    }
    return s;
  }
  const dPath = smooth(M.P, 1);           // 0..100 space
  const T = recordSeconds(M.record);      // hot-lap seconds

  /* ── reveal settler ──────────────────────────────────────────────────────
     The shared engine reveals [data-reveal] via a CSS opacity/transform
     transition. On this page the heavy, filtered, below-fold modules (lap
     player, corner map, globe) can have that transition parked at the hidden
     state by the compositor when it's armed off-screen during a scroll. We
     neutralise the CSS reveal (circuit.css keeps the resting state visible)
     and drive entrances with the Web Animations API, which always completes
     and reverts to the visible underlying state. */
  (function () {
    if (reduced) return;                                   // CSS already shows everything
    const io = new IntersectionObserver((ents) => {
      ents.forEach((e) => {
        if (!e.isIntersecting) return;
        const el = e.target; io.unobserve(el);
        const d = (parseFloat(el.getAttribute('data-reveal-d')) || 0) * 90;
        el.animate(
          [{ opacity: 0, transform: 'translateY(32px)' }, { opacity: 1, transform: 'none' }],
          { duration: 920, delay: d, easing: 'cubic-bezier(0.16,1,0.3,1)', fill: 'backwards' }
        );
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.01 });
    document.querySelectorAll('[data-reveal]').forEach((el) => io.observe(el));
  })();

  /* ── speed profile (a believable velocity trace from track curvature) ──── */
  // Samples the smoothed loop, derives a cornering-speed ceiling from local
  // radius, then runs accel/brake passes so the car brakes *before* corners
  // and powers *out* — the classic velocity profile. Returns speedAt(t)→km/h.
  function buildSpeedProfile(baseEl, L) {
    const N = 260, win = 5;
    const pts = [];
    for (let i = 0; i < N; i++) pts.push(baseEl.getPointAtLength((i / N) * L));
    const ds = L / N;
    const vmin = 78, vmax = M.topSpeed;
    const v = new Array(N);
    for (let i = 0; i < N; i++) {
      const A = pts[(i - win + N) % N], B = pts[i], Cc = pts[(i + win) % N];
      const a = Math.hypot(B.x - Cc.x, B.y - Cc.y);
      const b = Math.hypot(A.x - Cc.x, A.y - Cc.y);
      const c = Math.hypot(A.x - B.x, A.y - B.y);
      const area = Math.abs((B.x - A.x) * (Cc.y - A.y) - (Cc.x - A.x) * (B.y - A.y)) / 2;
      let R = area < 1e-4 ? 1e4 : (a * b * c) / (4 * area);   // circumradius in coord units
      let vc = 30 * Math.sqrt(R);                              // lateral-grip ceiling
      v[i] = Math.max(vmin, Math.min(vmax, vc));
    }
    // accel / brake passes (looped, a few iterations for the closed circuit)
    const aAcc = 6.5, aBrake = 12;
    for (let pass = 0; pass < 4; pass++) {
      for (let i = 0; i < N; i++) {                            // forward: limit acceleration
        const j = (i - 1 + N) % N;
        v[i] = Math.min(v[i], Math.sqrt(v[j] * v[j] + 2 * aAcc * ds * 60));
      }
      for (let i = N - 1; i >= 0; i--) {                       // backward: limit braking
        const j = (i + 1) % N;
        v[i] = Math.min(v[i], Math.sqrt(v[j] * v[j] + 2 * aBrake * ds * 60));
      }
    }
    return {
      N, arr: v,
      at(t) {
        const x = ((t % 1) + 1) % 1 * N; const i = Math.floor(x), f = x - i;
        return v[i % N] * (1 - f) + v[(i + 1) % N] * f;
      }
    };
  }
  const gearForSpeed = (s) => Math.max(1, Math.min(8, Math.round((s / M.topSpeed) * 7) + 1));

  /* ── HERO ghost lap ──────────────────────────────────────────────────── */
  (function () {
    const svg = $('hero-ghost'); if (!svg) return;
    svg.setAttribute('viewBox', '0 0 100 100');
    const base = el('path', 'gbase', { d: dPath });
    const line = el('path', 'gline', { d: dPath });
    const car = el('circle', 'gcar', { r: 1.7 });
    svg.appendChild(base); svg.appendChild(line); svg.appendChild(car);
    const L = line.getTotalLength();
    if (reduced) { const p = line.getPointAtLength(0); car.setAttribute('cx', p.x); car.setAttribute('cy', p.y); return; }
    line.style.strokeDasharray = `${L}`; line.style.strokeDashoffset = `${L}`;
    line.getBoundingClientRect();
    line.style.transition = 'stroke-dashoffset 2.4s cubic-bezier(0.16,1,0.3,1) .2s';
    requestAnimationFrame(() => { line.style.strokeDashoffset = '0'; });
    let t = 0;
    F1.onFrame(() => {
      t = (t + 0.0016) % 1;
      const p = line.getPointAtLength(t * L);
      car.setAttribute('cx', p.x); car.setAttribute('cy', p.y);
    });
  })();

  /* ── 01 · THE LAP — drivable hot-lap player ──────────────────────────── */
  (function () {
    const svg = $('lap-svg'); if (!svg) return;
    svg.setAttribute('viewBox', '0 0 100 100');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    const base = el('path', 'l-base', { d: dPath });
    svg.appendChild(base);
    const L = base.getTotalLength();
    const [f1, f2] = M.sectors;

    const drs = el('path', 'l-drs', { id: 'lap-drs' });
    const s1 = el('path', 'l-s1', { d: subPath(base, L, 0, f1) });
    const s2 = el('path', 'l-s2', { d: subPath(base, L, f1, f2) });
    const s3 = el('path', 'l-s3', { d: subPath(base, L, f2, 1) });
    svg.appendChild(drs); svg.appendChild(s1); svg.appendChild(s2); svg.appendChild(s3);
    // DRS zones — two long straights: main straight & the run to Parabolica
    const drsZones = [[0.93, 0.04], [0.60, 0.69]];   // [start,end] fractions (first wraps the line)
    let dz = '';
    drsZones.forEach(([a, b]) => { dz += (b < a) ? (subPath(base, L, a, 1) + subPath(base, L, 0, b)) : subPath(base, L, a, b); });
    drs.setAttribute('d', dz);

    // draw-on per sector
    [s1, s2, s3].forEach((p, i) => {
      const pl = p.getTotalLength();
      p.style.strokeDasharray = `${pl}`;
      p.style.strokeDashoffset = reduced ? '0' : `${pl}`;
      p.style.transition = `stroke-dashoffset 1.05s cubic-bezier(0.16,1,0.3,1) ${0.1 + i * 0.45}s`;
    });

    // start/finish + corner nodes
    const p0 = base.getPointAtLength(0);
    const sf = el('g', 'l-sf', { transform: `translate(${p0.x} ${p0.y})` });
    sf.appendChild(el('circle', 'o', { r: 4 })); sf.appendChild(el('circle', 'i', { r: 1.7 }));
    const nodesG = el('g');
    const nodes = M.corners.map((c) => {
      const pt = base.getPointAtLength(c.t * L);
      const g = el('g', 'l-node', { transform: `translate(${pt.x} ${pt.y})` });
      g.appendChild(el('circle', null, { r: 3.4 }));
      const tx = el('text', null, { 'text-anchor': 'middle', dy: 2.2 }); tx.textContent = c.n; g.appendChild(tx);
      nodesG.appendChild(g);
      return { g, len: c.t * L };
    });
    const ghost = el('circle', 'l-ghost', { r: 2.3 });
    const car = el('circle', 'l-car', { r: 2.9 });
    svg.appendChild(nodesG); svg.appendChild(sf); svg.appendChild(ghost); svg.appendChild(car);

    // speed profile + trace strip
    const speed = buildSpeedProfile(base, L);
    const trace = $('lap-trace');
    if (trace) {
      const tsvg = el('svg', null, { viewBox: '0 0 300 100', preserveAspectRatio: 'none' });
      const defs = el('defs');
      defs.innerHTML = `<linearGradient id="trace-grad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="var(--accent)" stop-opacity="0.5"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0.02"/></linearGradient>`;
      tsvg.appendChild(defs);
      const vmin = 70, vrange = M.topSpeed - vmin + 10;
      let line = '', poly = 'M0 100 ';
      for (let i = 0; i <= 120; i++) {
        const t = i / 120; const x = (t * 300).toFixed(1);
        const y = (100 - ((speed.at(t) - vmin) / vrange) * 96).toFixed(1);
        line += (i ? 'L' : 'M') + x + ' ' + y + ' '; poly += 'L' + x + ' ' + y + ' ';
      }
      poly += 'L300 100 Z';
      tsvg.appendChild(el('path', 'tr-fill', { d: poly }));
      tsvg.appendChild(el('path', 'tr-fillline', { d: line }));
      const head = el('line', 'tr-head', { x1: 0, y1: 0, x2: 0, y2: 100 });
      const dot = el('circle', 'tr-dot', { r: 2.6, cx: 0, cy: 100 });
      tsvg.appendChild(head); tsvg.appendChild(dot);
      const lbl = document.createElement('span'); lbl.className = 'lbl'; lbl.textContent = 'Speed trace · one lap';
      trace.appendChild(tsvg); trace.appendChild(lbl);
      trace._head = head; trace._dot = dot; trace._vmin = vmin; trace._vrange = vrange;
    }

    const speedNum = $('lap-speed'), gearB = $('lap-gear');
    const bars = [$('lap-b1'), $('lap-b2'), $('lap-b3')];
    const times = [$('lap-t1'), $('lap-t2'), $('lap-t3')];
    const clock = $('lap-clock'), scrub = $('lap-scrub'), playBtn = $('lap-play'), drsChip = $('lap-drschip');

    let t = 0, playing = false, last = 0, raf = null;

    function place(t) {
      const pc = base.getPointAtLength((t % 1) * L); car.setAttribute('cx', pc.x); car.setAttribute('cy', pc.y);
      const pg = base.getPointAtLength((((t - 0.02) % 1 + 1) % 1) * L); ghost.setAttribute('cx', pg.x); ghost.setAttribute('cy', pg.y);
      const cl = t * L;
      nodes.forEach((n) => { let dd = Math.abs(cl - n.len); dd = Math.min(dd, L - dd); n.g.classList.toggle('hot', dd < 7); });
      const inZone = drsZones.some(([a, b]) => (b < a) ? (t >= a || t <= b) : (t >= a && t <= b));
      drs.classList.toggle('on', inZone);
      if (drsChip) drsChip.style.opacity = inZone ? '1' : '0.5';
      // speed + gear
      const sp = speed.at(t);
      if (speedNum) speedNum.textContent = Math.round(sp);
      if (gearB) gearB.textContent = gearForSpeed(sp);
      if (trace && trace._head) {
        const x = (t % 1) * 300, y = 100 - ((sp - trace._vmin) / trace._vrange) * 96;
        trace._head.setAttribute('x1', x); trace._head.setAttribute('x2', x);
        trace._dot.setAttribute('cx', x); trace._dot.setAttribute('cy', y);
      }
    }
    function render(t) {
      if (clock) clock.textContent = fmtLap(t * T);
      const segs = [[0, f1], [f1, f2], [f2, 1]];
      segs.forEach((seg, i) => {
        const [a, b] = seg; let p = (t - a) / (b - a); p = Math.max(0, Math.min(1, p));
        if (bars[i]) bars[i].style.width = (p * 100).toFixed(1) + '%';
        const elapsed = (Math.min(t, b) > a ? (Math.min(t, b) - a) : 0) * T;
        if (times[i]) times[i].textContent = fmtSec(elapsed);
      });
    }
    function lapDur() {
      const h = (typeof window.__circuitHotlap === 'number') ? window.__circuitHotlap : 6;
      return Math.max(3, 14 - h);
    }
    function tick(now) {
      if (!playing) return;
      if (!last) last = now;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      t = (t + dt / lapDur()) % 1;
      if (scrub) scrub.value = String(Math.round(t * 1000));
      place(t); render(t);
      raf = requestAnimationFrame(tick);
    }
    const PLAY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
    const PAUSE = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>';
    function start() { playing = true; last = 0; if (playBtn) playBtn.innerHTML = PAUSE; raf = requestAnimationFrame(tick); }
    function pause() { playing = false; if (raf) cancelAnimationFrame(raf); if (playBtn) playBtn.innerHTML = PLAY; }
    if (playBtn) playBtn.addEventListener('click', () => playing ? pause() : start());
    if (scrub) scrub.addEventListener('input', () => { t = parseFloat(scrub.value) / 1000; if (playing) pause(); place(t); render(t); });

    place(0); render(0);
    if (!reduced) requestAnimationFrame(() => { s1.style.strokeDashoffset = '0'; s2.style.strokeDashoffset = '0'; s3.style.strokeDashoffset = '0'; });

    // auto-play once the player scrolls into view
    if (!reduced) {
      const io = new IntersectionObserver((ents) => {
        ents.forEach((e) => { if (e.isIntersecting && !playing && t === 0) { setTimeout(start, 700); io.disconnect(); } });
      }, { threshold: 0.45 });
      io.observe(svg.closest('.lapbox') || svg);
    }
  })();

  /* ── 02 · SECTORS — three mini maps ──────────────────────────────────── */
  (function () {
    const host = $('sector-cards'); if (!host) return;
    M.sectorMeta.forEach((s, i) => {
      const card = document.createElement('article');
      card.className = 'scard'; card.style.setProperty('--sc', s.color); card.setAttribute('data-reveal', ''); card.setAttribute('data-reveal-d', String(i + 1));
      card.innerHTML = `
        <div class="scard__map">
          <span class="scard__id">${s.id}</span>
          <span class="scard__pct">${Math.round((s.frac[1] - s.frac[0]) * 100)}% of lap</span>
          <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
            <path class="sm-base" d="${dPath}"></path>
            <path class="sm-on"></path>
          </svg>
        </div>
        <div class="scard__body">
          <h3 class="scard__name">${s.id} · <em>${s.name}</em></h3>
          <p class="scard__blurb">${s.blurb}</p>
        </div>`;
      host.appendChild(card);
      const baseEl = card.querySelector('.sm-base'), onEl = card.querySelector('.sm-on');
      const L = baseEl.getTotalLength();
      onEl.setAttribute('d', subPath(baseEl, L, s.frac[0], s.frac[1]));
      const pl = onEl.getTotalLength();
      onEl.style.strokeDasharray = `${pl}`;
      onEl.style.strokeDashoffset = reduced ? '0' : `${pl}`;
      onEl.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(0.16,1,0.3,1)';
      const io = new IntersectionObserver((ents) => ents.forEach((e) => {
        if (e.isIntersecting) { onEl.style.strokeDashoffset = '0'; io.disconnect(); }
      }), { threshold: 0.4 });
      io.observe(card);
    });
  })();

  /* ── 03 · CORNERS — annotated hotspot map + list ─────────────────────── */
  (function () {
    const svg = $('cnr-svg'); if (!svg) return;
    svg.setAttribute('viewBox', '0 0 100 100');
    const base = el('path', 'cm-base', { d: dPath });
    const line = el('path', 'cm-line', { d: dPath });
    svg.appendChild(base); svg.appendChild(line);
    const L = base.getTotalLength();
    const seg = el('path', 'cm-seg'); svg.appendChild(seg);
    const p0 = base.getPointAtLength(0);
    const sf = el('circle', 'cm-sf', { r: 2.2, cx: p0.x, cy: p0.y }); svg.appendChild(sf);
    const nodesG = el('g'); svg.appendChild(nodesG);

    const list = $('cnr-list');
    const read = { ix: $('cnr-ix'), nm: $('cnr-nm'), kd: $('cnr-kd'), note: $('cnr-note'),
      gear: $('cnr-gear'), speed: $('cnr-speed'), turns: $('cnr-turns') };
    const nodeEls = [], rowEls = [];
    let active = -1;

    function setActive(i) {
      if (i === active) return; active = i;
      const c = M.corners[i];
      nodeEls.forEach((n, k) => n.classList.toggle('on', k === i));
      rowEls.forEach((r, k) => r.classList.toggle('on', k === i));
      seg.setAttribute('d', subPath(base, L, c.t - 0.035, c.t + 0.035));
      seg.classList.add('on');
      if (read.ix) read.ix.textContent = String(c.n).padStart(2, '0');
      if (read.nm) read.nm.textContent = c.name;
      if (read.kd) read.kd.textContent = c.kind;
      if (read.note) read.note.textContent = c.note;
      if (read.gear) read.gear.textContent = c.gear;
      if (read.speed) read.speed.textContent = c.speed;
      if (read.turns) read.turns.textContent = c.turns;
    }

    M.corners.forEach((c, i) => {
      const pt = base.getPointAtLength(c.t * L);
      const g = el('g', 'cnr__node', { transform: `translate(${pt.x} ${pt.y})` });
      g.appendChild(el('circle', 'nd-ring', { r: 5.4 }));
      g.appendChild(el('circle', 'nd-dot', { r: 4.2 }));
      const tx = el('text', 'nd-num', { 'text-anchor': 'middle', dy: 1.9 }); tx.textContent = c.n; g.appendChild(tx);
      g.appendChild(el('circle', 'nd-hit', { r: 8 }));
      g.addEventListener('pointerenter', () => setActive(i));
      g.addEventListener('click', () => setActive(i));
      nodesG.appendChild(g); nodeEls.push(g);

      if (list) {
        const row = document.createElement('div');
        row.className = 'cnr__row';
        row.innerHTML = `<span class="rn">${String(c.n).padStart(2, '0')}</span>
          <span class="rnm">${c.name}</span>
          <span class="rt">${c.turns}</span>
          <span class="rbar"><i style="width:${Math.round((c.speed / M.topSpeed) * 100)}%"></i></span>`;
        row.addEventListener('pointerenter', () => setActive(i));
        row.addEventListener('click', () => setActive(i));
        list.appendChild(row); rowEls.push(row);
      }
    });
    setActive(0);
  })();

  /* ── 05 · LOCATION — orthographic locator globe ──────────────────────── */
  (function () {
    const stage = $('loc-globe'); const svg = $('loc-svg');
    // fill meta text from data (single source of truth)
    const latTxt = (M.lat >= 0 ? M.lat.toFixed(2) + '° N' : Math.abs(M.lat).toFixed(2) + '° S');
    const lonTxt = (M.lon >= 0 ? M.lon.toFixed(2) + '° E' : Math.abs(M.lon).toFixed(2) + '° W');
    const set = (id, v) => { const e = $(id); if (e) e.textContent = v; };
    set('loc-lat', latTxt); set('loc-lon', lonTxt); set('loc-elev', M.elevation + ' m');
    set('loc-region', M.region); set('loc-near', M.nearest);

    if (!stage || !svg || !window.d3) return;
    const d3 = window.d3;
    const S = 460, R = 214, CX = S / 2, CY = S / 2;
    svg.setAttribute('viewBox', `0 0 ${S} ${S}`);
    const proj = d3.geoOrthographic().scale(R).translate([CX, CY]).rotate([-M.lon, -M.lat]).clipAngle(90);
    const path = d3.geoPath(proj);
    const gratMinor = d3.geoGraticule().step([15, 15])();
    const gratMajor = d3.geoGraticule().step([90, 90])();

    const sphere = el('path', 'g2-sphere');
    const grat = el('path', 'g2-grat');
    const gratMaj = el('path', 'g2-grat--maj');
    const land = el('path', 'g2-land');
    const borders = el('path', 'g2-borders');
    const pin = el('g');
    pin.appendChild(el('circle', 'g2-pin__ring', { r: 7 }));
    pin.appendChild(el('circle', 'g2-pin__dot', { r: 3.4 }));
    const lab = el('text', 'g2-pin__lab', { x: 9, y: 3 }); lab.textContent = 'MONZA'; pin.appendChild(lab);
    svg.appendChild(sphere); svg.appendChild(grat); svg.appendChild(gratMaj);
    svg.appendChild(land); svg.appendChild(borders); svg.appendChild(pin);
    sphere.style.filter = 'drop-shadow(0 16px 30px rgba(20,17,14,0.26))';

    let landLow = null, landHigh = null, bordersMesh = null;
    const ll = [M.lon, M.lat];
    function render(fast) {
      sphere.setAttribute('d', path({ type: 'Sphere' }) || '');
      grat.setAttribute('d', path(gratMinor) || '');
      gratMaj.setAttribute('d', path(gratMajor) || '');
      const lf = (fast ? landLow : landHigh) || landLow || landHigh;
      if (lf) land.setAttribute('d', path(lf) || '');
      if (!fast && bordersMesh) borders.setAttribute('d', path(bordersMesh) || '');
      else if (fast) borders.setAttribute('d', '');
      const rot = proj.rotate(); const center = [-rot[0], -rot[1]];
      const dist = d3.geoDistance(ll, center);
      if (dist > Math.PI / 2 - 0.02) { pin.style.display = 'none'; }
      else { pin.style.display = ''; const p = proj(ll); pin.setAttribute('transform', `translate(${p[0].toFixed(1)} ${p[1].toFixed(1)})`); }
    }

    // drag to spin; gentle auto-rotate when idle
    let dragging = false, lx = 0, ly = 0, settle = null, idle = true;
    const k = 0.32;
    stage.addEventListener('pointerdown', (e) => { dragging = true; idle = false; lx = e.clientX; ly = e.clientY; try { stage.setPointerCapture(e.pointerId); } catch (_) {} });
    stage.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
      const r = proj.rotate(); let nlat = r[1] - dy * k; nlat = Math.max(-90, Math.min(90, nlat));
      proj.rotate([r[0] + dx * k, nlat]); render(true);
    });
    const endDrag = () => { dragging = false; clearTimeout(settle); settle = setTimeout(() => { render(false); idle = true; }, 80); };
    stage.addEventListener('pointerup', endDrag); stage.addEventListener('pointercancel', endDrag);

    render(false);
    if (!reduced) {
      let visible = false;
      const io = new IntersectionObserver((ents) => ents.forEach((e) => { visible = e.isIntersecting; }), { threshold: 0.2 });
      io.observe(stage);
      F1.onFrame(() => {
        if (!visible || dragging || !idle) return;
        const r = proj.rotate(); proj.rotate([r[0] + 0.06, r[1]]); render(true);
      });
    }
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json').then((r) => r.json())
      .then((topo) => { if (window.topojson) { landLow = topojson.feature(topo, topo.objects.land); render(false); } }).catch(() => {});
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json').then((r) => r.json())
      .then((topo) => {
        if (!window.topojson) return;
        landHigh = topojson.feature(topo, topo.objects.countries);
        bordersMesh = topojson.mesh(topo, topo.objects.countries, (a, b) => a !== b);
        render(false);
      }).catch(() => {});
  })();

  /* ── TWEAK · hot-lap speed (append to engine panel) ──────────────────── */
  (function () {
    const defaults = window.__F1_TWEAKS || {};
    let saved = {}; try { saved = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {}; } catch (e) {}
    let hotlap = (typeof saved.hotlap === 'number') ? saved.hotlap : (typeof defaults.hotlap === 'number' ? defaults.hotlap : 6);
    window.__circuitHotlap = hotlap;
    function persist(edits) {
      try { const cur = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {}; Object.assign(cur, edits); localStorage.setItem('f1home-tweaks', JSON.stringify(cur)); } catch (e) {}
      try { window.parent.postMessage({ type: '__edit_mode_set_keys', edits }, '*'); } catch (e) {}
    }
    function inject() {
      const body = document.querySelector('.twk .twk__b'); if (!body) return false;
      if (body.querySelector('[data-circuit-tweak]')) return true;
      const r1 = document.createElement('div');
      r1.className = 'twk__row'; r1.setAttribute('data-circuit-tweak', '1');
      r1.innerHTML = `<label>Hot-lap speed <span class="twk__val" id="ctw-hval"></span></label>
        <input class="twk__rng" id="ctw-hot" type="range" min="0" max="10" step="1">`;
      body.appendChild(r1);
      const rng = r1.querySelector('#ctw-hot'), hval = r1.querySelector('#ctw-hval');
      rng.value = hotlap; hval.textContent = hotlap <= 1 ? 'cruise' : (hotlap >= 9 ? 'qualy' : hotlap);
      rng.addEventListener('input', () => {
        hotlap = parseInt(rng.value, 10); window.__circuitHotlap = hotlap;
        hval.textContent = hotlap <= 1 ? 'cruise' : (hotlap >= 9 ? 'qualy' : hotlap);
        persist({ hotlap });
      });
      return true;
    }
    let tries = 0; const iv = setInterval(() => { if (inject() || ++tries > 40) clearInterval(iv); }, 120);
  })();

})();
