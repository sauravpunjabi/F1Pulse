/* ───────────────────────────────────────────────────────────────────────────
   hm-scrubber.jsx — the finale. "Seventy-six years in one gesture." A lever
   you physically drag: the year counts, the machine morphs (cigar → ground-
   effect → modern), the palette shifts and the engine note tracks your hand.
   Pure drag (independent of scroll). Imperative DOM updates for 60fps.
   Exports window.Scrubber.
   ─────────────────────────────────────────────────────────────────────────── */
const { useEffect: useEffectSc, useRef: useRefSc } = React;

const MACHINE = {
  cigar:  { bw: 360, bh: 34, br: 26, fw: 36,  rw: 44,  wh: 22 },
  wing:   { bw: 300, bh: 54, br: 46, fw: 122, rw: 156, wh: 30 },
  modern: { bw: 332, bh: 46, br: 38, fw: 150, rw: 176, wh: 28 },
};

function hx(h) { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
function mix(a, b, t) { const A = hx(a), B = hx(b); return `rgb(${A.map((x, i) => Math.round(x + (B[i] - x) * t)).join(',')})`; }
function lerp(a, b, t) { return a + (b - a) * t; }

function Scrubber() {
  const nodes = window.HM.scrub.nodes;
  const N = nodes.length;
  const posRef = useRefSc(0);
  const touchedRef = useRefSc(false);

  const refs = {
    track: useRefSc(null), fill: useRefSc(null), handle: useRefSc(null),
    year: useRefSc(null), label: useRefSc(null), speed: useRefSc(null),
    body: useRefSc(null), wingF: useRefSc(null), wingR: useRefSc(null),
    wheelF: useRefSc(null), wheelR: useRefSc(null), glow: useRefSc(null),
    stage: useRefSc(null), hint: useRefSc(null), ticks: useRefSc([]),
  };

  const render = (pos) => {
    pos = Math.max(0, Math.min(1, pos));
    posRef.current = pos;
    const f = pos * (N - 1);
    const i0 = Math.min(N - 1, Math.floor(f));
    const i1 = Math.min(N - 1, i0 + 1);
    const t = f - i0;
    const a = nodes[i0], b = nodes[i1];

    const accent = mix(a.accent, b.accent, t);
    const year = Math.round(lerp(parseInt(a.year, 10), parseInt(b.year, 10), t));
    const speed = Math.round(lerp(a.speed, b.speed, t));
    const ma = MACHINE[a.body], mb = MACHINE[b.body];
    const M = (k) => lerp(ma[k], mb[k], t);

    if (refs.stage.current) refs.stage.current.style.setProperty('--accent', accent);
    if (refs.year.current) refs.year.current.textContent = year;
    if (refs.label.current) refs.label.current.textContent = (t < 0.5 ? a : b).label;
    if (refs.speed.current) refs.speed.current.innerHTML = `<b>${speed}</b> km/h · qualifying trim`;

    const body = refs.body.current;
    if (body) { body.style.width = M('bw') + 'px'; body.style.height = M('bh') + 'px'; body.style.borderRadius = M('br') + 'px / ' + (M('br') * 1.4) + 'px'; }
    const halfBody = M('bw') / 2;
    if (refs.wingF.current) refs.wingF.current.style.width = M('fw') + 'px';
    if (refs.wingR.current) refs.wingR.current.style.width = M('rw') + 'px';
    [refs.wheelF, refs.wheelR].forEach((w) => { if (w.current) { w.current.style.width = M('wh') + 'px'; w.current.style.height = M('wh') + 'px'; } });

    if (refs.fill.current) refs.fill.current.style.width = (pos * 100) + '%';
    if (refs.handle.current) refs.handle.current.style.left = (pos * 100) + '%';

    refs.ticks.current.forEach((el, i) => { if (el) el.classList.toggle('is-on', i <= Math.round(f)); });

    // engine note tracks position
    window.HM.state.scrubRpm = Math.max(window.HM.state.scrubRpm || 0, 0.2 + pos * 0.7);
  };

  const fromClientX = (clientX) => {
    const r = refs.track.current.getBoundingClientRect();
    return (clientX - r.left) / r.width;
  };

  useEffectSc(() => {
    render(0);
    const track = refs.track.current;
    if (!track) return;

    let dragging = false;
    const hideHint = () => {
      if (!touchedRef.current) { touchedRef.current = true; if (refs.hint.current) refs.hint.current.style.opacity = '0'; }
    };
    const down = (e) => {
      dragging = true; hideHint();
      track.classList.add('is-dragging');
      try { track.setPointerCapture(e.pointerId); } catch (_) {}
      render(fromClientX(e.clientX));
    };
    const move = (e) => { if (dragging) render(fromClientX(e.clientX)); };
    const up = () => { dragging = false; track.classList.remove('is-dragging'); };
    track.addEventListener('pointerdown', down);
    track.addEventListener('pointermove', move);
    track.addEventListener('pointerup', up);
    track.addEventListener('pointercancel', up);

    const key = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { hideHint(); render(posRef.current + 1 / (N - 1)); e.preventDefault(); }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { hideHint(); render(posRef.current - 1 / (N - 1)); e.preventDefault(); }
    };
    const handle = refs.handle.current;
    handle && handle.addEventListener('keydown', key);

    return () => {
      track.removeEventListener('pointerdown', down);
      track.removeEventListener('pointermove', move);
      track.removeEventListener('pointerup', up);
      track.removeEventListener('pointercancel', up);
      handle && handle.removeEventListener('keydown', key);
    };
  }, []);

  return (
    <section className="scrub" data-screen-label="Scrub · 76 Years">
      <div className="scrub__pin" ref={refs.stage}>
        <div className="scrub__eyebrow">
          <span className="mono-tick">The whole story · 1950 → 2026</span>
          <h2 className="scrub__lead">Seventy-six years,<br />one gesture</h2>
        </div>

        <div className="scrub__stage">
          <span className="scrub__year" ref={refs.year}>1950</span>

          <div className="machine">
            <div className="machine__glow" ref={refs.glow} />
            <div className="machine__wing machine__wing--f" ref={refs.wingF} />
            <div className="machine__wing machine__wing--r" ref={refs.wingR} />
            <div className="machine__body" ref={refs.body} />
            <div className="machine__wheel machine__wheel--fr" ref={refs.wheelF} />
            <div className="machine__wheel machine__wheel--rr" ref={refs.wheelR} />
          </div>

          <div className="scrub__meta">
            <span className="scrub__label" ref={refs.label}>Front-engined</span>
            <span className="scrub__speed" ref={refs.speed}><b>290</b> km/h · qualifying trim</span>
          </div>
        </div>

        <div className="scrub__bottom">
          <div className="lever">
            <div className="lever__track" ref={refs.track}>
              <div className="lever__rail" />
              <div className="lever__fill" ref={refs.fill} />
              {nodes.map((n, i) => (
                <span key={i} className="lever__tick" ref={(el) => (refs.ticks.current[i] = el)} style={{ left: `${(i / (N - 1)) * 100}%` }} />
              ))}
              <div className="lever__handle" ref={refs.handle} role="slider" tabIndex={0}
                   aria-label="Drag through Formula One history" aria-valuemin={1950} aria-valuemax={2026} style={{ left: 0 }} />
            </div>
            <div className="lever__scale">
              {nodes.map((n, i) => (
                <span key={i} className="lever__yr">{n.year}</span>
              ))}
            </div>
          </div>

          <div className="scrub__hint" ref={refs.hint}>
            <span className="dragdot" /> Grab the marker and drag through time
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Scrubber });
