/* ───────────────────────────────────────────────────────────────────────────
   ds-stats.jsx — the signature animated stat sequence ("THE RECORD").
   Count-ups, telemetry bar fills, self-drawing qualifying trace, win cadence.
   Exports window.DriverStats.
   ─────────────────────────────────────────────────────────────────────────── */
const dsStatsData = window.DS;

/* A single bar that fills on view — used for the season win cadence. */
function CadenceBar({ value, max, label, sub, accent, mono, delay = 0 }) {
  const [ref, seen] = useInView({ threshold: 0.4 });
  const motion = useMotion();
  const pct = Math.max(0.02, value / max);
  return (
    <div ref={ref} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.18em', color: 'rgba(245,244,240,0.55)' }}>{label}</span>
        <span style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 18, color: mono ? 'rgba(245,244,240,0.5)' : '#F5F4F0' }}>{value}</span>
      </div>
      <div style={{ height: 4, background: 'rgba(255,255,255,0.08)', position: 'relative', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', inset: 0, transformOrigin: 'left',
          transform: `scaleX(${seen ? pct : 0})`,
          background: mono ? 'rgba(245,244,240,0.35)' : accent,
          boxShadow: mono ? 'none' : `0 0 12px ${accent}`,
          transition: `transform ${1.1 * motion}s cubic-bezier(0.16,1,0.3,1) ${delay * motion}s`,
        }} />
      </div>
      {sub && <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.12em', color: 'rgba(245,244,240,0.3)' }}>{sub}</span>}
    </div>
  );
}

function BigStat({ value, label, suffix, accent, dir, decimals }) {
  const labelFont = dir === 'archive' ? 'var(--serif)' : 'var(--mono)';
  const labelStyle = dir === 'archive'
    ? { fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 15, color: 'rgba(245,244,240,0.55)' }
    : { fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.4)' };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <CountUp to={value} suffix={suffix} decimals={decimals} duration={2.3}
        style={{ fontFamily: 'var(--display)', fontWeight: 900, lineHeight: 0.85, fontSize: 'clamp(48px,6.5vw,104px)', letterSpacing: '-0.02em', fontVariantNumeric: 'tabular-nums', color: '#F5F4F0' }} />
      <span style={labelStyle}>{label}</span>
    </div>
  );
}

function DriverStats({ dir, accent }) {
  const { driver, seasons, lapTrace } = dsStatsData;
  const c = driver.career;
  const maxWins = Math.max(...seasons.map((s) => s.wins));

  return (
    <section className="stats theme-dark" style={{ background: '#0a0a0b', color: '#F5F4F0', position: 'relative' }}>
      <div className="stats-inner">

        {/* Eyebrow */}
        <div className="stats-head">
          <span style={{ width: 8, height: 8, background: accent, borderRadius: 99, boxShadow: `0 0 12px ${accent}` }} />
          <span style={{ fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '0.4em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.5)' }}>The Record</span>
          <RevealLine color="rgba(255,255,255,0.12)" style={{ flex: 1 }} />
          <span style={{ fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '0.2em', color: 'rgba(245,244,240,0.35)' }}>1984—1994</span>
        </div>

        {/* ── Signature: 65 poles + drawing trace ──────────────────────────── */}
        <div className="poles-hero">
          <div className="poles-hero__num">
            <CountUp to={c.poles} duration={2.6}
              style={{ fontFamily: 'var(--display)', fontWeight: 900, lineHeight: 0.78, fontSize: 'clamp(140px,30vw,440px)', letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', color: '#F5F4F0', display: 'block' }} />
            <div className="poles-hero__caption">
              <span style={{ fontFamily: dir === 'archive' ? 'var(--serif)' : 'var(--display)', fontStyle: dir === 'archive' ? 'italic' : 'normal', fontWeight: dir === 'archive' ? 400 : 800, textTransform: dir === 'archive' ? 'none' : 'uppercase', fontSize: 'clamp(20px,2.4vw,34px)', color: accent }}>Pole Positions</span>
              <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(15px,1.4vw,20px)', color: 'rgba(245,244,240,0.6)', maxWidth: 360, lineHeight: 1.5, margin: '8px 0 0' }}>
                The fastest man over a single lap the sport has known — sixty-five times on the limit, alone.
              </p>
            </div>
          </div>
          <div className="poles-hero__trace">
            <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.25em', color: 'rgba(245,244,240,0.3)' }}>QUALIFYING TRACE · MONACO</span>
            <TelemetryTrace points={lapTrace} stroke={accent} strokeWidth={2.5} glow trigger="scroll" duration={2.4}
              fill={`${accent}14`}
              style={{ width: '100%', height: 'clamp(120px,18vh,200px)', color: accent, marginTop: 10 }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.2em', color: 'rgba(245,244,240,0.3)' }}>SECTOR 1</span>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.2em', color: 'rgba(245,244,240,0.3)' }}>SECTOR 2</span>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.2em', color: 'rgba(245,244,240,0.3)' }}>SECTOR 3</span>
            </div>
          </div>
        </div>

        {/* ── Count-up grid ────────────────────────────────────────────────── */}
        <div className="stats-grid">
          <BigStat value={c.titles} label="World Championships" accent={accent} dir={dir} />
          <BigStat value={c.wins} label="Grand Prix Wins" accent={accent} dir={dir} />
          <BigStat value={c.podiums} label="Podiums" accent={accent} dir={dir} />
          <BigStat value={c.starts} label="Race Starts" accent={accent} dir={dir} />
          <BigStat value={c.fastestLaps} label="Fastest Laps" accent={accent} dir={dir} />
          <BigStat value={c.points} label="Career Points" accent={accent} dir={dir} />
        </div>

        {/* ── Win cadence across seasons ───────────────────────────────────── */}
        <div className="cadence">
          <div className="cadence__head">
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.45)' }}>Wins, season by season</span>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.2em', color: 'rgba(245,244,240,0.3)' }}>{maxWins} max</span>
          </div>
          <div className="cadence__grid">
            {seasons.filter((s) => s.year < 1994).map((s, i) => (
              <CadenceBar key={s.year} value={s.wins} max={maxWins}
                label={`${s.year}`} sub={`${s.team}`} accent={accent}
                mono={s.mono} delay={i * 0.05} />
            ))}
          </div>
        </div>

        {/* ── Monaco signature highlight ───────────────────────────────────── */}
        <div className="monaco">
          <div className="monaco__big">
            <CountUp to={c.monacoWins} duration={2}
              style={{ fontFamily: 'var(--display)', fontWeight: 900, fontSize: 'clamp(90px,16vw,200px)', lineHeight: 0.8, color: accent, fontVariantNumeric: 'tabular-nums' }} />
          </div>
          <div className="monaco__text">
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.45)' }}>Monaco Grand Prix</span>
            <h3 style={{ fontFamily: dir === 'archive' ? 'var(--serif)' : 'var(--display)', fontStyle: dir === 'archive' ? 'italic' : 'normal', fontWeight: dir === 'archive' ? 500 : 800, textTransform: dir === 'archive' ? 'none' : 'uppercase', fontSize: 'clamp(28px,3.4vw,52px)', lineHeight: 1, margin: '12px 0 14px' }}>
              Master of the Principality
            </h3>
            <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(15px,1.4vw,21px)', lineHeight: 1.6, color: 'rgba(245,244,240,0.66)', maxWidth: 440, margin: 0 }}>
              Five victories in a row, six in all — a command of the streets between the barriers that has never been equalled.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
}

Object.assign(window, { DriverStats, CadenceBar, BigStat });
