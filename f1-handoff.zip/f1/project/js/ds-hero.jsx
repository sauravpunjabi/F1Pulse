/* ───────────────────────────────────────────────────────────────────────────
   ds-hero.jsx — cinematic dark hero, three art directions.
   dir: 'broadcast' | 'archive' | 'telemetry'.   Exports window.DriverHero.
   ─────────────────────────────────────────────────────────────────────────── */
const { driver, lapTrace } = window.DS;

/* Striped placeholder for the driver portrait (no real imagery yet). */
function Portrait({ label, ratio = '3 / 4', tone = 'dark', className, style }) {
  const stripe = tone === 'dark'
    ? 'repeating-linear-gradient(135deg, #1a1a1c 0 14px, #18181a 14px 28px)'
    : 'repeating-linear-gradient(135deg, #e9e7e1 0 14px, #e4e2dc 14px 28px)';
  const fg = tone === 'dark' ? 'rgba(255,255,255,0.32)' : 'rgba(0,0,0,0.4)';
  const bd = tone === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.12)';
  return (
    <div className={className} style={{ aspectRatio: ratio, background: stripe, border: `1px solid ${bd}`, position: 'relative', overflow: 'hidden', ...style }}>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, textAlign: 'center', padding: 16 }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.3em', textTransform: 'uppercase', color: fg }}>▢ portrait</span>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.18em', color: fg, maxWidth: '80%' }}>{label}</span>
      </div>
    </div>
  );
}

function HudTick({ children, style }) {
  return <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', ...style }}>{children}</span>;
}

/* ── Direction A — BROADCAST ──────────────────────────────────────────────── */
function HeroBroadcast({ accent }) {
  return (
    <section className="hero" style={{ background: 'radial-gradient(120% 90% at 70% 30%, #161213 0%, #0c0c0d 55%, #070707 100%)', color: '#F5F4F0' }}>
      <div className="hero-hud hero-hud--top">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: accent, boxShadow: `0 0 10px ${accent}` }} className="pulse" />
          <HudTick>F1Pulse · Pantheon</HudTick>
        </div>
        <HudTick>Driver Dossier № 12</HudTick>
        <HudTick style={{ color: accent }}>Brazil 🇧🇷</HudTick>
      </div>

      {/* Ghost number */}
      <span aria-hidden="true" style={{ position: 'absolute', right: '-2vw', top: '50%', transform: 'translateY(-50%)', fontFamily: 'var(--display)', fontWeight: 900, fontSize: '52vh', lineHeight: 0.7, color: 'transparent', WebkitTextStroke: '1px rgba(255,255,255,0.05)', pointerEvents: 'none', userSelect: 'none' }}>{driver.number}</span>

      <div className="hero-center">
        <SplitReveal as="div" text={driver.first} className="hero-eyebrow" stagger={0.02} delay={0.1}
          style={{ fontFamily: 'var(--mono)', fontSize: 'clamp(11px,1.4vw,15px)', letterSpacing: '0.6em', color: accent, marginLeft: '0.6em' }} />
        <h1 className="hero-name" style={{ fontFamily: 'var(--display)', fontWeight: 900, textTransform: 'uppercase', lineHeight: 0.8, fontSize: 'clamp(72px,20vw,340px)', letterSpacing: '-0.02em', margin: 0 }}>
          <SplitReveal text={driver.last} stagger={0.05} delay={0.25} />
        </h1>
        <div className="hero-underline">
          <RevealLine color="rgba(255,255,255,0.25)" delay={0.9} style={{ width: 'min(680px, 70vw)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, width: 'min(680px, 70vw)' }}>
            <HudTick>{driver.span}</HudTick>
            <HudTick>3× World Champion</HudTick>
            <HudTick>{driver.career.poles} Poles</HudTick>
          </div>
        </div>
      </div>

      <div className="hero-hud hero-hud--bottom">
        <HudTick>{driver.birthplace}</HudTick>
        <span className="scroll-cue"><HudTick style={{ color: accent }}>Scroll — the record</HudTick><span className="scroll-arrow" style={{ color: accent }}>↓</span></span>
      </div>
    </section>
  );
}

/* ── Direction B — ARCHIVE (museum / editorial) ───────────────────────────── */
function HeroArchive({ accent }) {
  return (
    <section className="hero" style={{ background: '#0d0d0e', color: '#F5F4F0', justifyContent: 'center' }}>
      <div className="hero-hud hero-hud--top">
        <HudTick>The Pantheon · Plate I</HudTick>
        <HudTick>F1Pulse Archive</HudTick>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 28, maxWidth: 1100, padding: '0 6vw', textAlign: 'center' }}>
        <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(16px,2.4vw,30px)', color: accent }} className="fade-up">An eternal portrait in motion</span>

        {/* Framed museum plate */}
        <figure className="archive-frame fade-up" style={{ margin: 0 }}>
          <Portrait label="Senna · Monaco · 1990" ratio="16 / 10" tone="dark" style={{ width: 'min(560px, 72vw)' }} />
          <figcaption className="archive-plaque">
            <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.25em' }}>{driver.full.toUpperCase()}</span>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 8, letterSpacing: '0.18em', opacity: 0.6 }}>McLaren MP4/5B · oil & carbon on tarmac</span>
          </figcaption>
        </figure>

        <h1 style={{ fontFamily: 'var(--display)', fontWeight: 900, textTransform: 'uppercase', lineHeight: 0.82, fontSize: 'clamp(54px,9vw,150px)', margin: 0, letterSpacing: '-0.01em' }}>
          <SplitReveal text="AYRTON SENNA" stagger={0.035} delay={0.3} />
        </h1>
        <p style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(15px,1.5vw,22px)', lineHeight: 1.6, maxWidth: 620, color: 'rgba(245,244,240,0.72)' }} className="fade-up">{driver.epitaph}</p>
      </div>

      <div className="hero-hud hero-hud--bottom">
        <HudTick>{driver.born} — {driver.birthplace}</HudTick>
        <span className="scroll-cue"><HudTick>Turn the page</HudTick><span className="scroll-arrow">↓</span></span>
      </div>
    </section>
  );
}

/* ── Direction C — TELEMETRY (data-forward) ───────────────────────────────── */
function HeroTelemetry({ accent }) {
  const rows = [
    ['DRIVER', driver.full],
    ['BORN', driver.born],
    ['ACTIVE', driver.span],
    ['TITLES', '03'],
    ['POLES', String(driver.career.poles)],
    ['WINS', String(driver.career.wins)],
  ];
  return (
    <section className="hero hero--grid" style={{ background: '#08090a', color: '#EAF2EF' }}>
      <div className="hero-hud hero-hud--top">
        <HudTick style={{ color: accent }}>● LIVE TRACE · QUALI LAP</HudTick>
        <HudTick>SESSION — SENNA / MONACO / 1990</HudTick>
      </div>

      <div className="telemetry-hero">
        <div className="telemetry-hero__name">
          <span style={{ fontFamily: 'var(--mono)', fontSize: 'clamp(11px,1.3vw,14px)', letterSpacing: '0.5em', color: accent }}>№ {driver.number} / {driver.code}</span>
          <h1 style={{ fontFamily: 'var(--display)', fontWeight: 900, textTransform: 'uppercase', lineHeight: 0.82, fontSize: 'clamp(60px,13vw,210px)', margin: '6px 0 0', letterSpacing: '-0.02em' }}>
            <SplitReveal text={driver.last} stagger={0.05} delay={0.2} />
          </h1>
        </div>

        <div className="telemetry-hero__readout">
          {rows.map(([k, v], i) => (
            <div className="telemetry-row" key={k} style={{ animationDelay: `${0.4 + i * 0.08}s` }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.25em', color: 'rgba(234,242,239,0.4)' }}>{k}</span>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '0.08em', color: accent }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <TelemetryTrace points={lapTrace} className="telemetry-hero__trace" stroke={accent} strokeWidth={2} glow trigger="mount" duration={2.6}
        style={{ position: 'absolute', left: 0, bottom: '14%', width: '100%', height: '26vh', color: accent, opacity: 0.9 }} />

      <div className="hero-hud hero-hud--bottom">
        <HudTick>VMAX 0.99 · S2 PURPLE · GAP −0.000</HudTick>
        <span className="scroll-cue"><HudTick style={{ color: accent }}>Scroll telemetry</HudTick><span className="scroll-arrow" style={{ color: accent }}>↓</span></span>
      </div>
    </section>
  );
}

function DriverHero({ dir, accent }) {
  if (dir === 'archive') return <HeroArchive accent={accent} />;
  if (dir === 'telemetry') return <HeroTelemetry accent={accent} />;
  return <HeroBroadcast accent={accent} />;
}

Object.assign(window, { DriverHero, Portrait, HudTick });
