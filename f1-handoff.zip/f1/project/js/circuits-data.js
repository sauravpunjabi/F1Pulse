/* ============================================================================
   F1Pulse — Circuits · The Grand Tour
   2026 World Championship calendar. Real circuits, geo-positions, records;
   track silhouettes are stylised point-loops (smoothed into beziers at runtime).
   Coordinates P are in a normalised 0..100 box.
   ========================================================================== */
window.CIRCUITS = [
  {
    r: 1, gp: "Australian Grand Prix", circuit: "Albert Park Circuit", city: "Melbourne", country: "Australia", cc: "AUS",
    date: "March 8", dateShort: "MAR 08", region: "Oceania", type: "Street / Park",
    len: 5.278, corners: 14, laps: 58, dist: 306.1, record: "1:19.813", recordBy: "C. Leclerc · 2024", firstHeld: 1996, drs: 4,
    lat: -37.85, lon: 144.97, sectors: [0.34, 0.67],
    beat: "Lights out, first. The parkland sweeps around Albert Park lake have opened the modern season since 1996.",
    P: [[30,70],[26,58],[24,46],[30,36],[40,28],[54,24],[68,26],[78,32],[82,42],[78,50],[70,52],[66,60],[70,68],[64,76],[52,80],[40,80],[33,76]]
  },
  {
    r: 2, gp: "Chinese Grand Prix", circuit: "Shanghai International Circuit", city: "Shanghai", country: "China", cc: "CHN",
    date: "March 15", dateShort: "MAR 15", region: "Asia", type: "Permanent",
    len: 5.451, corners: 16, laps: 56, dist: 305.1, record: "1:32.238", recordBy: "M. Schumacher · 2004", firstHeld: 2004, drs: 2,
    lat: 31.34, lon: 121.22, sectors: [0.33, 0.70],
    beat: "Drawn as the character 上 — 'rising'. A snail of a first corner unwinds into one of the longest straights in the sport.",
    P: [[30,28],[44,24],[60,24],[74,28],[80,36],[74,42],[60,42],[50,46],[52,54],[64,54],[76,56],[80,64],[74,74],[60,78],[44,78],[32,72],[28,62],[34,54],[42,48],[38,40],[30,36]]
  },
  {
    r: 3, gp: "Japanese Grand Prix", circuit: "Suzuka Circuit", city: "Suzuka", country: "Japan", cc: "JPN",
    date: "March 29", dateShort: "MAR 29", region: "Asia", type: "Permanent",
    len: 5.807, corners: 18, laps: 53, dist: 307.5, record: "1:30.983", recordBy: "L. Hamilton · 2019", firstHeld: 1987, drs: 1,
    lat: 34.84, lon: 136.54, sectors: [0.36, 0.66],
    beat: "The only figure-of-eight on the calendar — the track crosses over itself. The Esses and 130R remain a driver's true examination.",
    P: [[30,30],[44,24],[58,26],[64,36],[58,44],[48,46],[54,54],[64,58],[72,66],[66,76],[52,78],[42,72],[46,62],[40,52],[30,48],[26,38]]
  },
  {
    r: 4, gp: "Bahrain Grand Prix", circuit: "Bahrain International Circuit", city: "Sakhir", country: "Bahrain", cc: "BHR",
    date: "April 12", dateShort: "APR 12", region: "Middle East", type: "Permanent",
    len: 5.412, corners: 15, laps: 57, dist: 308.2, record: "1:31.447", recordBy: "P. de la Rosa · 2005", firstHeld: 2004, drs: 3,
    lat: 26.03, lon: 50.51, sectors: [0.35, 0.68],
    beat: "Floodlit desert stop-go. Heavy braking zones under the lights make it the great early-season equaliser.",
    P: [[28,32],[42,28],[56,30],[64,26],[72,32],[68,42],[58,44],[52,50],[58,56],[68,56],[74,64],[68,72],[54,74],[42,72],[32,66],[30,56],[38,52],[34,44],[26,40]]
  },
  {
    r: 5, gp: "Saudi Arabian Grand Prix", circuit: "Jeddah Corniche Circuit", city: "Jeddah", country: "Saudi Arabia", cc: "SAU",
    date: "April 19", dateShort: "APR 19", region: "Middle East", type: "Street",
    len: 6.174, corners: 27, laps: 50, dist: 308.5, record: "1:30.734", recordBy: "L. Hamilton · 2021", firstHeld: 2021, drs: 3,
    lat: 21.63, lon: 39.10, sectors: [0.34, 0.69],
    beat: "The fastest street circuit ever built — blind, walled and flat-out, averaging over 250 km/h along the Red Sea.",
    P: [[44,18],[54,18],[58,26],[54,34],[58,42],[54,50],[60,58],[56,66],[60,74],[52,82],[44,80],[42,72],[46,64],[42,56],[46,48],[42,40],[46,32],[40,26],[42,20]]
  },
  {
    r: 6, gp: "Miami Grand Prix", circuit: "Miami International Autodrome", city: "Miami Gardens", country: "United States", cc: "USA",
    date: "May 3", dateShort: "MAY 03", region: "Americas", type: "Street",
    len: 5.412, corners: 19, laps: 57, dist: 308.3, record: "1:29.708", recordBy: "M. Verstappen · 2023", firstHeld: 2022, drs: 3,
    lat: 25.96, lon: -80.24, sectors: [0.33, 0.67],
    beat: "A circuit wrapped around the Hard Rock Stadium, complete with a faux marina. Spectacle first — but a quick, technical middle sector.",
    P: [[30,44],[34,32],[46,28],[60,30],[72,36],[80,46],[76,56],[66,62],[56,60],[50,54],[44,58],[48,66],[58,70],[50,76],[38,74],[30,66],[28,54]]
  },
  {
    r: 7, gp: "Canadian Grand Prix", circuit: "Circuit Gilles Villeneuve", city: "Montreal", country: "Canada", cc: "CAN",
    date: "May 24", dateShort: "MAY 24", region: "Americas", type: "Street / Park",
    len: 4.361, corners: 14, laps: 70, dist: 305.3, record: "1:13.078", recordBy: "V. Bottas · 2019", firstHeld: 1978, drs: 3,
    lat: 45.50, lon: -73.52, sectors: [0.35, 0.66],
    beat: "An island circuit of long straights and tight chicanes. The 'Wall of Champions' has ended more than a few title runs.",
    P: [[24,40],[34,32],[48,30],[62,30],[74,34],[80,42],[76,48],[64,48],[52,48],[44,52],[50,58],[62,60],[72,62],[76,70],[68,76],[54,76],[42,72],[34,64],[30,54],[26,46]]
  },
  {
    r: 8, gp: "Monaco Grand Prix", circuit: "Circuit de Monaco", city: "Monte Carlo", country: "Monaco", cc: "MON",
    date: "June 7", dateShort: "JUN 07", region: "Europe", type: "Street",
    len: 3.337, corners: 19, laps: 78, dist: 260.3, record: "1:12.909", recordBy: "L. Hamilton · 2021", firstHeld: 1950, drs: 1,
    lat: 43.73, lon: 7.42, sectors: [0.32, 0.68],
    beat: "The crown jewel — run through the principality's streets since 1929. Qualifying is everything; overtaking is a rumour.",
    P: [[34,28],[46,24],[54,28],[52,36],[44,40],[48,46],[58,44],[68,46],[72,54],[66,60],[58,58],[60,66],[68,70],[64,78],[52,78],[42,74],[38,66],[42,58],[38,50],[32,44],[30,36]]
  },
  {
    r: 9, gp: "Spanish Grand Prix", circuit: "Circuit de Barcelona-Catalunya", city: "Barcelona", country: "Spain", cc: "ESP",
    date: "June 14", dateShort: "JUN 14", region: "Europe", type: "Permanent",
    len: 4.657, corners: 14, laps: 66, dist: 307.2, record: "1:16.330", recordBy: "M. Verstappen · 2023", firstHeld: 1991, drs: 2,
    lat: 41.57, lon: 2.26, sectors: [0.34, 0.67],
    beat: "Every engineer's reference track — drivers have tested here so often they could lap it blind. Aero efficiency is laid bare.",
    P: [[28,36],[36,28],[50,26],[64,28],[74,34],[78,44],[72,52],[62,52],[56,58],[62,64],[70,68],[64,74],[52,74],[44,68],[46,60],[40,56],[34,60],[30,52],[30,44]]
  },
  {
    r: 10, gp: "Austrian Grand Prix", circuit: "Red Bull Ring", city: "Spielberg", country: "Austria", cc: "AUT",
    date: "June 28", dateShort: "JUN 28", region: "Europe", type: "Permanent",
    len: 4.318, corners: 10, laps: 71, dist: 306.5, record: "1:05.619", recordBy: "C. Sainz · 2020", firstHeld: 1970, drs: 3,
    lat: 47.22, lon: 14.76, sectors: [0.33, 0.66],
    beat: "Short, sharp and brutal on brakes — three long climbs and three heavy stops, all framed by the Styrian mountains.",
    P: [[30,68],[34,52],[40,38],[50,28],[62,30],[68,40],[60,48],[64,58],[74,64],[70,74],[56,76],[44,76],[34,74]]
  },
  {
    r: 11, gp: "British Grand Prix", circuit: "Silverstone Circuit", city: "Silverstone", country: "United Kingdom", cc: "GBR",
    date: "July 5", dateShort: "JUL 05", region: "Europe", type: "Permanent",
    len: 5.891, corners: 18, laps: 52, dist: 306.2, record: "1:27.097", recordBy: "M. Verstappen · 2020", firstHeld: 1950, drs: 2,
    lat: 52.07, lon: -1.01, sectors: [0.35, 0.68],
    beat: "Where it all began — the first World Championship race, 1950. Maggotts–Becketts is the finest high-speed sequence in racing.",
    P: [[26,46],[32,34],[44,28],[58,26],[70,30],[78,38],[74,48],[64,50],[58,46],[52,52],[58,58],[68,62],[72,70],[62,76],[48,76],[38,70],[34,60],[28,54]]
  },
  {
    r: 12, gp: "Belgian Grand Prix", circuit: "Circuit de Spa-Francorchamps", city: "Stavelot", country: "Belgium", cc: "BEL",
    date: "July 19", dateShort: "JUL 19", region: "Europe", type: "Permanent",
    len: 7.004, corners: 19, laps: 44, dist: 308.1, record: "1:44.701", recordBy: "V. Bottas · 2018", firstHeld: 1950, drs: 2,
    lat: 50.44, lon: 5.97, sectors: [0.33, 0.69],
    beat: "The longest lap on the calendar, carved through the Ardennes forest. Eau Rouge–Raidillon: still the sport's most feared corner.",
    P: [[28,72],[24,56],[28,42],[36,30],[48,24],[58,28],[60,38],[54,46],[60,54],[70,58],[78,66],[74,74],[60,76],[46,76],[36,76]]
  },
  {
    r: 13, gp: "Hungarian Grand Prix", circuit: "Hungaroring", city: "Budapest", country: "Hungary", cc: "HUN",
    date: "July 26", dateShort: "JUL 26", region: "Europe", type: "Permanent",
    len: 4.381, corners: 14, laps: 70, dist: 306.6, record: "1:16.627", recordBy: "L. Hamilton · 2020", firstHeld: 1986, drs: 1,
    lat: 47.58, lon: 19.25, sectors: [0.34, 0.67],
    beat: "Monaco without the walls — twisty, dusty and relentless. Track position is gold; the only place to pass is the long run to Turn 1.",
    P: [[30,34],[42,28],[54,30],[60,38],[54,46],[46,46],[42,52],[50,56],[60,54],[68,60],[64,70],[52,74],[40,72],[32,64],[36,54],[30,46],[26,40]]
  },
  {
    r: 14, gp: "Dutch Grand Prix", circuit: "Circuit Zandvoort", city: "Zandvoort", country: "Netherlands", cc: "NED",
    date: "August 23", dateShort: "AUG 23", region: "Europe", type: "Permanent",
    len: 4.259, corners: 14, laps: 72, dist: 306.6, record: "1:11.097", recordBy: "L. Hamilton · 2021", firstHeld: 1952, drs: 2,
    lat: 52.39, lon: 4.54, sectors: [0.33, 0.66],
    beat: "Banked corners by the North Sea dunes. The steep, cambered final turn launches cars onto the straight like a velodrome.",
    P: [[30,40],[36,30],[48,26],[60,30],[68,38],[64,48],[56,50],[52,58],[60,64],[66,72],[56,76],[44,74],[36,68],[34,58],[40,50],[34,46]]
  },
  {
    r: 15, gp: "Italian Grand Prix", circuit: "Autodromo Nazionale Monza", city: "Monza", country: "Italy", cc: "ITA",
    date: "September 6", dateShort: "SEP 06", region: "Europe", type: "Permanent",
    len: 5.793, corners: 11, laps: 53, dist: 306.7, record: "1:21.046", recordBy: "R. Barrichello · 2004", firstHeld: 1950, drs: 2,
    lat: 45.62, lon: 9.28, sectors: [0.31, 0.66],
    beat: "The Temple of Speed. Lowest-downforce weekend of the year, 360 km/h on the straights, and the tifosi turning red.",
    P: [[30,24],[44,22],[58,24],[68,30],[64,38],[54,38],[58,46],[68,52],[74,62],[68,72],[54,74],[42,70],[44,60],[40,50],[34,42],[36,32]]
  },
  {
    r: 16, gp: "Madrid Grand Prix", circuit: "Madring", city: "Madrid", country: "Spain", cc: "ESP",
    date: "September 13", dateShort: "SEP 13", region: "Europe", type: "Hybrid Street",
    len: 5.474, corners: 22, laps: 57, dist: 311.9, record: "—", recordBy: "Inaugural — 2026", firstHeld: 2026, drs: 2,
    lat: 40.46, lon: -3.58, sectors: [0.34, 0.68],
    beat: "New for 2026. A hybrid street-and-permanent layout around IFEMA, with a banked corner echoing Spain's racing past.",
    P: [[28,42],[34,32],[46,28],[58,30],[68,34],[74,44],[68,52],[60,50],[54,56],[60,62],[66,70],[56,74],[44,72],[36,66],[34,56],[28,50]]
  },
  {
    r: 17, gp: "Azerbaijan Grand Prix", circuit: "Baku City Circuit", city: "Baku", country: "Azerbaijan", cc: "AZE",
    date: "September 27", dateShort: "SEP 27", region: "Asia", type: "Street",
    len: 6.003, corners: 20, laps: 51, dist: 306.0, record: "1:43.009", recordBy: "C. Leclerc · 2019", firstHeld: 2016, drs: 2,
    lat: 40.37, lon: 49.85, sectors: [0.32, 0.70],
    beat: "A 2.2 km blast past the Caspian flanked by the tight, medieval old-town walls. Equal parts top speed and claustrophobia.",
    P: [[22,64],[22,52],[28,42],[38,36],[44,42],[40,50],[46,52],[52,46],[58,40],[54,34],[62,32],[70,36],[68,44],[74,50],[80,56],[78,64],[64,66],[48,66],[34,66]]
  },
  {
    r: 18, gp: "Singapore Grand Prix", circuit: "Marina Bay Street Circuit", city: "Singapore", country: "Singapore", cc: "SGP",
    date: "October 11", dateShort: "OCT 11", region: "Asia", type: "Street",
    len: 4.940, corners: 19, laps: 62, dist: 306.3, record: "1:34.486", recordBy: "L. Hamilton · 2023", firstHeld: 2008, drs: 3,
    lat: 1.29, lon: 103.86, sectors: [0.34, 0.67],
    beat: "The original night race — humid, bumpy and almost two hours long. A brutal physical test under the Marina Bay skyline.",
    P: [[28,36],[40,30],[52,32],[58,28],[66,32],[62,40],[54,42],[58,48],[68,48],[74,54],[70,62],[60,62],[56,68],[64,72],[58,78],[46,76],[42,68],[46,60],[40,56],[34,60],[30,52],[34,44]]
  },
  {
    r: 19, gp: "United States Grand Prix", circuit: "Circuit of the Americas", city: "Austin", country: "United States", cc: "USA",
    date: "October 25", dateShort: "OCT 25", region: "Americas", type: "Permanent",
    len: 5.513, corners: 20, laps: 56, dist: 308.4, record: "1:36.169", recordBy: "C. Leclerc · 2019", firstHeld: 2012, drs: 2,
    lat: 30.13, lon: -97.64, sectors: [0.33, 0.67],
    beat: "A steep blind climb to Turn 1, then a homage lap — Silverstone's esses, Hockenheim's stadium, all rebuilt in Texas.",
    P: [[30,72],[28,56],[32,42],[40,30],[50,26],[58,32],[54,42],[60,48],[70,46],[78,52],[74,62],[64,62],[58,68],[64,74],[54,78],[44,76],[36,74]]
  },
  {
    r: 20, gp: "Mexico City Grand Prix", circuit: "Autódromo Hermanos Rodríguez", city: "Mexico City", country: "Mexico", cc: "MEX",
    date: "November 1", dateShort: "NOV 01", region: "Americas", type: "Permanent",
    len: 4.304, corners: 17, laps: 71, dist: 305.4, record: "1:17.774", recordBy: "V. Bottas · 2021", firstHeld: 1963, drs: 3,
    lat: 19.40, lon: -99.09, sectors: [0.34, 0.68],
    beat: "Thin air at 2,200 m above sea level starves the engines and the wings. The lap finishes through a roaring baseball stadium.",
    P: [[26,42],[34,32],[48,28],[62,30],[74,34],[80,44],[74,52],[62,52],[54,56],[60,62],[58,70],[48,72],[40,68],[44,60],[38,56],[44,50],[36,48],[30,50]]
  },
  {
    r: 21, gp: "São Paulo Grand Prix", circuit: "Autódromo José Carlos Pace", city: "São Paulo", country: "Brazil", cc: "BRA",
    date: "November 8", dateShort: "NOV 08", region: "Americas", type: "Permanent",
    len: 4.309, corners: 15, laps: 71, dist: 305.9, record: "1:10.540", recordBy: "V. Bottas · 2018", firstHeld: 1973, drs: 2,
    lat: -23.70, lon: -46.70, sectors: [0.32, 0.66],
    beat: "Interlagos — compact, anticlockwise and run on the throttle. Few circuits have delivered more title-deciding drama.",
    P: [[34,28],[48,26],[58,30],[62,40],[56,48],[64,54],[70,64],[62,72],[48,74],[38,70],[36,60],[44,54],[38,48],[32,52],[28,42],[30,34]]
  },
  {
    r: 22, gp: "Las Vegas Grand Prix", circuit: "Las Vegas Strip Circuit", city: "Las Vegas", country: "United States", cc: "USA",
    date: "November 21", dateShort: "NOV 21", region: "Americas", type: "Street",
    len: 6.201, corners: 17, laps: 50, dist: 309.9, record: "1:35.490", recordBy: "O. Piastri · 2023", firstHeld: 2023, drs: 2,
    lat: 36.11, lon: -115.17, sectors: [0.31, 0.70],
    beat: "Midnight on the Strip. A 1.9 km straight down Las Vegas Boulevard, neon overhead, slipstreams at 340 km/h.",
    P: [[22,40],[40,36],[58,34],[74,34],[82,40],[78,48],[62,48],[50,50],[54,58],[68,60],[76,66],[70,74],[52,74],[36,72],[26,64],[24,52]]
  },
  {
    r: 23, gp: "Qatar Grand Prix", circuit: "Lusail International Circuit", city: "Lusail", country: "Qatar", cc: "QAT",
    date: "November 29", dateShort: "NOV 29", region: "Middle East", type: "Permanent",
    len: 5.419, corners: 16, laps: 57, dist: 308.6, record: "1:24.319", recordBy: "M. Verstappen · 2024", firstHeld: 2021, drs: 1,
    lat: 25.49, lon: 51.45, sectors: [0.35, 0.68],
    beat: "A flowing motorcycle circuit run under lights — fast, sweeping, and savagely demanding on the neck and the tyres.",
    P: [[28,40],[36,30],[48,26],[60,28],[70,34],[76,44],[70,52],[60,52],[54,58],[60,66],[54,74],[42,74],[34,68],[32,58],[38,50],[30,46]]
  },
  {
    r: 24, gp: "Abu Dhabi Grand Prix", circuit: "Yas Marina Circuit", city: "Abu Dhabi", country: "United Arab Emirates", cc: "UAE",
    date: "December 6", dateShort: "DEC 06", region: "Middle East", type: "Permanent",
    len: 5.281, corners: 16, laps: 58, dist: 306.2, record: "1:25.637", recordBy: "M. Verstappen · 2021", firstHeld: 2009, drs: 2,
    lat: 24.47, lon: 54.60, sectors: [0.34, 0.69],
    beat: "The finale. A twilight race that starts in daylight and ends under floodlights — where seasons, and legacies, are settled.",
    P: [[26,36],[40,30],[54,30],[66,28],[76,34],[74,44],[62,44],[54,48],[58,56],[68,58],[72,66],[62,72],[48,72],[40,66],[44,58],[38,54],[30,52],[26,44]]
  }
];
