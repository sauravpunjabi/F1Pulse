/* ───────────────────────────────────────────────────────────────────────────
   hm-threshold.jsx — the deliberate entry. House lights dim, the projector
   warms, the wordmark resolves out of blur, and a subtle cursor-parallax makes
   the title feel physically present. Exports window.Threshold.
   ─────────────────────────────────────────────────────────────────────────── */
const { useState: useStateTh, useEffect: useEffectTh, useRef: useRefTh } = React;

function Threshold({ accent }) {
  const [lit, setLit] = useStateTh(true);
  const [phase, setPhase] = useStateTh(0);
  const titleRef = useRefTh(null);
  const reduced = (typeof window !== 'undefined') && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffectTh(() => {
    if (reduced) { setLit(false); setPhase(3); return; }
    const t0 = setTimeout(() => setLit(false), 200);
    const t1 = setTimeout(() => setPhase(1), 1100);
    const t2 = setTimeout(() => setPhase(2), 1700);
    const t3 = setTimeout(() => setPhase(3), 2600);
    return () => [t0, t1, t2, t3].forEach(clearTimeout);
  }, []);

  // cursor parallax on the wordmark
  useEffectTh(() => {
    if (reduced) return;
    const onMove = (e) => {
      const el = titleRef.current; if (!el) return;
      const dx = (e.clientX / window.innerWidth - 0.5);
      const dy = (e.clientY / window.innerHeight - 0.5);
      el.style.transform = `translate(${(-dx * 22).toFixed(1)}px, ${(-dy * 14).toFixed(1)}px)`;
    };
    window.addEventListener('pointermove', onMove);
    return () => window.removeEventListener('pointermove', onMove);
  }, []);

  const ease = 'cubic-bezier(0.16,1,0.3,1)';
  const word = (on, delay) => ({
    display: 'inline-block', opacity: on ? 1 : 0,
    transform: on ? 'translateY(0)' : 'translateY(0.5em)',
    filter: on ? 'blur(0)' : 'blur(10px)',
    transition: `opacity 1s ${ease} ${delay}s, transform 1.1s ${ease} ${delay}s, filter 1s ease ${delay}s`,
  });
  const soft = (on, dy, delay) => ({
    opacity: on ? 1 : 0, transform: on ? 'translateY(0)' : `translateY(${dy}px)`,
    transition: `opacity .9s ${ease} ${delay}s, transform .9s ${ease} ${delay}s`,
  });

  return (
    <section id="sec-threshold" className="threshold" data-screen-label="Threshold">
      <div className="threshold__house" style={{ opacity: lit ? 1 : 0 }} />

      <div className="threshold__top">
        <span className="mono-tick">F1Pulse · Archive</span>
        <span className="mono-tick">Est. 1950</span>
      </div>

      <div className="threshold__center">
        <div className="threshold__line" style={{ background: accent, width: phase >= 1 ? 'min(360px,60vw)' : 0, height: 1, transition: `width 1.1s ${ease}` }} />
        <span className="threshold__eyebrow" style={soft(phase >= 1, 10, 0)}>You are entering</span>
        <h1 className="threshold__title" ref={titleRef}>
          <span className="threshold__word" style={word(phase >= 2, 0)}>HISTORY</span>
          <span className="threshold__word" style={word(phase >= 2, 0.12)}>MODE</span>
        </h1>
        <p className="threshold__sub" style={soft(phase >= 3, 10, 0.1)}>The Evolution of Speed · 1950 → 2026</p>
      </div>

      <div className="threshold__cue" style={{ opacity: phase >= 3 ? 1 : 0, transition: 'opacity 1s ease' }}>
        <span className="mono-tick" style={{ color: accent }}>Descend into the past</span>
        <span className="threshold__beam" style={{ background: `linear-gradient(${accent}, transparent)` }} />
        <span className="mono-tick" style={{ fontSize: 8.5, opacity: 0.55 }}>↖ best experienced with sound</span>
      </div>
    </section>
  );
}

Object.assign(window, { Threshold });
