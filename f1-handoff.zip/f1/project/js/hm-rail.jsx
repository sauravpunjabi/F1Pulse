/* ───────────────────────────────────────────────────────────────────────────
   hm-rail.jsx — the decade scrubber. Always tells you WHERE in time you are,
   and now lets you GRAB the playhead to scrub the whole archive, or click any
   decade to fly there. Reads HM.state each frame (set by the master controller)
   so its colour + active era stay in lockstep with the page. Exports TimeRail.
   ─────────────────────────────────────────────────────────────────────────── */
const { useEffect: useEffectRail, useRef: useRefRail } = React;

function TimeRail() {
  const decades = window.HM.decades;
  const fillRef = useRefRail(null);
  const headRef = useRefRail(null);
  const capRef = useRefRail(null);
  const nowRef = useRefRail(null);
  const trackRef = useRefRail(null);
  const dotRefs = useRefRail([]);
  const lblRefs = useRefRail([]);

  // imperative per-frame update from shared state
  useEffectRail(() => {
    let lastActive = -1;
    const tick = () => {
      const s = window.HM.state;
      const pct = (s.scroll * 100).toFixed(2) + '%';
      const acc = s.accent || '#C9201A';
      if (fillRef.current) { fillRef.current.style.height = pct; fillRef.current.style.background = acc; }
      if (headRef.current) { headRef.current.style.top = pct; headRef.current.style.borderColor = acc; headRef.current.style.boxShadow = `0 0 12px ${acc}`; }
      if (capRef.current) capRef.current.textContent = String(Math.round(s.scroll * 100)).padStart(2, '0');
      if (nowRef.current) { nowRef.current.textContent = s.activeEra; nowRef.current.style.color = s.colour > 0.05 ? acc : 'rgba(245,244,240,0.7)'; }

      const ai = decades.findIndex((d) => d.era === s.activeEra);
      if (ai !== lastActive) {
        lastActive = ai;
        dotRefs.current.forEach((el, i) => { if (!el) return; const on = i === ai; el.style.transform = on ? 'scale(1.35)' : 'scale(1)'; el.style.background = on ? acc : 'transparent'; el.style.borderColor = on ? acc : 'rgba(255,255,255,0.4)'; });
        lblRefs.current.forEach((el, i) => { if (el) el.style.color = i === ai ? acc : 'rgba(245,244,240,0.4)'; });
      } else if (ai >= 0) {
        if (dotRefs.current[ai]) { dotRefs.current[ai].style.background = acc; dotRefs.current[ai].style.borderColor = acc; }
        if (lblRefs.current[ai]) lblRefs.current[ai].style.color = acc;
      }
    };
    return window.HM.frame.add(tick);
  }, []);

  const scrollToFrac = (frac) => {
    const h = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: Math.max(0, Math.min(h, frac * h)) });
  };

  // grab the playhead / click the track to scrub
  useEffectRail(() => {
    const track = trackRef.current, head = headRef.current;
    if (!track) return;
    let dragging = false;
    const fracFrom = (e) => {
      const r = track.getBoundingClientRect();
      const vert = r.height >= r.width;
      return vert ? (e.clientY - r.top) / r.height : (e.clientX - r.left) / r.width;
    };
    const down = (e) => { dragging = true; head && head.classList.add('is-dragging'); try { track.setPointerCapture(e.pointerId); } catch (_) {} scrollToFrac(fracFrom(e)); };
    const move = (e) => { if (dragging) scrollToFrac(fracFrom(e)); };
    const up = () => { dragging = false; head && head.classList.remove('is-dragging'); };
    track.addEventListener('pointerdown', down);
    track.addEventListener('pointermove', move);
    track.addEventListener('pointerup', up);
    track.addEventListener('pointercancel', up);
    return () => { track.removeEventListener('pointerdown', down); track.removeEventListener('pointermove', move); track.removeEventListener('pointerup', up); track.removeEventListener('pointercancel', up); };
  }, []);

  const go = (id, e) => {
    e.stopPropagation();
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY, behavior: 'smooth' });
  };

  return (
    <nav className="rail" aria-label="History timeline">
      <div className="rail__meta">
        <span className="rail__now" ref={nowRef}>{decades[0].era}</span>
      </div>
      <div className="rail__track" ref={trackRef} title="Drag to scrub through time">
        <div className="rail__fill" ref={fillRef} style={{ height: '0%' }} />
        <div className="rail__head" ref={headRef} style={{ top: '0%' }} />
        <ul className="rail__ticks">
          {decades.map((d, i) => (
            <li key={d.label} className="rail__tick">
              <button onClick={(e) => go(d.id, e)} title={d.era}>
                <span className="rail__dot" ref={(el) => (dotRefs.current[i] = el)} />
                <span className="rail__label" ref={(el) => (lblRefs.current[i] = el)}>{d.label}</span>
                {d.signature && <span className="rail__star" style={{ color: d.accent }}>★</span>}
              </button>
            </li>
          ))}
        </ul>
      </div>
      <div className="rail__cap">
        <span className="rail__capnum" ref={capRef}>00</span>
        <span className="rail__caplbl">ARCHIVE</span>
      </div>
    </nav>
  );
}

Object.assign(window, { TimeRail });
