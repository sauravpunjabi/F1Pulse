/* ───────────────────────────────────────────────────────────────────────────
   ds-timeline.jsx — "THE ASCENT": vertical career timeline 1984→1994 that
   carries the History-Mode signature: the early Lotus years render in
   black-and-white, then the 1988 McLaren-Honda title FLOODS the frame with
   colour as you scroll. Exports window.DriverTimeline.
   ─────────────────────────────────────────────────────────────────────────── */
const dsTl = window.DS;

/* The signature scroll-driven B&W → colour flood between 1987 and 1988. */
function ColorFlood({ accent }) {
  const [ref, p] = useScrollProgress();
  const reduced = useReducedMotion();
  // wipe runs through the middle band of the panel's travel
  const raw = (p - 0.2) / 0.5;
  const w = reduced ? 1 : Math.max(0, Math.min(1, raw));
  const wipe = w * 100;

  return (
    <div ref={ref} className="flood">
      <div className="flood__stage">
        {/* B&W base layer */}
        <div className="flood__layer flood__layer--bw">
          <span className="flood__year" style={{ color: 'rgba(255,255,255,0.14)' }}>1987</span>
          <span className="flood__tag" style={{ color: 'rgba(255,255,255,0.4)' }}>LOTUS · THE SILVER YEARS</span>
        </div>
        {/* Colour layer, revealed by a diagonal wipe */}
        <div className="flood__layer flood__layer--color" style={{
          clipPath: `polygon(0 0, ${wipe}% 0, ${Math.max(0, wipe - 12)}% 100%, 0 100%)`,
          background: `radial-gradient(120% 120% at 30% 30%, ${accent}38 0%, #120a0a 60%, #0a0606 100%)`,
        }}>
          <span className="flood__year" style={{ color: '#F5F4F0' }}>1988</span>
          <span className="flood__tag" style={{ color: accent }}>McLAREN-HONDA · WORLD CHAMPION</span>
        </div>
        {/* The wipe edge — a bright seam */}
        <div className="flood__seam" style={{ left: `calc(${wipe}% - 1px)`, background: accent, opacity: w > 0.02 && w < 0.99 ? 1 : 0, boxShadow: `0 0 24px ${accent}` }} />
      </div>
      <p className="flood__caption" style={{ opacity: w }}>
        <span style={{ color: accent }}>The colour returns.</span> Eight wins. Thirteen poles. A first crown — and the sport changes hue.
      </p>
    </div>
  );
}

function MiniStat({ k, v, accent }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 22, color: '#F5F4F0', fontVariantNumeric: 'tabular-nums' }}>{v}</span>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 8, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.4)' }}>{k}</span>
    </div>
  );
}

function YearRow({ s, accent, dir }) {
  const [ref, seen] = useInView({ threshold: 0.35 });
  const motion = useMotion();
  const teamColor = dsTl.teamColors[s.teamKey] || accent;
  const mono = s.mono;

  return (
    <div ref={ref} className={`yr ${mono ? 'yr--mono' : ''} ${s.requiem ? 'yr--requiem' : ''}`}
      style={{ opacity: seen ? 1 : 0, transform: seen ? 'translateY(0)' : 'translateY(40px)', transition: `opacity ${0.7 * motion}s ease, transform ${0.8 * motion}s cubic-bezier(0.16,1,0.3,1)` }}>
      {/* Rail node */}
      <div className="yr__rail">
        <span className="yr__node" style={{ background: s.champion ? accent : 'transparent', borderColor: s.champion ? accent : 'rgba(255,255,255,0.3)', boxShadow: s.champion ? `0 0 14px ${accent}` : 'none' }} />
      </div>

      {/* Year */}
      <div className="yr__year">
        <span style={{ fontFamily: 'var(--display)', fontWeight: 900, fontSize: 'clamp(40px,5vw,82px)', lineHeight: 0.85, color: s.champion ? '#F5F4F0' : 'rgba(245,244,240,0.55)', letterSpacing: '-0.02em' }}>{s.year}</span>
        {s.champion && <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.3em', color: accent, marginTop: 6 }}>★ CHAMPION</span>}
        {s.requiem && <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.3em', color: 'rgba(245,244,240,0.4)', marginTop: 6 }}>REQUIEM</span>}
      </div>

      {/* Image placeholder */}
      <div className="yr__img">
        <Portrait label={`${s.team} ${s.car}`} ratio="16 / 9" tone="dark" style={{ width: '100%', filter: mono ? 'grayscale(1) contrast(1.05)' : 'none' }} />
        <span className="yr__teamtag" style={{ borderColor: mono ? 'rgba(255,255,255,0.2)' : teamColor, color: mono ? 'rgba(245,244,240,0.6)' : teamColor }}>{s.team} · {s.car}</span>
      </div>

      {/* Detail */}
      <div className="yr__detail">
        <div style={{ display: 'flex', gap: 28, marginBottom: 14 }}>
          <MiniStat k="Finish" v={s.pos} accent={accent} />
          <MiniStat k="Wins" v={s.wins} accent={accent} />
          <MiniStat k="Poles" v={s.poles} accent={accent} />
          <MiniStat k="Points" v={s.points} accent={accent} />
        </div>
        <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(15px,1.4vw,21px)', lineHeight: 1.55, color: s.requiem ? accent : 'rgba(245,244,240,0.72)', maxWidth: 420, margin: 0 }}>{s.note}</p>
      </div>
    </div>
  );
}

function DriverTimeline({ dir, accent }) {
  const { seasons, eras } = dsTl;
  const early = seasons.filter((s) => s.year <= 1987);
  const late = seasons.filter((s) => s.year >= 1988);

  return (
    <section className="timeline theme-dark" style={{ background: '#0a0707', color: '#F5F4F0' }}>
      <div className="timeline-inner">
        {/* Header */}
        <div className="tl-head">
          <span style={{ fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '0.4em', textTransform: 'uppercase', color: accent }}>History Mode · The Ascent</span>
          <h2 style={{ fontFamily: dir === 'archive' ? 'var(--serif)' : 'var(--display)', fontStyle: dir === 'archive' ? 'italic' : 'normal', fontWeight: dir === 'archive' ? 500 : 900, textTransform: dir === 'archive' ? 'none' : 'uppercase', fontSize: 'clamp(44px,8vw,128px)', lineHeight: 0.85, margin: '14px 0 18px', letterSpacing: '-0.02em' }}>
            {dir === 'archive' ? 'From silver to scarlet' : <SplitReveal text="1984 → 1994" stagger={0.04} trigger="scroll" />}
          </h2>
          <div className="tl-eras">
            {eras.map((e) => (
              <div key={e.key} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ width: 24, height: 3, background: e.accent }} />
                <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.5)' }}>{e.label} · {e.years}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Early (mono) years */}
        <div className="tl-rows">
          {early.map((s) => <YearRow key={s.year} s={s} accent={accent} dir={dir} />)}
        </div>

        {/* The signature flood */}
        <ColorFlood accent={accent} />

        {/* Late (colour) years */}
        <div className="tl-rows">
          {late.map((s) => <YearRow key={s.year} s={s} accent={accent} dir={dir} />)}
        </div>

        {/* Requiem close */}
        <div className="requiem-close">
          <RevealLine color="rgba(255,255,255,0.14)" />
          <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(18px,2vw,30px)', lineHeight: 1.6, color: 'rgba(245,244,240,0.8)', maxWidth: 640, margin: '40px auto 0', textAlign: 'center' }}>
            “If you no longer go for a gap that exists, you are no longer a racing driver.”
          </p>
          <span style={{ display: 'block', textAlign: 'center', marginTop: 18, fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.35em', color: accent }}>AYRTON SENNA · 1960 — 1994</span>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { DriverTimeline, ColorFlood, YearRow });
