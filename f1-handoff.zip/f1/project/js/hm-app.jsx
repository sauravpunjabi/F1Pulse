/* ───────────────────────────────────────────────────────────────────────────
   hm-app.jsx — History Mode shell + master controller.
   ONE frame loop (via HM.frame) drives the whole world: scroll progress, the
   master B&W→colour saturation (gated by the 1967 ignition + grown by depth),
   the archival texture intensities, the crimson ignition flash, the active era,
   and the synthesized engine RPM. Assembles the spine + Tweaks.
   ─────────────────────────────────────────────────────────────────────────── */
const { useEffect: useEffectApp, useRef: useRefApp } = React;

const HM_ACCENTS = [
  { label: 'Crimson', value: '#C9201A' },
  { label: 'Amber',   value: '#E8A33D' },
  { label: 'Silver',  value: '#C9C4B8' },
  { label: 'Teal',    value: '#1FA07A' },
];

const HM_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#C9201A",
  "grain": 1,
  "flicker": 1,
  "dust": 1,
  "vignette": 1,
  "motion": 1
}/*EDITMODE-END*/;

const clamp01 = (x) => Math.max(0, Math.min(1, x));
function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
function lerpHex(a, b, t) { const A = hexToRgb(a), B = hexToRgb(b); const c = A.map((x, i) => Math.round(x + (B[i] - x) * t)); return `rgb(${c[0]},${c[1]},${c[2]})`; }
function bgAt(c) {
  const stops = window.HM.stageStops;
  for (let i = 0; i < stops.length - 1; i++) {
    const s = stops[i], e = stops[i + 1];
    if (c >= s.at && c <= e.at) { const t = (c - s.at) / (e.at - s.at || 1); return lerpHex(s.bg, e.bg, t); }
  }
  return stops[stops.length - 1].bg;
}

function App() {
  const [t, setTweak] = useTweaks(HM_DEFAULTS);
  const tref = useRefApp(t);
  tref.current = t;

  useEffectApp(() => { window.__motionScale = t.motion; window.dispatchEvent(new Event('ds-motion')); }, [t.motion]);
  useEffectApp(() => { document.documentElement.style.setProperty('--accent', t.accent); }, [t.accent]);

  // ── Master controller ─────────────────────────────────────────────────────
  useEffectApp(() => {
    const root = document.documentElement;
    let cur = 0, redFlash = 0, wasIgnited = false;

    const tick = ({ dt }) => {
      const S = window.HM.state;
      const sh = document.documentElement.scrollHeight - window.innerHeight;
      const sy = window.scrollY;
      const scroll = sh > 0 ? clamp01(sy / sh) : 0;
      S.scroll = scroll;

      const ig = document.getElementById('sec-1967');
      const fin = document.getElementById('sec-now');

      // master colour: gated by ignition, grows with depth
      let target;
      if (!S.ignited) {
        target = S.hold * 0.42;
      } else {
        const igStart = ig ? ig.offsetTop : 0;
        const end = fin ? fin.offsetTop : sh;
        const gp = end > igStart ? clamp01((sy - igStart) / (end - igStart)) : 0;
        target = 0.42 + 0.58 * gp;
        if (sy < igStart - window.innerHeight * 0.6) target = 0; // grey past
      }
      cur += (target - cur) * Math.min(1, dt * 6);
      S.colour = cur;
      root.style.setProperty('--desat', (1 - cur).toFixed(3));
      root.style.setProperty('--stage-bg', bgAt(scroll));

      const tw = tref.current;
      root.style.setProperty('--grain-op', ((0.15 * (1 - cur) + 0.045) * tw.grain).toFixed(3));
      root.style.setProperty('--flicker-op', ((0.9 * (1 - cur)) * tw.flicker).toFixed(3));
      root.style.setProperty('--dust-op', ((0.32 * (1 - cur) + 0.03) * tw.dust).toFixed(3));
      root.style.setProperty('--vignette-op', ((0.55 * (1 - cur) + 0.2) * tw.vignette).toFixed(3));

      // crimson ignition flash
      if (S.ignited && !wasIgnited) { wasIgnited = true; redFlash = 1; }
      let red = S.ignited ? (redFlash = Math.max(0, redFlash - dt / 1.8)) : S.hold;
      root.style.setProperty('--flood-red', (red * 46).toFixed(1) + 'vh');
      root.style.setProperty('--flood-red-op', (red * 0.9).toFixed(3));

      // active era — nearest section centre to viewport centre
      let best = null, bestD = Infinity; const vc = window.innerHeight / 2;
      for (const d of window.HM.decades) {
        const el = document.getElementById(d.id); if (!el) continue;
        const r = el.getBoundingClientRect(); const dist = Math.abs(r.top + r.height / 2 - vc);
        if (dist < bestD) { bestD = dist; best = d; }
      }
      if (best) { S.activeEra = best.era; S.accent = cur > 0.04 ? best.accent : '#8d8a84'; }

      // engine note: louder of the two interactions, scrub decays
      window.HM.audio.setRPM(Math.max(S.holdRpm || 0, S.scrubRpm || 0));
      S.scrubRpm = (S.scrubRpm || 0) * 0.9;
    };

    const off = window.HM.frame.add(tick);
    return off;
  }, []);

  const eras = window.HM.eras;

  return (
    <React.Fragment>
      <SoundToggle accent={t.accent} />
      <TimeRail />

      <div className="history-stage">
        <Threshold accent={t.accent} />
        <EraChapter era={eras[0]} />
        <Ignite accent={t.accent} />
        {eras.slice(1).map((e) => <EraChapter key={e.id} era={e} />)}
        <Scrubber />

        <section className="closer" data-screen-label="Closer">
          <span className="mono-tick">Seventy-six years · still accelerating</span>
          <h3 className="closer__title">The story<br />continues</h3>
          <p className="closer__line">Every lap since 1950, leading to the next corner — somewhere ahead, the fastest cars in history are firing up.</p>
        </section>
      </div>

      <div className="flood-red" aria-hidden="true" />
      <HistoryTexture />

      <TweaksPanel>
        <TweakSection label="Signature Accent" />
        <TweakColor label="Accent" value={t.accent} options={HM_ACCENTS.map((a) => a.value)} onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Archival Texture" />
        <TweakSlider label="Film grain" value={t.grain} min={0} max={2} step={0.1} unit="×" onChange={(v) => setTweak('grain', v)} />
        <TweakSlider label="Projector flicker" value={t.flicker} min={0} max={2} step={0.1} unit="×" onChange={(v) => setTweak('flicker', v)} />
        <TweakSlider label="Dust & scratches" value={t.dust} min={0} max={2} step={0.1} unit="×" onChange={(v) => setTweak('dust', v)} />
        <TweakSlider label="Vignette" value={t.vignette} min={0} max={2} step={0.1} unit="×" onChange={(v) => setTweak('vignette', v)} />
        <TweakSection label="Motion" />
        <TweakSlider label="Speed" value={t.motion} min={0.5} max={2} step={0.1} unit="×" onChange={(v) => setTweak('motion', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
