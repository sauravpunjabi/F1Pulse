/* ───────────────────────────────────────────────────────────────────────────
   hm-sound.jsx — opt-in sound toggle. Audio is synthesized in hm-engine and
   stays muted until the user clicks here (a real gesture, required to start an
   AudioContext). Exports window.SoundToggle.
   ─────────────────────────────────────────────────────────────────────────── */
const { useState: useStateSd, useEffect: useEffectSd } = React;

function SoundToggle({ accent }) {
  const [on, setOn] = useStateSd(false);
  useEffectSd(() => window.HM.onAudio((v) => setOn(v)), []);
  const toggle = async () => {
    await window.HM.audio.toggle();
    window.HM.emitAudio();
  };
  return (
    <button className={`sound${on ? ' is-on' : ''}`} onClick={toggle} aria-pressed={on} aria-label={on ? 'Sound on' : 'Sound off'}>
      <span className="sound__eq" aria-hidden="true">
        <i style={{ background: accent }} /><i style={{ background: accent }} />
        <i style={{ background: accent }} /><i style={{ background: accent }} />
      </span>
      <span className="sound__lbl">{on ? 'Sound on' : 'Sound off'}</span>
    </button>
  );
}

Object.assign(window, { SoundToggle });
