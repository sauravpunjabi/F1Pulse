/* ───────────────────────────────────────────────────────────────────────────
   hm-data.js — History Mode content (plain global).
   Narrative copy + cosmetic constants. Settled history only; never live data.
   The chromatic journey: silver → gold → ember → yellow → red → teal → spectrum.
   ─────────────────────────────────────────────────────────────────────────── */
window.HM = (function () {

  // Decade rail — every tick the scrubber shows. All live in this spine now.
  const decades = [
    { id: 'sec-1950', label: '1950s', era: 'Birth of Speed',  accent: '#B6B2A8' },
    { id: 'sec-1967', label: '1967',  era: 'Colour Arrives',  accent: '#C9201A', signature: true },
    { id: 'sec-1970', label: '1970s', era: 'The Golden Era',  accent: '#E8A33D' },
    { id: 'sec-1980', label: '1980s', era: 'Turbo Wars',      accent: '#E0552E' },
    { id: 'sec-1990', label: '1990s', era: 'The Rivalry',     accent: '#E6C233' },
    { id: 'sec-2000', label: '2000s', era: 'Red Dynasty',     accent: '#D81E26' },
    { id: 'sec-2010', label: '2010s', era: 'The Hybrid Age',  accent: '#3FC1B0' },
    { id: 'sec-now',  label: 'NOW',   era: 'Present Tense',   accent: '#E10600' },
  ];

  // Era chapters (everything except the 1967 ignite, which is bespoke).
  // colour: 0..1 master-saturation floor this era should read at once ignited.
  const eras = [
    {
      id: 'sec-1950', num: '01', range: '1950 — 1959', tag: 'B&W · Silver Film',
      title: 'BIRTH OF SPEED', accent: '#B6B2A8', bg: '#070707', colour: 0,
      ghost: '1950',
      lede: '13 May 1950, Silverstone. Seven races to crown the first World Champion of Drivers — front-engined machines, no seatbelts, drivers in shirtsleeves and linen helmets.',
      facts: [
        { k: 'First Champion', v: 'G. Farina' },
        { k: 'Marque', v: 'Alfa Romeo' },
        { k: 'Colour', v: 'None' },
      ],
      plate: 'Silverstone · 13 May 1950 · The first grid',
      pull: 'A sport developed in monochrome — courage measured in seconds, captured on silver film.',
    },
    {
      id: 'sec-1970', num: '03', range: '1970 — 1979', tag: 'Colour · Sepia Gold',
      title: 'THE GOLDEN ERA', accent: '#E8A33D', bg: '#16120c', colour: 0.42,
      ghost: '’79', reverse: true,
      lede: 'Ground-effect tunnels, cigarette liveries and the warmth of analogue feel — when the car spoke and the driver answered through the soles of their feet.',
      facts: [
        { k: 'Innovation', v: 'Ground Effect' },
        { k: 'Feel', v: 'Pure Analogue' },
        { k: 'Tone', v: 'Sepia Gold' },
      ],
      plate: 'Monaco · 1979 · Ground-effect age',
      pull: 'Colour, finally — and with it the warmth of gold, smoke and sunlight on Monaco asphalt.',
    },
    {
      id: 'sec-1980', num: '04', range: '1980 — 1989', tag: 'Turbo · Boost Fire',
      title: 'TURBO WARS', accent: '#E0552E', bg: '#151013', colour: 0.56,
      ghost: '’86',
      lede: 'Fifteen hundred horsepower in qualifying trim. Boost gauges off the dial, fuel on a knife-edge — the most violent engines the sport has ever lit.',
      facts: [
        { k: 'Peak Power', v: '≈1500 bhp' },
        { k: 'Format', v: '1.5L Turbo' },
        { k: 'Risk', v: 'Maximum' },
      ],
      plate: 'Österreichring · 1983 · Boost off the dial',
      pull: 'They called it the grenade — wind it up, hold your breath, and pray it lasted a single flying lap.',
    },
    {
      id: 'sec-1990', num: '05', range: '1990 — 1999', tag: 'Active Era · Rivalry',
      title: 'THE RIVALRY', accent: '#E6C233', bg: '#12110d', colour: 0.68,
      ghost: '’93', reverse: true,
      lede: 'Genius against precision. A yellow helmet in the rain at Donington, a rivalry so fierce it redrew what courage inside a cockpit could mean.',
      facts: [
        { k: 'Icon', v: 'A. Senna' },
        { k: 'Tech', v: 'Active Susp.' },
        { k: 'Legacy', v: 'Eternal' },
      ],
      plate: 'Donington · 1993 · The lap of the gods',
      pull: 'Some drivers chase the limit. Senna parked his car on top of it and dared the rest to follow.',
    },
    {
      id: 'sec-2000', num: '06', range: '2000 — 2009', tag: 'Scuderia · Scarlet',
      title: 'RED DYNASTY', accent: '#D81E26', bg: '#130c0c', colour: 0.8,
      ghost: '’04',
      lede: 'Five titles in a row. A German metronome and a scarlet machine turned domination into an art form — and Maranello into the centre of the universe.',
      facts: [
        { k: 'Champion', v: 'M. Schumacher' },
        { k: 'Titles', v: 'Five Straight' },
        { k: 'Marque', v: 'Ferrari' },
      ],
      plate: 'Monza · 2004 · The tifosi roar',
      pull: 'Perfection, repeated until it became routine — and a sea of red that never stopped believing.',
    },
    {
      id: 'sec-2010', num: '07', range: '2010 — 2019', tag: 'Hybrid · The Hum',
      title: 'THE HYBRID AGE', accent: '#3FC1B0', bg: '#0b1012', colour: 0.9,
      ghost: '’14', reverse: true,
      lede: 'Energy harvested under braking, deployed at 160 mph. Power units of bewildering complexity — the quietest, fastest, most efficient cars ever raced.',
      facts: [
        { k: 'Power Unit', v: 'Hybrid V6' },
        { k: 'Recovery', v: 'MGU-K · H' },
        { k: 'Frontier', v: 'Software' },
      ],
      plate: 'Spa · 2014 · The hybrid frontier',
      pull: 'The scream gave way to a hum — and somehow the cars got faster than anyone believed possible.',
    },
    {
      id: 'sec-now', num: '08', range: '2020 — NOW', tag: 'Live · Full Spectrum',
      title: 'PRESENT TENSE', accent: '#E10600', bg: '#0a0a0e', colour: 1,
      ghost: '26', reverse: false, finale: true,
      lede: 'Ground effect returns. Twenty-four races, a global grid, a sport reborn for a new generation — and the fastest machinery in its seventy-six-year history.',
      facts: [
        { k: 'Season', v: '2026' },
        { k: 'Rounds', v: '24' },
        { k: 'Colour', v: 'Full Spectrum' },
      ],
      plate: 'Las Vegas · 2026 · The present tense',
      pull: 'Seventy-six years of silver, gold and fire — all of it leading here, to a sport finally seen in full.',
    },
  ];

  // 1967 — the signature ignition. Press & hold to set the film alight.
  const ignite = {
    year: '1967',
    pre: ['THE', 'COLOUR', 'ARRIVES'],
    venue: 'British Grand Prix',
    sub: 'Silverstone · The world gains its hues',
    prompt: 'Press & hold to ignite',
    caption: 'Seventeen years in silver. Then, in a single season, the film catches fire — and Formula One is seen in colour for the first time.',
    swatches: ['#C9201A', '#E8A33D', '#1FA07A', '#2D6BD6', '#7A4FD0', '#B6BABD'],
  };

  // Drag-the-decades time lever. Each node morphs the central display.
  // speed = evocative qualifying-trim top speed (km/h), not a record claim.
  const scrub = {
    nodes: [
      { year: '1950', label: 'Front-engined', accent: '#B6B2A8', speed: 290, body: 'cigar' },
      { year: '1967', label: 'Colour arrives', accent: '#C9201A', speed: 300, body: 'cigar' },
      { year: '1979', label: 'Ground effect', accent: '#E8A33D', speed: 320, body: 'wing' },
      { year: '1986', label: 'Turbo peak',    accent: '#E0552E', speed: 345, body: 'wing' },
      { year: '1993', label: 'Active era',    accent: '#E6C233', speed: 350, body: 'wing' },
      { year: '2004', label: 'V10 zenith',    accent: '#D81E26', speed: 370, body: 'modern' },
      { year: '2017', label: 'Hybrid force',  accent: '#3FC1B0', speed: 372, body: 'modern' },
      { year: '2026', label: 'Ground effect II', accent: '#E10600', speed: 362, body: 'modern' },
    ],
  };

  // Stage background journey by scroll position 0..1 (dark → warm → modern).
  const stageStops = [
    { at: 0.0,  bg: '#070707' },
    { at: 0.28, bg: '#100b08' },
    { at: 0.5,  bg: '#16120c' },
    { at: 0.72, bg: '#120c0c' },
    { at: 1.0,  bg: '#0a0a0e' },
  ];

  return { decades, eras, ignite, scrub, stageStops };
})();
