/* ============================================================================
   F1Pulse — The Atlas · A Living Globe
   Hi-detail orthographic Earth: 50m coastlines, country borders, atmospheric
   halo, a drifting day-night terminator and city lights that wake at dusk.
   Static until dragged. Loads after engine.js (F1) + d3 + topojson-client.
   ========================================================================== */
(function () {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const root = document.documentElement;
  const SVGNS = 'http://www.w3.org/2000/svg';
  const F1 = window.F1 || { onFrame: (cb) => requestAnimationFrame(function l(){ cb({}); requestAnimationFrame(l); }) };
  const el = (tag, cls, attrs) => {
    const e = document.createElementNS(SVGNS, tag);
    if (cls) e.setAttribute('class', cls);
    if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  };

  /* ── page-local atmosphere (deep space by default) ─────────────────────────
     This page owns its own light/dark independent of the site-wide theme so it
     always opens in the intended deep-space look. Stored under its own key. ── */
  const ATLAS_THEME_KEY = 'atlas-atmosphere';
  function readAtlasTheme() {
    let t; try { t = localStorage.getItem(ATLAS_THEME_KEY); } catch (e) {}
    return (t === 'light' || t === 'dark') ? t : 'dark';
  }
  function forceAtlasTheme() { root.setAttribute('data-theme', readAtlasTheme()); }
  // engine.js applies the shared theme on DOMContentLoaded; run after it to win.
  if (document.readyState === 'loading') addEventListener('DOMContentLoaded', forceAtlasTheme);
  else forceAtlasTheme();

  /* ── starfield ─────────────────────────────────────────────────────────── */
  (function stars() {
    const host = document.getElementById('stars'); if (!host) return;
    function build() {
      host.innerHTML = '';
      const W = innerWidth, H = innerHeight;
      const n = Math.round(Math.min(220, (W * H) / 9000));
      const frag = document.createDocumentFragment();
      for (let i = 0; i < n; i++) {
        const s = document.createElement('i');
        const r = Math.random();
        const size = r < 0.82 ? (0.8 + Math.random() * 1.1) : (1.8 + Math.random() * 1.6);
        s.style.width = s.style.height = size.toFixed(2) + 'px';
        s.style.left = (Math.random() * 100).toFixed(2) + '%';
        s.style.top = (Math.random() * 100).toFixed(2) + '%';
        s.style.setProperty('--td', (3 + Math.random() * 6).toFixed(2) + 's');
        s.style.setProperty('--o1', (0.08 + Math.random() * 0.22).toFixed(2));
        s.style.setProperty('--o2', (0.55 + Math.random() * 0.45).toFixed(2));
        s.style.animationDelay = (-Math.random() * 8).toFixed(2) + 's';
        if (size > 1.9) s.style.boxShadow = '0 0 5px rgba(255,255,255,.7)';
        frag.appendChild(s);
      }
      host.appendChild(frag);
    }
    build();
    let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(build, 250); }, { passive: true });

    // occasional shooting star (dark theme only, motion on)
    function shoot() {
      const m = window.__f1motion ?? 1;
      if (!reduced && m > 0.05 && root.getAttribute('data-theme') !== 'light' && Math.random() < 0.6) {
        const s = document.createElement('div'); s.className = 'shoot';
        const x = 20 + Math.random() * 60, y = 8 + Math.random() * 32;
        s.style.left = x + 'vw'; s.style.top = y + 'vh';
        host.appendChild(s);
        s.animate([
          { transform: 'translate(0,0) rotate(18deg)', opacity: 0 },
          { opacity: 1, offset: 0.15 },
          { transform: 'translate(40vw,13vw) rotate(18deg)', opacity: 0 }
        ], { duration: 1100, easing: 'cubic-bezier(.3,.6,.2,1)' }).onfinish = () => s.remove();
      }
      setTimeout(shoot, 6000 + Math.random() * 9000);
    }
    setTimeout(shoot, 4000);
  })();

  /* ── major cities (lon, lat, weight) — for the night-side lights ───────── */
  const CITIES = [
    [-74.0,40.7,1.3],[-87.6,41.9,1],[-118.2,34.0,1.2],[-122.4,37.8,.9],[-95.4,29.8,.9],[-80.2,25.8,.9],
    [-79.4,43.7,.9],[-123.1,49.3,.7],[-99.1,19.4,1.2],[-90.5,14.6,.6],[-58.4,-34.6,1],[-46.6,-23.6,1.2],
    [-43.2,-22.9,1],[-70.7,-33.5,.8],[-77.0,-12.0,.8],[-47.9,-15.8,.7],[-3.7,40.4,1],[2.35,48.85,1.3],
    [-0.13,51.5,1.3],[-6.26,53.3,.7],[4.9,52.4,.9],[13.4,52.5,1.1],[12.5,41.9,1],[9.19,45.46,.9],
    [2.17,41.4,.9],[8.68,50.1,.8],[-9.14,38.7,.7],[18.07,59.33,.8],[10.75,59.91,.7],[24.94,60.17,.7],
    [37.6,55.75,1.2],[30.5,50.45,.8],[21.0,52.23,.8],[16.37,48.2,.8],[19.04,47.5,.7],[28.98,41.0,1.2],
    [32.86,39.93,.8],[35.21,31.77,.8],[31.24,30.06,1.1],[3.06,36.75,.7],[28.05,-26.2,.9],[18.42,-33.9,.8],
    [36.82,-1.29,.7],[39.27,-6.82,.6],[44.0,21.5,.6],[51.39,35.69,1],[55.27,25.2,1.1],[54.37,24.45,.8],
    [46.72,24.69,.9],[47.98,29.37,.7],[50.58,26.22,.6],[60.6,29.4,.5],[67.0,24.86,.9],[72.87,19.07,1.3],
    [77.21,28.61,1.3],[88.36,22.57,1],[80.27,13.08,1],[77.59,12.97,1],[78.47,17.38,.9],[90.4,23.8,1],
    [100.5,13.75,1.1],[106.8,-6.21,1.2],[103.8,1.35,1.1],[101.69,3.14,.9],[120.98,14.6,1.1],[121.0,31.23,1.4],
    [116.4,39.9,1.4],[113.26,23.13,1.2],[114.17,22.32,1.2],[120.2,30.25,1],[126.98,37.57,1.4],[127.0,37.5,.8],
    [139.69,35.69,1.5],[135.5,34.69,1.1],[130.4,33.59,.8],[144.96,-37.81,1],[151.2,-33.87,1.1],[153.0,-27.47,.8],
    [174.76,-36.85,.7],[121.56,25.04,1],[105.85,21.03,.9],[106.66,10.76,1],[-58.0,6.8,.5],[-99.2,19.0,.6],
    [-84.4,33.75,.8],[-71.06,42.36,.9],[-75.16,39.95,.9],[-104.99,39.74,.7],[-112.07,33.45,.8],[-96.8,32.78,.9],
    [-86.15,39.77,.6],[-93.27,44.98,.7],[-90.07,29.95,.6],[-81.38,28.54,.7],[-115.14,36.17,.8],[-122.33,47.6,.8],
    [-73.57,45.5,.8],[-114.07,51.05,.6],[-38.5,-12.97,.7],[-49.27,-25.43,.7],[-60.0,-3.1,.6],[28.19,-25.75,.5],
    [7.42,43.73,.5],[-16.0,28.1,.4],[-15.6,27.7,.4],[55.45,-20.9,.4]
  ];

  /* ── GLOBE ─────────────────────────────────────────────────────────────── */
  (function globe() {
    const stage = document.getElementById('globe');
    const svg = document.getElementById('globe-svg');
    if (!stage || !svg || !window.d3) return;
    const d3 = window.d3;

    const S = 760, R = 330, CX = S / 2, CY = S / 2;
    svg.setAttribute('viewBox', `0 0 ${S} ${S}`);

    const proj = d3.geoOrthographic().scale(R).translate([CX, CY]).rotate([-12, -22]).clipAngle(90);
    const path = d3.geoPath(proj);
    const graticule = d3.geoGraticule().step([15, 15]);

    /* defs: gradients, glow, clip */
    const defs = el('defs');
    defs.innerHTML = `
      <radialGradient id="oceanGrad" cx="50%" cy="44%" r="62%">
        <stop offset="0%"  stop-color="#1f5688"/>
        <stop offset="55%" stop-color="#143f66"/>
        <stop offset="100%" stop-color="#081f36"/>
      </radialGradient>
      <linearGradient id="landGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#46705a"/>
        <stop offset="100%" stop-color="#2f5246"/>
      </linearGradient>
      <radialGradient id="atmoGrad" cx="50%" cy="50%" r="50%">
        <stop offset="62%" stop-color="rgba(86,150,224,0)"/>
        <stop offset="86%" stop-color="rgba(96,162,236,0.28)"/>
        <stop offset="98%" stop-color="rgba(120,180,255,0.0)"/>
      </radialGradient>
      <radialGradient id="rimGrad" cx="50%" cy="50%" r="50%">
        <stop offset="86%" stop-color="rgba(150,200,255,0)"/>
        <stop offset="97%" stop-color="rgba(173,214,255,0.55)"/>
        <stop offset="100%" stop-color="rgba(173,214,255,0)"/>
      </radialGradient>
      <radialGradient id="sunGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%"  stop-color="rgba(255,247,224,0.55)"/>
        <stop offset="35%" stop-color="rgba(255,233,180,0.20)"/>
        <stop offset="100%" stop-color="rgba(255,233,180,0)"/>
      </radialGradient>
      <filter id="softBlur" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="7"/>
      </filter>
      <filter id="termBlur" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="2.2"/>
      </filter>
      <filter id="cityGlow" x="-300%" y="-300%" width="700%" height="700%">
        <feGaussianBlur stdDeviation="1.6"/>
      </filter>
      <clipPath id="globeClip"><circle cx="${CX}" cy="${CY}" r="${R}"/></clipPath>`;
    svg.appendChild(defs);

    /* atmospheric halo behind the planet */
    const halo = el('circle', null, { cx: CX, cy: CY, r: R * 1.16, fill: 'url(#atmoGrad)', filter: 'url(#softBlur)' });
    svg.appendChild(halo);

    /* sphere (ocean) */
    const sphere = el('path', null, { fill: 'url(#oceanGrad)' });
    sphere.setAttribute('id', 'g-sphere');
    svg.appendChild(sphere);

    /* clipped group: everything that lives on the disc */
    const disc = el('g', null, { 'clip-path': 'url(#globeClip)' });
    svg.appendChild(disc);

    const grat = el('path', 'g-grat'); disc.appendChild(grat);
    const land = el('path', 'g-land'); disc.appendChild(land);
    const border = el('path', 'g-border'); disc.appendChild(border);
    const sunGlow = el('circle', 'g-specular', { r: R * 0.62, fill: 'url(#sunGrad)', style: 'mix-blend-mode:screen' });
    disc.appendChild(sunGlow);
    const night = el('path', 'g-night', { filter: 'url(#termBlur)' }); disc.appendChild(night);
    const term = el('path', 'g-term', { filter: 'url(#termBlur)' }); disc.appendChild(term);
    const cityG = el('g'); disc.appendChild(cityG);

    /* rim light on top of the disc */
    const rim = el('circle', null, { cx: CX, cy: CY, r: R, fill: 'url(#rimGrad)', style: 'mix-blend-mode:screen' });
    svg.appendChild(rim);

    /* light theme tones for the ocean/halo */
    function paintTheme() {
      const light = root.getAttribute('data-theme') === 'light';
      sphere.setAttribute('fill', light ? '#e3ddd0' : 'url(#oceanGrad)');
      halo.style.opacity = light ? '0.25' : '1';
      rim.style.opacity = light ? '0.4' : '1';
    }

    /* city light dots */
    const cityEls = CITIES.map((c) => {
      const dot = el('circle', 'g-city', { r: (1.1 + c[2] * 1.35).toFixed(2), filter: 'url(#cityGlow)' });
      dot.style.display = 'none';
      cityG.appendChild(dot);
      return { c, ll: [c[0], c[1]], dot, phase: Math.random() * Math.PI * 2, w: c[2] };
    });

    /* feature data (filled after fetch) */
    let landF = null, borderF = null;

    /* ── earth render (only when orientation changes) ──────────────────────── */
    function renderEarth() {
      sphere.setAttribute('d', path({ type: 'Sphere' }) || '');
      grat.setAttribute('d', path(graticule()) || '');
      if (landF) land.setAttribute('d', path(landF) || '');
      if (borderF && bordersOn) border.setAttribute('d', path(borderF) || '');
      else border.setAttribute('d', '');
      updateReadout();
    }

    /* ── sky render (terminator + lights + sun glow) every frame ───────────── */
    const decl = 16; // solar declination (deg) — fixed seasonal tilt
    let sunLon = 150;
    let bordersOn = true, lightsOn = true, living = true;
    let manualSun = null; // when frozen + scrubbed

    function antipode(lon, lat) { return [((lon + 360) % 360) - 180 + (lon + 180 > 180 ? 0 : 0), -lat]; }

    function renderSky(now) {
      const sun = [((sunLon + 540) % 360) - 180, decl];
      const anti = [((sunLon + 180 + 540) % 360) - 180, -decl];

      // night hemisphere disc
      const nightPath = d3.geoCircle().center(anti).radius(90)();
      const nd = path(nightPath) || '';
      night.setAttribute('d', nd);
      term.setAttribute('d', nd);

      // sun glow — only when subsolar point faces us
      const rot = proj.rotate();
      const center = [-rot[0], -rot[1]];
      const sunVisible = d3.geoDistance(sun, center) < Math.PI / 2;
      const sp = proj(sun);
      if (sunVisible && sp) {
        sunGlow.setAttribute('cx', sp[0].toFixed(1));
        sunGlow.setAttribute('cy', sp[1].toFixed(1));
        sunGlow.style.opacity = '1';
      } else { sunGlow.style.opacity = '0'; }

      // city lights
      if (lightsOn) {
        const t = now * 0.001;
        for (const it of cityEls) {
          const onFar = d3.geoDistance(it.ll, center) > Math.PI / 2 - 0.02;
          const sunAng = d3.geoDistance(it.ll, sun); // > PI/2 → night
          if (onFar || sunAng < Math.PI / 2 - 0.12) { it.dot.style.display = 'none'; continue; }
          const p = proj(it.ll); if (!p) { it.dot.style.display = 'none'; continue; }
          it.dot.style.display = '';
          it.dot.setAttribute('cx', p[0].toFixed(1));
          it.dot.setAttribute('cy', p[1].toFixed(1));
          // deeper into night = brighter; gentle twinkle
          const depth = Math.min(1, (sunAng - (Math.PI / 2 - 0.12)) / 0.42);
          const tw = 0.78 + 0.22 * Math.sin(t * (1.4 + it.w) + it.phase);
          it.dot.style.opacity = (Math.max(0.45, 0.45 + depth * 0.55) * tw).toFixed(3);
        }
      } else {
        for (const it of cityEls) it.dot.style.display = 'none';
      }
    }

    /* ── readout ───────────────────────────────────────────────────────────── */
    const roLat = document.getElementById('ro-lat');
    const roLon = document.getElementById('ro-lon');
    const roSun = document.getElementById('ro-sun');
    const fmt = (v, pos, neg) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? pos : neg}`;
    function updateReadout() {
      const rot = proj.rotate();
      if (roLat) roLat.innerHTML = fmt(-rot[1], 'N', 'S');
      if (roLon) roLon.innerHTML = fmt(-rot[0], 'E', 'W');
      if (roSun) roSun.innerHTML = fmt(((sunLon + 540) % 360) - 180, 'E', 'W');
    }

    /* ── drag to rotate ────────────────────────────────────────────────────── */
    let dragging = false, lx = 0, ly = 0;
    const sens = 0.32;
    stage.addEventListener('pointerdown', (e) => {
      dragging = true; lx = e.clientX; ly = e.clientY;
      try { stage.setPointerCapture(e.pointerId); } catch (_) {}
    });
    stage.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
      const r = proj.rotate();
      let nlat = r[1] - dy * sens; nlat = Math.max(-90, Math.min(90, nlat));
      proj.rotate([r[0] + dx * sens, nlat]);
      renderEarth();
    });
    const endDrag = () => { dragging = false; };
    stage.addEventListener('pointerup', endDrag);
    stage.addEventListener('pointercancel', endDrag);

    /* ── boot ──────────────────────────────────────────────────────────────── */
    paintTheme();
    renderEarth();
    renderSky(performance.now());

    // animate the terminator drift + twinkle
    let t0 = performance.now();
    F1.onFrame(({}) => {
      const now = performance.now();
      const m = window.__f1motion ?? 1;
      if (living && !reduced) {
        const dt = now - t0;
        // ~90s per full day, scaled gently by the Motion tweak
        sunLon -= dt * (360 / 90000) * (0.5 + 0.5 * m);
        if (sunLon < -360) sunLon += 360;
        if ((Math.round(now) % 4) === 0) updateReadout();
      } else if (manualSun != null) {
        sunLon = manualSun;
      }
      t0 = now;
      renderSky(now);
    });

    // react to theme changes from the Tweaks panel
    new MutationObserver(paintTheme).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

    // fetch hi-detail 50m countries → land outline (merge) + interior borders (mesh)
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json')
      .then((r) => r.json())
      .then((topo) => {
        if (!window.topojson) return;
        const obj = topo.objects.countries;
        landF = topojson.merge(topo, obj.geometries);
        borderF = topojson.mesh(topo, obj, (a, b) => a !== b);
        renderEarth();
      })
      .catch(() => {
        // fallback: coarse land only
        fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json')
          .then((r) => r.json())
          .then((t) => { if (window.topojson) { landF = topojson.feature(t, t.objects.land); renderEarth(); } })
          .catch(() => {});
      });

    /* ── expose tweak hooks ────────────────────────────────────────────────── */
    window.__atlas = {
      setLights: (v) => { lightsOn = !!v; },
      setBorders: (v) => { bordersOn = !!v; renderEarth(); },
      setLiving: (v) => { living = !!v; manualSun = v ? null : sunLon; },
      setSun: (lon) => { manualSun = lon; sunLon = lon; renderSky(performance.now()); updateReadout(); },
      getSun: () => sunLon, isLiving: () => living
    };
  })();

  /* ── extra Tweaks · inject into engine.js panel ────────────────────────── */
  (function tweaks() {
    const defaults = window.__F1_TWEAKS || {};
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {}; } catch (e) {}
    let lights = (saved.lights || defaults.lights || 'on');
    let borders = (saved.borders || defaults.borders || 'on');
    let living = (saved.living || defaults.living || 'living');

    function apply() {
      const a = window.__atlas; if (!a) return;
      a.setLights(lights === 'on');
      a.setBorders(borders === 'on');
      a.setLiving(living === 'living');
    }
    const applyIv = setInterval(() => { if (window.__atlas) { apply(); clearInterval(applyIv); } }, 120);

    function persist(edits) {
      try {
        const cur = JSON.parse(localStorage.getItem('f1home-tweaks') || '{}') || {};
        Object.assign(cur, edits);
        localStorage.setItem('f1home-tweaks', JSON.stringify(cur));
      } catch (e) {}
      try { window.parent.postMessage({ type: '__edit_mode_set_keys', edits }, '*'); } catch (e) {}
    }

    function seg(label, opts, val, onPick) {
      const row = document.createElement('div');
      row.className = 'twk__row'; row.setAttribute('data-atlas-tweak', '1');
      row.innerHTML = `<label>${label}</label><div class="twk__seg">${
        opts.map((o) => `<button data-v="${o.v}">${o.t}</button>`).join('')}</div>`;
      const s = row.querySelector('.twk__seg');
      const paint = () => s.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === val()));
      s.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => { onPick(b.dataset.v); paint(); }));
      paint();
      return row;
    }

    function inject() {
      const body = document.querySelector('.twk .twk__b');
      if (!body) return false;
      if (body.querySelector('[data-atlas-tweak]')) return true;

      // Replace the engine's site-theme control with a page-local Atmosphere one.
      const themeSeg = body.querySelector('[data-seg="theme"]');
      if (themeSeg) { const row = themeSeg.closest('.twk__row'); if (row) row.remove(); }
      let atmo = readAtlasTheme();
      const atmoRow = seg('Atmosphere', [{ v: 'dark', t: 'Deep space' }, { v: 'light', t: 'Paper' }],
        () => atmo, (v) => {
          atmo = v; root.setAttribute('data-theme', v);
          try { localStorage.setItem(ATLAS_THEME_KEY, v); } catch (e) {}
        });
      body.insertBefore(atmoRow, body.firstChild);

      body.appendChild(seg('City lights', [{ v: 'on', t: 'On' }, { v: 'off', t: 'Off' }],
        () => lights, (v) => { lights = v; window.__atlas && window.__atlas.setLights(v === 'on'); persist({ lights: v }); }));

      body.appendChild(seg('Country borders', [{ v: 'on', t: 'On' }, { v: 'off', t: 'Off' }],
        () => borders, (v) => { borders = v; window.__atlas && window.__atlas.setBorders(v === 'on'); persist({ borders: v }); }));

      // Living / Frozen + a time-of-day scrubber when frozen
      const row = document.createElement('div');
      row.className = 'twk__row'; row.setAttribute('data-atlas-tweak', '1');
      row.innerHTML = `<label>Day / night <span class="twk__val" id="atw-tod"></span></label>
        <div class="twk__seg" id="atw-live"><button data-v="living">Living</button><button data-v="frozen">Frozen</button></div>
        <input class="twk__rng" id="atw-sun" type="range" min="-180" max="180" step="1" style="margin-top:12px">`;
      body.appendChild(row);
      const s = row.querySelector('#atw-live');
      const rng = row.querySelector('#atw-sun');
      const tod = row.querySelector('#atw-tod');
      const paintLive = () => {
        s.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === living));
        rng.style.opacity = living === 'frozen' ? '1' : '0.35';
        rng.disabled = living === 'living';
        tod.textContent = living === 'living' ? 'drifting' : 'manual';
      };
      const syncRng = () => { if (window.__atlas) rng.value = Math.round(((window.__atlas.getSun() + 540) % 360) - 180); };
      s.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
        living = b.dataset.v;
        window.__atlas && window.__atlas.setLiving(living === 'living');
        syncRng(); paintLive(); persist({ living });
      }));
      rng.addEventListener('input', () => {
        if (living !== 'frozen') { living = 'frozen'; window.__atlas && window.__atlas.setLiving(false); paintLive(); persist({ living }); }
        window.__atlas && window.__atlas.setSun(parseFloat(rng.value));
      });
      syncRng(); paintLive();
      return true;
    }

    let tries = 0;
    const iv = setInterval(() => { if (inject() || ++tries > 50) clearInterval(iv); }, 120);
  })();

})();
