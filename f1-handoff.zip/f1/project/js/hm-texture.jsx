/* ───────────────────────────────────────────────────────────────────────────
   hm-texture.jsx — archival texture overlays. Intensity is driven by CSS vars
   (--grain-op, --flicker-op, --dust-op, --vignette-op) that the stage
   controller animates with scroll, so these layers never re-render on scroll.
   Exports window.HistoryTexture.
   ─────────────────────────────────────────────────────────────────────────── */

const GRAIN_URL = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch"/></filter><rect width="180" height="180" filter="url(%23n)"/></svg>'
) + '")';

function HistoryTexture() {
  return (
    <div aria-hidden="true" className="hm-texture">
      {/* film grain — twinkles via stepped background-position */}
      <div className="hm-grain" style={{ backgroundImage: GRAIN_URL }} />
      {/* projector flicker — irregular faint pulse */}
      <div className="hm-flicker" />
      {/* dust + scratches — drifting celluloid damage */}
      <svg className="hm-dust" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <filter id="hmspeck"><feTurbulence type="fractalNoise" baseFrequency="0.35 0.5" numOctaves="2" seed="7"/><feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 26 -22"/></filter>
        </defs>
        <rect width="100" height="100" filter="url(#hmspeck)" opacity="0.7"/>
        <g className="hm-scratch" stroke="#ffffff" strokeWidth="0.12">
          <line x1="22" y1="0" x2="22.6" y2="100"/>
          <line x1="61" y1="0" x2="60.4" y2="100"/>
          <line x1="83" y1="0" x2="83.5" y2="100"/>
        </g>
      </svg>
      {/* vignette */}
      <div className="hm-vignette" />
    </div>
  );
}

Object.assign(window, { HistoryTexture });
