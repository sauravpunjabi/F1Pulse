/* ───────────────────────────────────────────────────────────────────────────
   hm-engine.js — the beating heart of History Mode (plain global, no React).

   1. HM.frame  — ONE requestAnimationFrame loop. Components add(fn)/remove(fn)
      callbacks that run every frame with { t, dt }. Lets dozens of reactive
      elements update imperatively at 60fps without N scroll listeners or React
      re-renders. Auto-idles when nothing is subscribed.

   2. HM.state  — shared mutable values written each frame by the master
      controller (in hm-app) and read by any component: scroll, colour (master
      saturation 0..1), ignited, hold (0..1 ignite preview), rpm (engine sound).

   3. HM.audio  — synthesized, opt-in engine + atmosphere via Web Audio. No
      external files: a detuned sawtooth stack through a lowpass = engine note;
      filtered noise = air/tyre; a low sine = ambience. Muted until the user
      opts in (a real gesture), then setRPM/swell/ignite shape it.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  const HM = (window.HM = window.HM || {});

  // ── Shared per-frame state ─────────────────────────────────────────────────
  HM.state = {
    scroll: 0,      // 0..1 whole-page scroll progress
    colour: 0,      // 0..1 master saturation (1 - grayscale)
    ignited: false, // has the 1967 flood been triggered
    hold: 0,        // 0..1 ignite hold preview (pre-ignition tease)
    rpm: 0,         // 0..1 engine sound intensity target
    activeEra: 'Birth of Speed',
    accent: '#C9201A',
  };

  // ── Single rAF ticker ──────────────────────────────────────────────────────
  HM.frame = (function () {
    const subs = new Set();
    let raf = 0, last = 0;
    const loop = (t) => {
      const dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016;
      last = t;
      subs.forEach((fn) => { try { fn({ t: t / 1000, dt }); } catch (e) { /* keep looping */ } });
      raf = subs.size ? requestAnimationFrame(loop) : 0;
      if (!raf) last = 0;
    };
    return {
      add(fn) { subs.add(fn); if (!raf) raf = requestAnimationFrame(loop); return () => subs.delete(fn); },
      remove(fn) { subs.delete(fn); },
    };
  })();

  // ── Synthesized audio engine ────────────────────────────────────────────────
  HM.audio = (function () {
    let ctx = null, master = null;
    let engGain = null, noiseGain = null, ambGain = null, lp = null;
    let oscs = [], baseFreqs = [110, 110.6, 109.4, 220.5];
    let enabled = false, started = false;
    let curRpm = 0;

    function build() {
      if (started) return;
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.gain.value = 0; master.connect(ctx.destination);

      // engine: detuned saw stack → shared lowpass → engGain
      lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 320; lp.Q.value = 6;
      engGain = ctx.createGain(); engGain.gain.value = 0.0;
      lp.connect(engGain); engGain.connect(master);
      oscs = baseFreqs.map((f, i) => {
        const o = ctx.createOscillator(); o.type = i === 3 ? 'sawtooth' : 'sawtooth';
        o.frequency.value = f;
        const g = ctx.createGain(); g.gain.value = i === 3 ? 0.18 : 0.34;
        o.connect(g); g.connect(lp); o.start();
        return o;
      });

      // air / tyre: bandpassed white noise
      const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource(); noise.buffer = buf; noise.loop = true;
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 0.7;
      noiseGain = ctx.createGain(); noiseGain.gain.value = 0;
      noise.connect(bp); bp.connect(noiseGain); noiseGain.connect(master); noise.start();

      // ambience: low sine drone (the projector room)
      const amb = ctx.createOscillator(); amb.type = 'sine'; amb.frequency.value = 58;
      ambGain = ctx.createGain(); ambGain.gain.value = 0;
      amb.connect(ambGain); ambGain.connect(master); amb.start();

      started = true;
    }

    function ramp(param, to, time = 0.12) {
      if (!ctx) return;
      const now = ctx.currentTime;
      param.cancelScheduledValues(now);
      param.setValueAtTime(param.value, now);
      param.linearRampToValueAtTime(to, now + time);
    }

    return {
      get enabled() { return enabled; },
      async enable() {
        build();
        if (ctx.state === 'suspended') await ctx.resume();
        enabled = true;
        ramp(master.gain, 0.9, 0.6);
        ramp(ambGain.gain, 0.06, 1.2);
        return true;
      },
      disable() {
        enabled = false;
        if (master) ramp(master.gain, 0, 0.4);
      },
      toggle() { return enabled ? (this.disable(), Promise.resolve(false)) : this.enable(); },
      // rpm 0..1 → engine pitch + filter + level
      setRPM(rpm) {
        curRpm = rpm;
        if (!enabled || !started) return;
        const k = Math.max(0, Math.min(1, rpm));
        oscs.forEach((o, i) => ramp(o.frequency, baseFreqs[i] * (1 + k * 2.4), 0.08));
        ramp(lp.frequency, 320 + k * 2600, 0.1);
        ramp(engGain.gain, 0.04 + k * 0.16, 0.1);
        ramp(noiseGain.gain, k * 0.05, 0.12);
      },
      // a one-shot upward swell (ignition resolve)
      ignite() {
        if (!enabled || !started) return;
        const now = ctx.currentTime;
        oscs.forEach((o, i) => {
          o.frequency.cancelScheduledValues(now);
          o.frequency.setValueAtTime(baseFreqs[i] * 1.6, now);
          o.frequency.exponentialRampToValueAtTime(baseFreqs[i] * 4.2, now + 0.5);
          o.frequency.exponentialRampToValueAtTime(baseFreqs[i] * 2.0, now + 1.4);
        });
        lp.frequency.cancelScheduledValues(now);
        lp.frequency.setValueAtTime(1200, now);
        lp.frequency.exponentialRampToValueAtTime(5200, now + 0.45);
        lp.frequency.exponentialRampToValueAtTime(900, now + 1.6);
        engGain.gain.cancelScheduledValues(now);
        engGain.gain.setValueAtTime(0.22, now);
        engGain.gain.linearRampToValueAtTime(0.06, now + 1.6);
      },
    };
  })();

  // tiny pub/sub so React chrome (sound button, rail) can reflect audio on/off
  HM.audioListeners = new Set();
  HM.onAudio = (fn) => { HM.audioListeners.add(fn); return () => HM.audioListeners.delete(fn); };
  HM.emitAudio = () => HM.audioListeners.forEach((f) => f(HM.audio.enabled));
})();
